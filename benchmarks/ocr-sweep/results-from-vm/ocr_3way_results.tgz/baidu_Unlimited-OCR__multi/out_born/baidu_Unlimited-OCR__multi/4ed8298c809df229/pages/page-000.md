CorrectiveFeedbackCSNL

![figure](assets/p1_1.png)

RESEARCH ARTICLE

Correctivefeedbackguideshumanperceptual decision-makingbyinformingabouttheworldstate ratherthanrewardingitschoice

Hyang-Jung Le1, Heseung Le1, Chae Young Lim2, Isac Rhim3, Sang-Hun Le1*

1 Department of Brain and Cognitive Sciences, Seoul National University, Seoul, South Korea, 2 Department of Statistics, Seoul National University, Seoul, South Korea, 3 Institute of Neuroscience, University of Oregon, Eugene, Oregon, United States of America

visionsl@snu.ac.kr

Abstract

Corective fedback received on perceptual decisions is crucial for adjusting decision-making strategies to improve future choices. However, its complex interaction with other decision components, such as previous stimuli and choices, chalenges a principled acount of how it shapes subsequent decisions. One popular aproach, based on animal behavior and extended to human perceptual decision-making, employs “reinforcement learning,” a principle proven sucesful in reward-based decision-making. The core idea behind this aproach is that decision-makers, although engaged in a perceptual task, treat corective fedback as rewards from which they learn choice values. Here, we explore an alternative idea, which is that humans consider corective fedback on perceptual decisions as evidence of the actual state of the world rather than as rewards for their choices. By implementing these “fedback-as-reward” and “fedback-as-evidence” hypotheses on a shared learning platform, we show that the later