18. Odoemene O, Pisupati S, Nguyen H, Churchland AK. Visual evidence acumulation guides decision making in unrestrained mice. J Neurosci. 2018; 38(47):10143–1015. htps:/doi.org/10.1523/ JNEUROSCI.3478-17.2018 PMID: 3032902

19. Hermoso-Mendizabal A, Hyafil A, Rueda-Orozco PE, Jaramilo S, Robe D, de la Rocha J. Response outcomes gate the impact of expectations on perceptual decisions. Nat Comun. 2020; 1(1):1057. htps:/doi.org/10.1038/s41467-020-14824-w PMID: 3210309

20. Akrami A, Kopec CD, Diamond ME, Brody CD. Posterior parietal cortex represents sensory history and mediates its efects on behaviour. Nature. 2018; 54(7692):368–372. htps:/doi.org/10.1038/ nature2510 PMID: 2941494

21. Sumerfield C, Tsetsos K. Building bridges betwen perceptual and economic decision-making: neural and computational mechanisms. Front Neurosci. 2012; 6:70. htps:/doi.org/10. 389/fnins.2012. 070 PMID: 2654730

2. Kahnt T, Grueschow M, Speck O, Haynes JD. Perceptual learning and decision-making in human medial frontal cortex. Neuron. 201; 70(3):549–59. htps:/doi.org/10.1016/j.neuron.201.02.054 PMID: 21 5079

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 30 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions

24. Polanı´a R, Krajbich I, Grueschow M, Ruf C. Neural oscilations and synchronization diferentialy suport evidence acumulation in perceptual and value-based decision making. Neuron. 2014; 82(3):709–720. htps:/doi.org/10.1016/j.neuron.2014.03.014 PMID: 2481387

25. Ko¨rding KP, Wolpert DM. Bayesian decision theory in sensorimotor control. Trends Cogn Sci. 206; 10(7):319–326. htps:/doi.org/10.1016/j.tics.206.05.03 PMID: 16807063

26. Tromersha¨user J, Maloney LT, Landy MS. Decision making, movement planing and statistical decision theory. Trends Cogn Sci. 208; 12(8):291–297. htps:/doi.org/10.1016/j.tics.208.04.010 PMID: 18614390

27. Grifiths TL, Tenenbaum JB. Optimal predictions in everyday cognition. Psychol Sci. 206; 17(9):767–

73. htps:/doi.org/10. 1/j.1467-9280.206.01780.x PMID: 16984293

28. Tenenbaum JB, Kemp C, Grifiths TL, Godman ND. How to grow a mind: statistics, structure, and abstraction. Science. 201; 31(602):1279–1285. htps:/doi.org/10.126/science.19278 PMID: 21393536

29. Glaze CM, Filipowicz ALS, Kable JW, Balasubramanian V, Gold JI. A bias–variance trade-of governs individual diferences in on-line learning in an unpredictable environment. Nat Hum Behav. 2018; 2(3):213–24.

30. Ma WJ. Bayesian decision models: A primer. Neuron. 2019; 104(1):164–175. htps:/doi.org/10.1016/j.neuron.2019.09.037 PMID: 3160512

31. Hachen I, Reinartz S, Braselet R, Stroligo A, Diamond ME. Dynamics of history-dependent perceptual judgment. Nat Comun. 2021; 12(1):6036. htps:/doi.org/10.1038/s41467-021-26104-2 PMID: 34654804