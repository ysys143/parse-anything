episode vector [0; large; corect] and demarcated by thick outlines. The trials that precede and folow toi can be labeled as toi−1 and toi+1, respectively. (B) Trial structure. Participants viewed a randomly sampled ring with their eyes fixed, clasified its size, and then received

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 5 / 32