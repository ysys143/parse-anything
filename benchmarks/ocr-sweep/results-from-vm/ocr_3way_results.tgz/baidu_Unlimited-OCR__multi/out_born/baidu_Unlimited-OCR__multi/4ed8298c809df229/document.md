<!-- page -13 -->

CorrectiveFeedbackCSNL

![figure](assets/p1_1.png)

RESEARCH ARTICLE

Correctivefeedbackguideshumanperceptual decision-makingbyinformingabouttheworldstate ratherthanrewardingitschoice

Hyang-Jung Le1, Heseung Le1, Chae Young Lim2, Isac Rhim3, Sang-Hun Le1*

1 Department of Brain and Cognitive Sciences, Seoul National University, Seoul, South Korea, 2 Department of Statistics, Seoul National University, Seoul, South Korea, 3 Institute of Neuroscience, University of Oregon, Eugene, Oregon, United States of America visionsl@snu.ac.kr

Abstract

Corective fedback received on perceptual decisions is crucial for adjusting decision-making strategies to improve future choices. However, its complex interaction with other decision components, such as previous stimuli and choices, chalenges a principled acount of how it shapes subsequent decisions. One popular aproach, based on animal behavior and extended to human perceptual decision-making, employs “reinforcement learning,” a principle proven sucesful in reward-based decision-making. The core idea behind this aproach is that decision-makers, although engaged in a perceptual task, treat corective fedback as rewards from which they learn choice values. Here, we explore an alternative idea, which is that humans consider corective fedback on perceptual decisions as evidence of the actual state of the world rather than as rewards for their choices. By implementing these “fedback-as-reward” and “fedback-as-evidence” hypotheses on a shared learning platform, we show that the later<!-- page -12 --> outperforms the former in explaining how corective fedback adjusts the decision-making strategy along with past stimuli and choices. Our work sugests that humans learn about what has hapened in their environment rather than the values of their own choices through corective fedback during perceptual decision-making.

Introduction

Perceptual decision-making (PDM) means comiting to a proposition about an objective world state (e.g., “The temperature today is low.”). Decision-makers adjust future comitments based on what they experienced from past comitments, including what they perceived, what they chose, and what the environment gave them in return. Among these history factors, trial-to-trial corective fedbackfedback about the corectnes of a decision-makerʼs choices on a trial-to-trial basis—is widely used by experimenters to train participants on PDM tasks. Despite this clear utility of fedback and a pile of evidence for its impact on subsequent PDM behavior acros species and sensory modalities [1–1], much remains elusive about how corective fedback, in conjunction with other history factors, exerts its trialto-trial influence on subsequent decisions.

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 1 / 32

![figure](assets/p2_2.png)

<!-- page -11 -->

This figure depicts the experimental timeline of a perceptual decision-making task. The horizontal axis represents time in miliseconds, with specific intervals marked for fixation, stimulus presentation, response, and fedback. The sequence ilustrates the trial progresion, starting with a 50 ms fixation period folowed by a stimulus, a response phase, and a 1 0 ms fedback period.

PLOS BIOLOGY | Corective fedback on perceptual decisions

org/10.5281/zenodo.8427373). Al other relevant data, including numerical data underlying each figure, are within the paper and its Suporting Information files.

Funding: This research was suported by the Seoul National University (SNU) Research Grant 39202013 (to S.-H. L.), by the Brain Research Program through the National Research Foundation of Korea (NRF) funded by the Ministry of Science and Information and Comunications Technology (MSIT) Grant No. NRF-2021R1F1A1052020 (to S.-H. L.), and by the Basic Research Laboratory Program through NRF funded by MSIT Grant No. NRF-2018R1A4A1025891 (to S.-H. L.). The funders had no role in study design, data colection, analysis, the decision to publish, or manuscript preparation.

![figure](assets/p3_1.png)

<!-- page -10 -->

Competing interests: The authors have declared that no competing interests exist.

Abreviations: AICc, Akaike information criterion corected; BADS, Bayesian Adaptive Direct Search; BDT, Bayesian Decision Theory; BMBU, Bayesian model of boundary-updating; DVA, degre in visual angle; IBS, inverse binomial sampling; PDM, perceptual decision-making; PSE, point of subjective equality; RL, reinforcement learning; toi, trial of interest; VDM, value-based decision-making.

Unlike PDM, value-based decision-making (VDM) involves making choices based on decision-makersʼ subjective preferences (e.g., “chosing betwen two drinks based on their tastes”). Reinforcement learning (RL) algorithms have proven efective in explaining how past rewards afect future VDM based on eror-driven incremental mechanisms [12–18]. Intriguingly, there have ben atempts to explain the impact of past fedback on subsequent PDM by grafting an RL algorithm onto the PDM proceses [3,4,8–10]. This grafting premises that decision-makers treat corective fedback in PDM similarly to reward fedback in VDM. On this premise, this RL-grafting acount proposes that decision-makers update the value of their choice to minimize the diference betwen the expected reward and the actual reward received, caled “reward prediction eror” (red dashed arows in Fig 1A). Importantly, the amount of reward prediction eror is inversely related to the strength of sensory evidence—i.e., the extent to which a given sensory measurement of the stimulus suports the choice—because the expected

**Fig 1. Two posible scenarios for what humans learn from fedback for PDM and their distinct predictions of fedback efects.** (A) Decision-making platform for perceptual binary clasification. The gray arows depict how a sensory measurement and fedback are generated from a stimulus , which is sampled from the world, and a choice . The black arows depict the computational proces, where, for a given choice option, a decision-maker computes its expected value by multiplying the probability that the choice is corect given and the clas boundary with the value of that choice and make a choice based on . In principle, the decision-maker may update either (red dashed arows; value-updating) or world (gren dashed arows; world-updating) from . (B) Distinct sensory evidence–dependent fedback efects predicted by the value-updating and worldupdating scenarios. Acording to the value-updating scenario (left), as sensory evidence becomes stronger, increases, and acordingly, so does . As a result, reward prediction erors become smaler but remain in the direction congruent with fedback, which predicts that fedback efects on subsequent trials diminish asymptoticaly as a function of the strength of sensory evidence. Acording to the world-updating scenario (right), as sensory evidence becomes stronger, the stimulus distribution, and acordingly to, becomes shifted farther towards the stimulus in the direction counteracting the influence of fedback. As a result, the direction of fedback efects is the same as that predicted by the value-updating scenario for weak sensory evidence but eventualy reverses to the direction incongruent with fedback as sensory evidence becomes stronger.

m F S C

Qoption poption m B Voption C Qoption Voption m,C,and F poption Qoption

htps:/doi.org/10.1371/journal.pbio.302373.g01

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 2 / 32

<!-- page -9 -->

PLOS BIOLOGY _ Corective fedback on perceptual decisions value becomes low as the sensory evidence becomes weak. For example, supose a decision-maker comited to a proposition, “The temperature today is low.” Then, corect fedback to that comitment increases the value of the “low” choice since the positive reward for the “low” choice leads to the positive reward prediction eror, which indicates the ned to heighten the value of the “low” choice. Importantly, the amount of value-updating is greater when the experienced temperature is moderately cold (e.g., −2˚C, weak sensory evidence for the “low” choice) compared to when it is very cold (e.g., −15˚C, strong sensory evidence for the “low” choice) because the expected reward is smaler in the former, which leads to a greater level of reward prediction eror compared to the later (as ilustrated in the left panel of Fig 1B). A recent study [9] refered to this sensory evidence–dependent impact of fedback as “confidenceguided choice updating” based on the tight linkage betwen decision confidence and sensory evidence. This RL-grafting acount, refered to as the value-updating scenario hereinafter, apears natural given that corective fedback is typicaly provided as physical rewards such as juice or water in animal PDM experiments [4,5,8–10,19–21]. The value-updating scenario sems plausible from the perspective that PDM and VDM might share comon mechanisms [2], as sugested by some empirical studies [23,24].

Nevertheles, value-updating might not be the only route through which fedback efects transpire in PDM, especialy for humans receiving corective fedback without any physical rewards. Alternatively, decision-makers may treat fedback not as rewards but as a logical indicator of whether the proposition they comited to is true or false in the world. In this scenario, decision-makers update their belief about world statistics (i.e., stimulus distribution) by combining the information about the truenes of their choice, which is informed by fedback, and the information about the stimulus, which is informed by a sensory measurement (dashed arow from in Fig 1A). Supose you have recently arived in Canada for the first time in the winter and felt the chily air. You remarked, “The temperature today is low.” Your friend, who has lived for long in Canada, may agre or disagre with you, and this wil provide you with information on the typical temperature distribution during the Canadian winter. The incorect fedback from your friend (e.g., “Actualy, itʼs not low at al today.”) indicates that the temperature experienced today fals on the higher side of the actual distribution, making you adjust your belief about the distribution to the lower side. On the contrary, the corect fedback (e.g., “Yes, itʼs low today.”) wil lead you to adjust your belief about the distribution to the higher side. It is important to note that, besides the fedback from your friend, the temperature felt by yourself also informs you of the statistical distribution of temperature since it is a sample from that distribution. For example, if the temperature felt moderately cold (e.g., −2˚C), your belief about the temperature distribution wil only slightly shift towards the lower side. However, if it felt very cold (e.g., −15˚C), your belief wil shift towards the same lower side, but with a much greater amount, which can counteract the impact of the corect fedback on your belief (i.e., adjusting your belief to the higher side).

Therefore, acording to this alternative scenario, refered to as the word-updating scenario hereinafter, corect fedback to “The temperature today is low.” wil increase the tendency to clasify the next dayʼs temperature as “low,” just like the value-updating scenario. However, unlike the value-updating scenario,<!-- page 1 --> the world-updating scenario implies that when sensory evidence is to strong, such a tendency can be reversed, leading to a counterintuitive increase in the tendency to clasify the next dayʼs temperature as “high,” (as ilustrated in the right panel of Fig 1B). The world-updating scenario is conceptualy parsimonious because it does not require any component outside the PDM proceses, such as the RL algorithms developed in the VDM. Especialy in Bayesian Decision Theory (BDT) [25,26], which has ben providing compeling acounts for PDM behavior, world statistics is a crucial knowledge that is required to infer a world state in PDM [27–30].

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 3 / 32

PLOS BIOLOGY

Corective fedback on perceptual decisions

Here, we tested which of the 2 scenarios beter explains the efects of corective fedback—without any physical reward—on humansʼ PDM. To do so, we implemented the value-updating and world-updating scenarios into a variant of RL model [9] and a Bayesian model, respectively, and directly compared the 2 modelsʼ acountability for the fedback efects on humansʼ PDM behavior. As a PDM task, we opted for a binary clasification task, one most widely used PDM task in which decision-makers sort items into 2 discrete clases by seting a boundary since the 2 scenarios make distinct predictions about the stimulusdependent fedback efects in this task. As was described intuitively above and wil be explained rigorously later, the value-updating scenario predicts that fedback, which acts like rewards, “unidirectionaly” fosters and supreses the rewarded (corect) and unrewarded (incorect) choices, respectively, in subsequent trials while diminishing its impact asymptoticaly as sensory evidence becomes stronger, due to the reduction in reward prediction eror (the red curve in Fig 1B). By contrast, the world-updating scenario predicts that the fedback efects not just diminish but eventualy become reversed to the oposite side as sensory evidence becomes stronger, as the shift of the clas boundary towards the previous stimulus counteracts the boundary shift due to fedback (the gren curve in Fig 1B).

We found the world-updating model superior to the value-updating model in explaining human history efects of corective fedback on PDM. Criticaly, the value-updating model fails to acount for the observed stimulus-dependent fedback efects. Our findings sugest that humans are likely to treat corective fedback in PDM as logical indicators of the truenes of the proposition to which they comited, rather than as rewards, and update their knowledge of world statistics, rather than the values of their choices, based on fedback in conjunction with the other history factors—previous stimuli and choices.

Results<!-- page 2 --> Quantifyingtheretrospectiveandprospectivehistoryefectsof fedbackonbinaryclasification

To study the stimulus-dependent fedback efects in PDM, we acquired long sequences (170 trials/sequence) of binary choices ( ) many times (30 sequences/participant) from each of 30 human participants while varying the ring size ( ) and providing corective fedback ( ) (Fig 2A). On each trial, participants viewed a ring, judged whether its size is smal or large as acurately as posible while receiving fedback, which indicated by color whether the choice was corect or incorect (Fig 2B). We ensured the ring size varied suficiently—including the ones very easy and dificult for clasification—so that the 2 scenariosʼ distinct predictions on the stimulus-dependent fedback efects could be readily compared. Also, we used stochastic fedback, where corect and incorect fedback was ocasionaly given to incorect and corect choices, respectively, to cover the entire 3D space of decision-making episodes defined orthogonaly over “stimulus,” “choice,” and “fedback” ( episodes; Fig 2C; Materials and methods).

C ∈ {small,large}

S ∈ {−2,−1,0,1,2} F ∈ {correct,incorrect}

# 5 × 2 × 2 = 20

To rigorously evaluate the corespondence betwen model prediction and human behavior, we quantified the history efects in both retrospective and prospective directions of time, as folows (Fig 2D). First, we localized the trials in which a PDM episode of interest ocured (trial of interest, toi) and stacked the trials that preceded (the retrospective block of trials, toi−1) and those that folowed (the prospective block of trials, toi+1) the toi. Second, we derived the 2 psychometric curves from the retrospective and prospective blocks of trials, respectively, and fit the cumulative normal distribution function to these curves to estimate the point of subjective equality (PSE) measures, which have previously ben used [19– 21] and known to reliably estimate the history-dependent choice biases in PDM [31]. Thus, the PSEs of the retrospective

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 4 / 32

PLOS BIOLOGY Corective fedback on perceptual decisions

A toi = [0; large; corect] # 170 trials/run

B binary clasification of ring size Stimulus Choice Fedback

C

D

S ∈ {−2,−1,0,1,2} C ∈ {small,large} F ∈ {correct,incorrect}

**Fig 2. Experimental design and definition of retrospective and prospective history efects.** (A) A chain of PDM episodes over a single sequence of trials. Each trial sequence consists of 170 column vectors of PDM episode [stimulus; choice; fedback]. In this example, the trial of interest (toi) is characterized by an<!-- page 0 --> episode vector [0; large; corect] and demarcated by thick outlines. The trials that precede and folow toi can be labeled as toi−1 and toi+1, respectively. (B) Trial structure. Participants viewed a randomly sampled ring with their eyes fixed, clasified its size, and then received

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 5 / 32 fedback indicating whether the clasification was corect or incorect by the color around the fixation. (C) The 3D state space of the PDM episodes in the experiment. The example episode of toi in (A) is marked by the black cube. (D) Definition of retrospective and prospective history efects. As ilustrated in (A) and (C), for any given episode of toi, al the trials labeled with toi−1 and toi+1 are stacked and used to derive the psychometric curves, respectively. The PSEs estimated for the toi−1 and toi+1 psychometric curves quantify the retrospective and prospective history efects, respectively. In this example, the black and gray curves were defined for toi = [0; large; corect] and toi = [0; smal; corect], respectively, with circles and bars representing the mean and SEM acros 30 participants, respectively. The data underlying this figure (D) can be found in S1 Data. htps:/doi.org/10.1371/journal.pbio.302373.g02

<!-- page -5 -->

![figure](assets/p9_1.png)

<!-- page 2 -->

![Fig 2](assets/p10_1.png)

and prospective trials quantify the choice biases that exist before and after the PDM episode of interest ocurs, respectively, with negative and positive values signifying that choices are biased to large and smal, respectively.

Decision-makingprocessesforbinaryclassification

As a first step of evaluating the value-updating and world-updating scenarios, we constructed a comon platform of decision-making for binary clasification where both scenarios play out. This platform consists of 3 procesing stages (Fig 3A). At the stage of “perception,” the decision maker infers the clas probabilities, i.e., the probabilities that the ring size (S) is larger and smaler, respectively, than the clas boundary (B) given a noisy sensory measurement (m), as folows: where CL stands for the clas variable with the 2 (smal and large) states.

At the stage of “valuation,” the decision-maker forms the expected values for the 2 choices ( and ) by multiplying the clas probabilities by the learned values of the coresponding choices ( p(CL = large) = p(S > B|m) = ∫ p(CL = small) = 1 − p(CL = large),

Qlarge Qsmall Vlarge Vsmall and ) as folows:

Qlarge = p(CL = large) × Vlarge; Qsmall = p(CL = small) × Vsmall.

<!-- page 3 -->

Lastly, at the stage of “decision,” the decision-maker comits to the choice whose expected value is greater than the other. In this platform, choice bias may originate from the perception or valuation stage. Supose the decision-makerʼs belief about size distribution at the perception stage is not fixed but changes depending on previous PDM episodes (Fig 3B, top). Such changes lead to the changes in PSE of the psychometric curve because the clas probabilities change as the clas boundary changes (Fig 3B, botom). Alternatively, supose the decision makerʼs learned values of the choices are not fixed but change similarly (Fig 3C, top). These changes also lead to the changes in PSE of the psychometric curve because the expected values change as the choice values change (Fig 3C, botom).

Thebelief-basedRLmodel

To implement the value-updating scenario, we adapted the belief-based RL model [9] to the curent experimental setup. Here, fedback acts like a reward by positively or negatively reinforcing the value of choice ( ) with the deviation of the reward outcome (r) from the expected value of that choice (

Vlarge(small) Qlarge(small)

), as folows:

Vlarge(small) ← Vlarge(small) + αδ;

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 6 / 32

<!-- page -2 -->

![Fig 3](assets/p12_1.png)

**Fig 3. Implementation of the value-updating and world-updating scenarios into computational models in a comon PDM platform.** (A) Computational elements along the 3 stages of PDM for binary clasification. At the “perception” stage, the probabilities that the clas variable takes its binary states smal and large— and —are computed by comparing the belief on the stimulus size against the belief on the clas boundary —the mean of the belief on stimulus distribution in the world . At the “valuation” stage, the outcomes of the perception stage are multiplied by the learned values to produce the expected values . At the “decision” stage, the choice with the greater expected value is selected. (B, C) Ilustration of 2 potential origins of choice biases, one at the “perception” stage (B) and the other at the “valuation” stage (C). The color indicates the direction of choice bias (yelow for bias to large; black for no bias; blue for bias to smal). (D, E) Ilustration of the architectures (left panels) and predictions on the stimulus-dependent fedback efects (right panels) of BMBU (D) and the belief-based RL model (E). In the left panels, the dashed arows

PLOS BIOLOGY | Corective fedback on perceptual decisions p(CL = large) p(CL = small) p(S|m) B p(S)

Vs Qs<!-- page 8 --> represent the ways the history factors (fedback and stimulus) exert their contribution to choice bias. In the right panels, , which quantifies the choice bias in the trials folowing a certain PDM episode at , is ploted as a function of the stimulus size at . The color indicates the direction of choice bias, as in (B) and (C).

PSEtoi+1 toi = [0;large;correct] toi

htps:/doi.org/10.1371/journal.pbio.302373.g03 δ = r − Qlarge(small) = r − p(CL = large(small)) × Vlarge(small), α δ r where , , and are the learning rate, the reward prediction eror, and the reward, respectively. The state of fedback determines the value of : for corect; for incorect. Note that has the statistical decision confidence at the perception stage, i.e., , as one of its 3 arguments. As stresed by the authors who developed this algorithm [9], this feature makes the strength of sensory evidence—i.e., statistical decision confidence—modulate r r = 1 r = 0 δ p(CL = large(small))

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 7 / 32 the degre to which the decision-maker updates the chosen value based on fedback (Fig 3E, left). Hence, this belief (confidence)-based modulation of value-updating underlies the stimulus-dependent fedback efects: The amount of fedback efects decreases as sensory evidence becomes stronger since the reward prediction eror decreases as a function of , which is proportional to sensory evidence (Fig 3E, right).

p(CL = large (small))

TheBayesianmodel ofboundary-updating(BMBU)

To implement the world-updating scenario, we developed BMBU, which updates the clas boundary based on the previous PDM episode in the framework of BDT. Specificaly, given “a state of the clas variable that is indicated jointly by fedback and choice,” CL, and “a noisy memory recal of the sensory measurement (which wil be refered to as ‘mnemonic measurementʼ hereinafter),” , BMBU infers the mean of the size distribution (i.e., clas boundary), , by updating its prior belief about , , with the likelihod of , , by inverting its learned generative model of how and CL are generated (Fig 3D, left; Eqs 3–6 in Materials and methods for the detailed formalisms for the learned generative model), as folows:

B B p(B) B p(m′,CL|B) m′ p(B|m′,CL) ∝ p(m′,CL|B)p(B) ≡ p(m′,C,F|B)p(B) :

This inference uses multiple pieces of information from the PDM episode just experienced, including the mnemonic measurement, choice, and fedback, to update the belief about the location of the clas boundary (refer to Eqs 8–14 in Materials and methods for more detailed formalisms for the inference). In what folows, we wil explain why and how this inference leads to the specific stimulus-dependent fedback efects predicted by the world-updating scenario (Fig 3D, right), where world knowledge is continuously updated.

<!-- page 0 -->

Supose a decision-maker curently believes that the size distribution is centered around 0. Let us first consider a case where the decision-maker experiences a PDM episode with an ambiguous stimulus: The ring with size 0 is presented and produces a sensory measurement that is only slightly greater than 0 (through the stochastic proces where is generated from ; Eq 5), which leads to the large choice since the infered from such is greater than the center of the size distribution (Eqs 4 and 7), and then folowed by corect fedback. BMBU predicts that after this PDM episode, the decision-maker wil update the belief about the size distribution by shifting it towards the smaler side. Hence, the choice in the next trial wil be biased towards the larger option, resulting in a negatively biased PSE for the psychometric curve defined by the trials folowing the episode of interest. This is because the impact of the mnemonic measurement on boundary-updating is minimal, whereas that of the informed clas variable is substantial. After the above episode, the decision-makerʼs noisy mnemonic measurement is also likely to be slightly larger than 0 since is an unbiased random sample of the sensory measurement (Eq 6). Thus, the impact of on boundary updating is minimal because is close to 0 and thus only slightly atracts the clas boundary. On the contrary, the impact of the informed state of the clas variable on boundary updating is relatively substantial, pushing the clas boundary towards the regime consistent with the informed state of (Eqs 9–12), which is the smaler side. As a result, the clas boundary is negatively (towards smal-side) biased, which leads to the negative bias in the PSE of the psychometric curve defined from the trials folowing the episode of interest (as depicted by the left (yelow) regime in the plot of Fig 3D).

m m S m′ m m′ m′

CL

CL

Next, to apreciate the stimulus-dependent nature of fedback efects in the world-updating scenario, let us consider another case where the decision-maker experiences a PDM episode with an unambiguous stimulus: The ring with size 2 is presented and produces a sensory measurement that fals around 2, which leads to the large choice and then folowed by corect

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 8 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions

fedback. After this episode, as in the previous case with an ambiguous stimulus, the informed state of the clas variable ( ) shifts the clas boundary to the smaler side. However, unlike the previous case, the impact of the mnemonic measurement on boundary-updating, which is likely to be around 2, is substantial, resulting in a shift of the boundary towards the far larger side. Consequently, the clas boundary becomes positively (towards-large-side) biased. Here, the mnemonic measurement and the informed state of the clas variable exert conflicting influences on boundary updating. Since the mnemonic measurement increases as the stimulus size grows (e.g., ), the relative impact of the mnemonic measurement on boundary-updating is increasingly greater as the stimulus size grows, eventualy overcoming the counteracting influence of the informed state of the clas variable (S1 Fig). As a result, the bias in the clas boundary is initialy negative but is progresively reversed to be positive as the stimulus size grows, which leads to the bias reversal in the PSE of the psychometric curve defined from the trials folowing the episode of interest (as depicted by the right (blue) regime in the plot of Fig 3D).

CL = large

S = 0 → 1 → 2<!-- page 10 --> We stres that this “stimulus-dependent bias reversal” is a halmark of the world-updating scenarioʼs prediction of the history efects in PDM. Specificaly, the direction of bias reversal is always from smal to large as long as the fedback in conjunction with the choice indicates (e.g.,

CL = small or

{S = 0 → −1 → −2,C = small,F = correct} {S = 0 → −1 → −2,C = large,F = incorrect}

) and always from large to smal as long as the fedback in conjunction with the choice indicates (e.g.,

CL = large {S = 0 → 1 → 2,C = large,F = correct} {S = 0 → 1 → 2,C = small,F = incorrect} or ). Criticaly, the value-updating scenario does not predict the bias reversal (Fig 3E, right). It predicts that the fedback efects only asymptoticaly decrease as a function of sensory evidence but never switch to the other direction. This is because the decision confidence, , only modulates the amount of value-updating but never changes the direction of value-updating.

p(CL = large(small))

Exantesimulationofthefeedbackeffectsunderthe2 scenarios

Above, we have conceptualy explained why and how the 2 scenarios imply the distinct paterns of stimulus-dependent fedback efects. Though this implication sems intuitively aparent, it must be confirmed under the experimental seting of the curent study. Moreover, there are god reasons to expect any history efect to exhibit complex dynamics over trials. First, sensory and mnemonic measurements are subject to stochastic noises, which propagates through decision-making and value/boundary-updating proceses to subsequent trials (e.g., a sensory measurement that hapens to fal on a relatively smal side is likely to lead to a smal choice, which afects the subsequent value/boundary-updating proces, and so on). Second, provided that any deterministic value/boundaryupdating proceses are presumed to be at work, the PDM episode on a given trial must, in principle, be probabilisticaly conditioned on the episodes in past trials (e.g., the curent smal choice on the ring of is likely to have folowed the previous episodes leading to “boundary-updating in the large direction” or “positive value-updating of the smal choice”). Third, 2 steps of deterministic value/boundary-updating ocur betwen what can be observed at and at (as indicated by the psychometric curves in Fig 4A), once folowing the episode at ( in Fig 4A) and next folowing the episode at ( in Fig 4A). Thus, the diferences betwen the retrospective and prospective history efects should be construed as reflecting not only but also . The nuanced impacts of this hi den updating on the history efects must be complicated and thus be inspected with realistic simulations. Further, considering that these multiple stochastic and deterministic events interplay to create diverse temporal contexts, history efects are suposed to reveal themselves in multiplexed dynamics.

S = 0 toi − 1 toi + 1 toi − 1 Utoi−1 toi Utoi

Utoi Utoi−1

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 9 / 32

<!-- page 2 -->

![Fig 4](assets/p16_1.png)

**Fig 4. Ex ante simulation results for the PDM episodes with corect fedback.** (A) Ilustration of how the retrospective (left) and prospective (right) history efects relate to the value updates and boundary updates (botom) ocuring over the trials overarching the trial of interest. While the updating ocurs latently at every trial (as indicated by , , ), its behavioral consequences are observable only at the preupdating phase at and . (B-D) The observable retrospective (B) and prospective (D) history efects and latent value-updating proceses (C) for the value-updating model agent. (C) Since corect fedback is treated as a positive reward, the chosen value is updated positively while the amount of value-updating varies depending on the strength of sensory evidence, as indicated by the length of the vertical arows in diferent colors (weak sensory evidence, pale blue; strong sensory evidence, dark blue). The short horizontal bars and arow heads of the colored arows indicate the chosen values before and after , respectively. (E-G) The observable retrospective (E) and prospective (G) history efects and latent boundary-updating proceses (F) for the world-updating model agent. (F) Since corect fedback is treated as a logical indicator of the true state of the clas variable (i.e., the true inequality betwen the clas boundary and the stimulus), the clas boundary shifts as a joint function of fedback and sensory evidence, where the boundary shift due to sensory evidence (solid black arows) counteracts that due to fedback (doted black arows), as indicated by the arows in diferent colors (weak sensory evidence, pale blue; strong sensory evidence, dark blue). The short vertical bars and arow

PLOS BIOLOGY | Corective fedback on perceptual decisions

Utoi−1 Utoi Utoi+1 toi − 1 toi + 1<!-- page 2 --> heads of the colored arows at the top indicate the clas boundary before and after , respectively. (H) Juxtaposition of the diferences betwen the retrospective and prospective history efects displayed by the 2 model agents. (C, F) The contributions of both sensory and fedback evidence are indicated by Sevidence and F-evidence, respectively. (B, D, E, G) Data points are the means and SEMs acros the parameter sets used in ex ante simulations (se Materials and methods). The data underlying this figure (B, D, E, G, H) can be found in S1 Data.

htps:/doi.org/10.1371/journal.pbio.302373.g04

Hence, we simulated ex ante the 2 models over a reasonable range of parameters by making the model agents perform the binary clasification task on the sequences of stimuli that wil be used in the actual experiment (Table A in S1 Apendix, S4 Fig, and Materials and methods). The simulation results confirmed our intuition, as sumarized in Fig 4, which shows the retrospective and prospective history efects for the PDM episodes with corect fedback. Notably, the retrospective history efects indicate that both value-updating and world-updating agents were already slightly biased to the choice they are about to make in the—folowing—toi (Fig 4B and 4E). One readily intuits that such retrospective biases are more pronounced when

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 10 / 32

![Fig 5](assets/p17_1.png)

**Fig 5. Ex ante simulation results for the PDM episodes with incorect fedback.** The format is identical to that in Fig 4. The data underlying this figure (B, D, E, G, H) can be found in S1 Data.

<!-- page 5 -->

PLOS BIOLOGY Corective fedback on perceptual decisions

htps:/doi.org/10.1371/journal.pbio.302373.g05 conditioned on the toi with weak sensory evidence because the stochastic bias consistent with the choice that would be made in the toi is required more in those trials. This testifies to the presence of the complex dynamics of history efects discused above and is also consistent with what has ben previously observed (e.g., se Fig 2 of the previous study [9]). Importantly, in line with our conceptual conjecture (Fig 3D and 3E), the 2 agents evidently disagre on the prospective history efects. While the valueupdating agent always exhibits the fedback-congruent bias but never reverses the direction of bias, the world-updating agent shows the fedback-congruent bias after viewing the ambiguous stimulus but progresively reversed the direction of bias as the stimulus evidence suporting the decision becomes stronger (Fig 4C, 4D and 4F–4H).

Next, Fig 5 sumarizes the history efects for the PDM episodes with incorect fedback. The retrospective history efects show that both agents exhibit the choice bias consistent with the choice they wil make next trial, as in the case for corect fedback, but the amounts of bias are much greater compared to those in the corect-fedback condition (Fig 5B and 5E). These pronounced retrospective efects conditioned on the incorect-fedback episodes are intuitively understod as folows: The valueupdating agentʼs value ratio or the world-updating agentʼs clas boundary was likely to be somehow “unusualy and strongly” biased before the toi, given that they make an incorect—thus “unusual”—choice in the toi. Suporting this intuition, the

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 20231 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions retrospective bias increases as sensory evidence increases, since the prior value ratio or clas boundary must be strongly biased to result in that particular incorect choice despite such strong sensory evidence. Importantly, despite these large retrospective biases, the prospective history efects indicate that both agents adjust their value and clas boundary, respectively, in their own maners identical to those for the corect-fedback episodes (Fig 5C, 5D, 5F and 5G). Thus, as in the case of the corect-fedback episodes, the direction reversal is displayed only by the world-updating agent, but not by the valueupdating agent (Fig 5H).

In sum, the ex ante simulation confirmed that the bias reversal of the stimulus-dependent fedback efects ocurs only under the world-updating scenario but not under the value- updating scenario, regardles of the (corect or incorect) states of fedback. The simulation results also confirmed that, with the curent experimental seting, we can empiricaly deter- mine which of the 2 scenarios provides a beter acount of fedback efects.

<!-- page 2 -->

Evaluatingthe2scenariosforthegodnessoffitto humandecision-makingdata

![Fig 6](assets/p19_1.png)

**Fig 6. Model godnes of fit to human choice behavior.** (A) Specification of the models constituting the model space. The color labels also aply to the rest of the panels in (B-D). (B, C) Model comparisons in godnes of fit in terms of log likelihod (B) and AICc (C). The height of bars represents the acrosparticipant average diferences from the godnes of fit measures of the Base model (N = 30, mean ± SEM). Both diference measures indicate a beter fit for higher values. Dashed lines in purple (Hybrid model) and gray (Fixed model) provide the reference points for evaluating the value-updating and worldupdating modelsʼ acountability of the trial-to-trial choice variability (se main text for their exact meanings). Pairwise model comparisons were performed using paired one-tailed t tests (asterisks indicate significance: , P < 0.05; , P < 0.05; , P < 10 ) (D) Model comparisons in the hierarchical Bayesian model selection measures. Height of bars, expected posterior probabilities; eror bars, standard deviation of posterior probabilities. Dots marked with short dashes, protected excedance probability. Dashed lines, chance level (p = 0.2), indicating the probability that a model is favored over others in describing the data by random chance. Bayesian omnibus risk (BOR), the estimated probability that observed diferences in model frequencies may be due to chance, is reported (BOR = 1.7636 × 10 ). The data underlying this figure (B, C, D) can be found in S1 Data.

Having confirmed the distinct predictions of the 2 scenarios via ex ante simulation, we evalu- ated their godnes of fit to human data. As points of reference for evaluation in the model space (Fig 6A), we created 3 reference models. The “Base” model sets the clas boundary at the

htps:/doi.org/10.1371/journal.pbio.302373.g06

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 12 / 32

PLOS BIOLOGY Corective fedback on perceptual decisions unbiased value ( ) and does not update any choice values, thus incorporating neither arbitrary choice preference nor adaptive updating. The “Fixed” model is identical to the Base model except that it incorporates arbitrary choice preference by fiting the constant clas boundary to the data. The “Hybrid” model incorporated both value-updating and world- updating algorithms. We quantified the modelsʼ ability to predict human clasification choices using log likelihod (Fig 6B) and compared their abilities using the Akaike information crite- rion corected for sample size (AICc [32]; Fig 6C). The Fixed modelʼs performance relative to the Base modelʼs (gray dashed lines in Fig 6B and 6C) reflects the fraction of choice variability that is atributed to arbitrary choice prefer- ence. On the other hand, the Hybrid modelʼs performance relative to the Base modelʼs (purple dashed lines in Fig 6B and 6C) reflects the maximum fraction of choice variability that can be potentialy explained by either the value-updating model, the world-updating model, or both. Thus, the diference in performance betwen the Hybrid and Fixed models (the space spaned betwen the gray and purple dashed lines in Fig 6B and 6C) quantifies the meaningful fraction of choice variability that the 2 competing models of interest are expected to capture. Prior to model evaluation, we confirmed that the 2 competing models (the value-updating and world- updating models) and 2 reference models (the Base and Hybrid models) are empiricaly distin- guishable by carying out a model recovery test (S3 Fig).

B = 0

With this target fraction of choice variability to be explained, we evaluated the 2 competing models by comparing them against the Fixed and Hybrid modelsʼ performances while taking into acount model complexity with AICc. The value-updating model was moderately beter than the Fixed model (paired onetailed t test, , ) and substantialy worse than the Hybrid model (paired onetailed t test, , ) and the world-updating model (paired one-tailed t test, , ). By con- trast, the world-updating model was substantialy beter than the Fixed model (paired one- tailed t test, , ) but not significantly beter than the Hybrid model (paired one-tailed t test, , ). These results indicate (i) that the world-updating model is beter than the value-updating model in acounting for the choice variability and (i) that ading the value-updating algorithm to the worldupdating algorithm does not improve the acountability of the choice variability.

t(29) = −2.8540 P = 0.0039 t(29) = 7.6996 P = 8.6170 × 10−9 t(29) = 8.3201 P = 1.7943 × 10−9 t(29) = −10.3069 P = 1.6547 × 10−11 t(29) = −1.0742 P = 0.1458

To complement the above pairwise comparisons, we tok the hierarchical Bayesian model selection aproach [3–35] using AICc model evidence, to ases how probable it is that each of the 5 models prevails in the population (expected posterior probability; vertical bars in Fig 6D) and how likely it is that<!-- page 6 --> any given model is more frequent than the other models (pro- tected excedance probability; dots with horizontal bars in Fig 6D). Both measures corobo- rated the outcomes of the pairwise comparisons: The world-updating model predominated in expected posterior probability (0.592) and protected excedance probability (0.8938).

In sum, the world-updating scenario was superior to the value-updating scenario in pre- dicting the choice behavior of human participants performing the binary clasification task.

Expostsimulationofthefeedbackeffectsunderthe2 scenarios

The godnes of fit results sumarized above simply indicate that the world-updating model is beter than the value-updating model in predicting the trial-to-trial variability in choice behavior while taking into acount model complexity. Our study aims to examine whether these 2 competing models of interest can acount for the stimulus-dependent fedback efects observed in human decision-makers. To do so, we caried out ex post simulations based on the godnes of fit results [36] by testing whether the valueupdating and world-updating models can reproduce the observed stimulus-dependent fedback efects.

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 13 / 32

<!-- page 10 -->

![Fig 7](assets/p22_1.png)

**Fig 7. Ex post simulation results.** (A-C) Retrospective (left columns), prospective (mi dle columns), and subtractive (right columns) history efects in PSE for the human (A), value-updating (B), and worldupdating (C) decision-makers. Top and botom rows in each panel show the PSEs asociated with the toi episodes involving corect and incorect fedback. Symbols with eror bars, mean ± SEM acros 30 decision-makers. Se S5 Fig for the results from the Hybrid model decision-makers. (D) Frequency of PDM episodes in the human data (mean and SD acros participants). (E, F) Maps of significant deviations of the value-updating (E) and world-updating (F) model agents from the human decision-makers in the retrospective (left) and prospective (right) history efects. Gray and black cels of the maps mark the insignificant and significant deviations (paired two-tailed t tests with the Bonferoni corection for multiple comparisons). Empty cels are data points with NaN values due to insuficient trials. The data underlying this figure (A, B, C, D, E, F) can be found in S1 Data.

PLOS BIOLOGY | Corective fedback on perceptual decisions

htps:/doi.org/10.1371/journal.pbio.302373.g07<!-- page 1 --> The ex post simulation was identical to the ex ante simulation except that each decision-makerʼs best-fit model parameters were used (Table B in S1 Apendix; Materials and methods). We asesed how wel the models reproduce the human history efects of fedback in 2 diferent ways. First, we compared the models and the humans similarly to the ex ante simulation (Fig 7A–7C). We included the PDM episodes with nonveridical fedback (symbols with doted lines in Fig 7A–7C), though those episodes infrequently ocured (12.09 ± 0.02% (mean ± SEM) out of total toi episode trials; bars with doted outlines in Fig 7D). As a result, we inspected the retrospective and prospective history efects, and their diferences, for al the posible combinations of “stimulus,” “choice,” and “fedback” (20 PDM episodes in total), which resulted in a total of 60 PSE pairs to compare. The PSEs simulated by the world-update model closely matched the human PSEs, in both patern and magnitude (Fig 7A and 7C), whereas those by the valueupdate model substantively deviated from the human PSEs (Fig 7A and 7B). The statistical comparison (paired two-tailed t tests with Bonferoni corection)

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 14 / 32 indicates that the value-updating modelʼs PSEs significantly deviated from the coresponding human PSEs for almost half of the entire pairs (29 out of 60 pairs), whereas none of the world-updating modelʼs PSEs significantly difered from the human PSEs (0 out of 60 pairs). Notably, most mismatches ocured because the value-updating model does not reverse the direction of fedback efects as sensory evidence becomes stronger while humans do so (compare the third columns of Fig 7A and 7B).

Second, we compared the models and the humans in the probability distribution of retrospective and prospective episodes conditioned on each episode of (Fig 7D–7F). This comparison alows us to ases the modelsʼ reproducibility not just for fedback efects but also for the history efects in general and to explore the origin of the value-based modelʼs failure. By colapsing al the preceding and folowing trials onto each of the 20 episodes (the columns of Fig 7E and 7F) and computing their probability distributions acros—again—the 20 types of and 20 types of episodes (the rows of Fig 7E and 7F), respectively, we could create 40 joint-probability cels.

toi toi toi − 1 toi + 1

We caried out repeated tests with Bonferoni corection to se where the model-human mismatches ocur (data were mising for a few cels—mostly those including nonveridical fedback episodes, as indicated by the empty cels in Fig 7E and 7F, because those episodes were to rare (Fig 7D) to ocur for al participants). For the remaining cels, the world-updating model showed a remarkable level of corespondence with the humans, deviating from the humans at only 2 cels (out of 790 cels, 0.25%; Fig 7F). By contrast, the value-updating model failed to match the humans for 94 cels (out of 792 cels,

1.87%; Fig 7E). Here, the mismatches ocured systematicaly: They were frequent when the preceding episode defining any given cel (i.e., episodes at for the retrospective cels or episodes at for the prospective cels) was featured with strong sensory evidence (as indicated by the arows in Fig 7E). This systematic deviation precisely reflects the incapability of the value-updating model to reverse the direction of fedback efects as sensory evidence strengthens.

toi − 1 toi

In sum, the stimulus-dependent history efects of fedback observed in humans could be reproduced by the world-updating scenario but not by the value-based scenario.

<!-- page 2 -->

Discussion

Here, we explored the 2 posible scenarios for what humans learn from corective fedback in a PDM task. We implemented the value-updating scenario with the belief-based RL model [9,10], originaly developed to acount for the stimulus-dependent efects of reward fedback on animalsʼ PDM. As an alternative, we implemented the world-updating scenario with BMBU, where decision-makers continuously update their internal knowledge about stimulus distribution based on sensory measurements and corective fedback. The later excels over the former in predicting the choice behavior and reproducing the stimulus-dependent fedback efects in human PDM, sugesting that humans update their knowledge about world statistics upon corective fedback for PDM.

Given RL modelsʼ suces in VDM and the presence of physical rewards, it is not surprising for the beliefbased RL model to be considered as an acount of the fedback efects in animalsʼ PDM. The original work [9] suported this model using 6 datasets, including 1 human dataset [37]. However, the curent work indicates that the way humans learn from corective fedback —without any physical or monetary reward—in PDM deviates from the value-updating scenario. The critical deviation ocured for the PDM episodes with strong sensory evidence: Past corect fedback should, albeit weakly, reinforce the choice made in the past acording to the value-updating scenario, whereas humans made the oposite choice more frequently. In fact, the human dataset previously analyzed in the study [9] exhibits the same deviations (se their PLOS BIOLOGY

Corective fedback on perceptual decisions

Fig 8C and 8D). When this dataset was analyzed in our way, it displayed the paterns almost identical to those of our dataset (S7A Fig). For that mater, another published human dataset [31] substantialy deviated from the value-updating scenario (S7B Fig). We remain cautious about the posibility that even animals may demonstrate such deviations as wel. However, this posibility sems worth exploring though, given that the main dataset from the 16 rats engaged in an olfactory PDM task also exhibited paterns similar to those found in humans when corected for the bias present in previous trials (se Fig 2i in the study [9]). Notably, in these studies [9,31,37], the clas boundary existed either implicitly (e.g., a perfectly balanced odor mixture [9]) or explicitly (e.g., a reference stimulus presented in another interval [37]). This sugests the posibility that the bias reversal of fedback efects may be a general phenomenon that can be observed in diverse types of binary clasification tasks. However, further empirical tests are required to confirm this posibility. The bias reversal of fedback efects should not be treated lightly as a nuisance because any variant of the RL algorithm canot reverse the direction of reinforcement in principle, as demonstrated in our work and in the modeling results of the same study [9] (shown in their Fig 3). By contrast, BMBU provides a principled acount of these efects by treating corect and incorect fedback as what they suposedly mean, a teaching signal indicating the true state of the clas variable.

<!-- page 2 -->

To be sure, the idea of shifting the decision or clas boundary toward past stimuli per se is not new and has ben previously hypothesized [38,39] or implemented into various models [40–4]. However, BMBU goes beyond these eforts by ofering a normative formalism of incorporating corect and incorect fedback as evidence for the clas boundary such that it has an equal foting as sensory evidence in PDM tasks. This integration of fedback and sensory evidence within the framework of BDT advances the curent computational acount of the history efects because it adreses the history factors in the complete dimensions of PDM (“stimulus,” “choice,” and “fedback”), which is important given the multiplexed nature of history efects emphasized by prior studies [8–1,31,45]. Our modeling work joins recent computational and empirical eforts of incorporating fedback in the normative evidence acumulation model [6,46], a framework comonly employed in various clasic PDM tasks, such as a random-dot motion task. Furthermore, a study on ratsʼ binary clasification behavior has shown that rats can use information about the corect clas state (refered to as “second-order prior” by the authors) by integrating their own choices with fedback (reward outcome) and that the population neural activity in the orbitofrontal cortex represents this information [1]. Together with these studies, our work suports a general view that decision-makers use corective fedback as evidence for updating their world knowledge pertinent to the PDM task engaging them. Having mentioned the general view on the role of fedback in human PDM, future eforts are neded to further verify the stimulus-dependent fedback efects under various sensory modalities and PDM tasks.

Previously, the so-caled “Ana Karenina” acount was presented to describe the semingly idiosyncratic incorect fedback efects [9]. The Ana Karenina acount leaves the crucial aspect of fedback efectsthe diferent consequences of corect versus incorect fedback—unexplained. Since the belief-based RL model predicts the specific patern of fedback efects for incorect trials, as shown via ex ante simulation, endorsing the Ana Karenina acount admits that the belief-based RL model fails to acount for the efects of incorect fedback observed in animals. For that mater, past studies on the history efects in PDM paid litle atention to incorect trials because they are, owing to their infrequency, considered to noisy and unreliable to be properly analyzed. By contrast, BMBU acounts for the efects of fedback in a principled way, regardles of whether the fedback is corect or incorect. Furthermore, BMBU explains why the fedback efects apear diferent betwen the corect and incorect trials on the surface (compare the prospective history efects betwen Figs 4 and 5): The corect

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 16 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions and incorect trials share the same deterministic boundary-updating proces but had diferent histories of their own stochastic events, which led to corect versus incorect choices, respectively. As mentioned earlier, the history efects are dynamic and multiplexed in nature. This cals for an efort to establish a rigorous framework to probe behavioral data for the history efects. Several recent studies made such eforts by taking various aproaches, yet al emphasizing the presence of distinct sources of biases. One study [47] asumed 2 sources with difering time scales and tok a regresion-based aproach to separate their influences on choice bias by incorporating them as independent regresors to predict<!-- page 6 --> choices. Another group of researchers [6,9] also noted the presence of slow fluctuations and raised a concern about the conventional practice of inspecting only the prospective history efects because nonsystematic slow fluctua- tions in the decision-making strategy may cause the observed efects. This group dealt with this concern by subtracting the retrospective history efects from the prospective ones. A more recent study [48] shared this concern but disagred about its remedy by showing that the subtraction method canot fairly recover diverse systematic updating strategies. Alternatively, they tok a model-based aproach to separate any given updating strategy from random drifts in decision criteria. We acknowledge the importance of the eforts by these studies and share the same concern. But, we emphasize that BMBU sucesfuly reproduced human history efects in both directions of time without incorporating any nonsystematic components arising from random drifts. BMBUʼs concurent reproduction of the retrospective and prospective history efects was confirmed not just for the sumary statistics (the PSEs in Fig 7C) but also for the individual data points spaning almost the entire space of PDM episode pairs (Fig 7F). This sugests that it is an empirical mater of whether the decision criterion slowly drifts or not, raising another concern that systematic history efects might be explained away as non- existing slow drifts. In this sense, we propose that researchers should treat the retrospective history efects not as a baseline or control condition but as what must be explained, the phe- nomenon equaly important as the prospective history efects, before resorting to any nonsys- tematic sources. We believe that such a treatment is the way historians treat historical events [49] and that our aproach showcases its one rigorous example.

Materialsandmethods

Ethicsstatement

The study protocol was aproved by the Seoul National University Institutional Review Board (No. 1310/ 01-020). Al the experiments were conducted in acordance with the principles expresed in the Declaration of Helsinki. Al participants gave prior writen informed consent to participate in the experiments.

Participants

Al participants (13 females and 17 males, aged 18 to 30 years) were recruited from the Seoul National University (SNU) comunity and were compensated aproximately \$10/h.

<!-- page 7 -->

Procedure

Stimuli. The stimulus was a thin (.07 degre in visual angle (DVA), Gausian-noise fil- tered, black-andwhite ring flickering at 20 Hz on a gray luminance background. On each trial, a fixation first apeared for 0.5 s on average (fixation duration uniformly jitered from 0.3 s to 0.7 s on a trial-to-trial basis) before the onset of a ring stimulus. Five diferent ring sizes

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 17 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions

(radi of 3.84, 3.92, 4.0, 4.08, 4.16 DVA, denoted by −2, −1, 0, 1, 2, respectively, in the main text) were randomized within every block of 5 trials.

Task. Participants performed a binary clasification task on ring size with trial-to-trial corective fedback. Each individual participated in 5 daily sesions, each consisting of 6 runs, each consisting of 170 trials, ended up performing a total of 5,10 trials. In any given trial, par- ticipants viewed one of the 5 rings and indicated its clas (smal or large) within 1.2 s after stim- ulus onset by presing one of the 2 keys using their index and mi dle fingers. The asignment of computer keys for smal and large choices alternated betwen sucesive sesions to prevent any unwanted choice bias posibly asociated with finger preference. The response period was folowed by a fedback period of 0.5 s, during which the color of the fixation mark informed the participants of whether their response was corect (gren) or not (red). In case no response had ben made within the response period, the fixation mark turned yelow, reminding partic- ipants that a response must be made in time. These late-response trials comprised 0.5418% of the entire trials acros participants and were included in data analysis. Meanwhile, the trials on which a response was not made at al comprised 0.0948% of the entire trials. These trials were excluded from analysis and model fiting. As a result, the number of valid trials per participant ranged from 5,073 to 5,10 with an average of 5,095.2 trials. Before each run, we showed par- ticipants the ring stimulus of the median size (4.0 DVA in radius) on the scren for 15 s while instructing them to use that ring as a reference for future trials, i.e., to judge whether a test ring is smaler or larger than this reference ring. This procedure was introduced for the purpose of minimizing any posible caryovers from the belief they formed about the clas boundary in the previous sesion. Participants were encouraged to maximize the fraction of corect trials.

Fedback manipulation. We provided participants with stochastic fedback using a “vir- tual” criterion sampled from a normal distribution . was always fixed at 1.28 throughout the entire runs. In each run, was initialy (up to 40 to 50 trials) set to 0 and then to one of the 3 values (

N(μTrue,σTrue) σTrue μTrue

) with the equal proportion (10 runs for each value) for the rest of trials. The stochastic fedback was introduced this particular way to create PDM episodes with (ocasional) nonveridical fedback while mimicking a real-world situation where references are slightly noisy and biased in an unoticeable maner.

μTrue = {−0.4,0,0.4}<!-- page 9 --> Dataanalysis

For any given PDM episode at a toi, we quantified the retrospective and prospective history efects by probing the psychometric curves at the trials before and after toi, respectively. The psychometric function ( ) was estimated by fiting the cumulative Gausian distribution ( ) to the curves using Psignifit package [50–52] (htps:/github.com/wichman-lab/psignifit), as folows: ψ(x) F ψ(x;μ,σ) = F(x;μ,σ), μ σ F μ where and are the mean and standard deviation of . By finding the best-fiting value of , we defined the PSE (the stimulus level with equal probability for a smal or large choice), which was used as the sumary statistics that quantifies the history efects asociated with a given PDM episode. To ensure reliable PSE estimates, we acquired botstrap samples ( ) of psychometric curves based on the binomial random proces and tok their aver- age as the final estimate for each PDM episode. In our main data analysis, the results of which are displayed in Fig 7, we chose not to include the parameters for gues or lapse rates in esti- mating PSEs. This was done to prevent unfair overfiting problems from ocuring in infre- quent episode types with smal numbers of trials available for fiting. On the other hand, to preclude any potential confounding problem related to the task dificulty asociated with PDM

N = 5,000

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 18 / 32 episode types, we also repeated the above PSE estimation procedure with gues () and lapse ( ) rates included as fre parameters: . The results did not difer betwen the original estimation procedure without the lapse and gues rates and the procedure with the lapse and gues rates (Bonferoni-corected P = 0.2023 ~ 1. 0; paired two-tailed t tests; se S2 Data for detailed statistical information).

γ λ ψ(x;μ,σ,γ,λ) = γ + (1 − γ − λ)F(x;μ,σ)

Value-updatingmodel

As a model of the value-updating scenario, we used the belief-based RL model proposed in the previous work [9,10]. This model incorporates RL algorithm into the conventional Bayesian formalism of decision confidence—also known as statistical decision confidence using a partialy observable Markov decision proces (Fig 3E). In this model, the decision-maker, given sensory measurement , computes the probability that the stimulus belongs to “large” ( ) or “smal” ( ) clas (hereinafter the pcomputation), where . This probability wil be refered to as a “belief-state,” as in the m pL pS = 1 − pL pL = ∫μ∞ original work [9,10]. Here, the probability distribution is defined as a normal distribution with mean and standard deviation . Whereas was asumed to be zero in the original work, we set fre as a constant parameter to alow the belief-based RL model to deal with any potential individualsʼ idiosyncratic choice bias, as we wil alow the world-updating model (BMBU) to do so (se below). Next, p(S|m) m σm μ0 μ0

<!-- page 2 -->

the expected values of the 2 choices and can be obtained by and multiplied with the learned values of the options of smal and large, and , respectively. Acordingly, the expected value

QS QL pS pL VS VL QC QS QL is also defined separately for the choice made betwen smal and large: and .

In the original work, the argmax rule was aplied to determine the choice (i.e., the higher determines the choice ). Instead, here, we aplied the softmax rule, which selects large with probability

Q C exp(βQL)

(the higher preferentialy selects ) where is an inverse temperature. This feature exp(βQS)+exp(βQL) Q C β did not exist in the original model but was introduced here to alow the belief-based RL model to deal with stochastic noise at the decision stage, as we alow the world-updating model (BMBU) to do so.

The initial values of smal and large choices were set identicaly as a fre parameter . Upon receiving fedback on the decision, the decision-maker updates the value of the selected choice by the reward prediction eror with learning rate :

Vinit

VC δ α

VC ← VC + αδ

No temporal discounting is asumed for simplicity. Since the decision-maker treats corective fedback as rewards (corect: , incorect: ), the reward prediction eror is computed as the deviation of the reward from the expected value: r = +1 r = 0 δ δ = r − QC = r − pCVC pC δ δ pC

Note that the belief state (i.e., statistical decision confidence) modulates such that increases as decreases, which is the crucial relationship constraining the belief-based RL modelʼs key prediction on the stimulus-dependent fedback efects. Specificaly, upon corect fedback, wil take a positive value and reinforce the choice value. However, as increases, the magnitude of such reinforcement wil decrease. Criticaly, despite the decrease of reinforcement as a function of , the sign of reinforcement wil never be reversed until the expected value reaches the maximum reward value ( ). Based on the same ground, the sign of reinforcement wil never be reversed either in the case of incorect fedback. The fre parameters of the value-updating model are .

δ pC pC Q r = 1 θ = {μ0,σm,α,β,Vinit}

PLOS BIOLOGY | Corective fedback on perceptual decisions

World-updatingmodel

As a model of the world-updating scenario, we developed the BMBU. BMBU shares the same platform for PDM with the belief-based RL model (as depicted in Figs 1A and 3A) but, as a BDT model, makes decisions using its “learned” generative model while continualy updating its belief about the clas boundary , the key latent variable of that internal model (as depicted in the left panel of Fig 3D).

<!-- page 3 -->

“Learned” generative model. In BDT, the learned generative model refers to the decision-makerʼs subjective internal model that relates task-relevant variables ( , , and in the left panel of Fig 3D) to external stimuli and behavioral choices ( and , respectively, in the left panel of Fig 3D). As previously known [53,54], the decision-makerʼs internal model is likely to deviate from the “actual” generative model that acurately reflects how the experimenter generated external stimuli due to oneʼs limitations in the sensory and memory aparatus. In the curent experimental setup, we asumed that the internal model of the decision-maker deviates from that of the experimenter in the folowing aspect: Due to the noise in the sensory and memory encoding proceses, the decision-maker is likely to believe that many rings of diferent sizes are presented, although the experimenter used only 5 discrete-size rings. The postexperiment interviews suported this: None of the participants reported perceiving discrete stimuli during the experiment. A deviation like this is known to ocur comonly in psychophysical experiments where a discrete number of stimuli were used [40,54,5].

m m′ B S CL

We incorporated the above deviation into the decision-makerʼs internal model by asuming that the stimulus at any given trial is randomly sampled from a Gausian distribution with mean and variance (as depicted by in Fig 3D):

B σ2S B → S p(S|B) = N(S;B,σ2S), (3) σ2S CL which defines the probability distribution of stimuli conditioned on the clas boundary, where coresponds to the extent to which a given decision-maker asumes that stimuli are distributed. Next, the inequality betwen the clas boundary and the stimulus determines the state of the clas (as depicted by the converging causal relations involving the clas variable, , in Fig 3D):

B → CL ← S CL = large(small) if S > (<)B, (4) which defines the corect answer of the perceptual task. On the other hand, the sensory measurement m S σ2m at any given trial is randomly sampled from a Gausian distribution with mean and variance (as depicted by in Fig 3D): p(m|S) = N(m;S,σ2m), (5) which defines the probability distribution of sensory measurements conditioned on the stimulus, where coresponds to the extent to which the decision-makerʼs sensory system is noisy. Lastly, the mnemonic measurement at any given trial is randomly sampled from a Gausian distribution with mean and variance (as depicted by in Fig 3D): m σ2m′ m → m′ p(m′|m) = N(m′;m,σ2m′), (6) which defines the probability distribution of mnemonic measurements conditioned on the sensory measurement, where coresponds to the extent to which the decision-makerʼs working memory system is noisy. This generative proces ( ) is required because the sensory evidence of the stimulus is no longer available in the sensory system—due to a brief (0.3 s;

<!-- page 10 -->

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 20 / 32

PLOS BIOLOGY Corective fedback on perceptual decisions

Fig 2B) stimulus duration—at the moment of updating the state of the clas boundary (as wil be shown below in the subsection titled “Boundary-updating”) and instead must be retrieved from the working memory system. The mnemonic recal of the stimulus is known to be noisy, becoming quickly deteriorated right away after stimulus ofset, especialy for continuous visual evidence such as color and orientation [56,57]. The generative proces relating to has ben adopted for the same reason by recent studies [58,59], including our group [5], and is consistent with the nonzero levels of memory noise in the modelfit results ( ). The substantial acros-individual variability of the fited levels of is also consistent with the previous studies [5,58,59].

σ2m′ = [1.567, 5.606] σ2m′

With the learned generative model defined above, the decision-maker comits to a deci- sion by infering the curent state of the clas variable from the curent sensory measure- ment and then updates the curent state of the boundary variable from both the curent mnemonic measurement and the curent fedback .

CL m m′ F

Decision-making. As for decision-making, BMBU, unlike the belief-based RL model, does not consider the choice values but completely relies on the -computation by selecting the large clas if and the smal clas if . The -computation is caried out by propagating the sensory measurement p pL > 0.5 pL < 0.5 p within its learned generative model: pL = ∫ p(S|m)dS, (7) where the finite limit of the integral is defined by the infered state of the boundary , which is continualy updated on a trial-to-trial basis (as wil be described below). This means that the behavioral choice can vary depending on even for the same value of (as depicted in the “perception” stage of Fig 3A and 3B).

B^ m

Boundary-updating. After having experienced a PDM episode in any given trial , BMBU (i) computes the likelihod of the clas boundary by concurently propagating the mnemonic measurement and the “informed” state of the clas variable , which can be informed by fedback and choice in the curent PDM episode, within its learned generative model ( ) and then (i) forms a posterior distribution of the clas boundary ( ) by combining that likelihod with its prior belief about the clas boundary at the moment ( ), which is inherited from the posterior distribution formed in the previous trial . Intuitively put, as BMBU undergoes sucesive trials, its poste- rior belief in the previous trial becomes the prior in the curent trial, being used as the clas boundary for decision-making and then being combined with the likelihod to be updated as the posterior belief in the curent trial. Below, we wil first describe the computations for (i) and then those for (i). As m′t CLt Ft Ct p(m′t,CLt|Bt) p(Bt|m′t,CLt) p(Bt) t − 1(p(Bt−1|m′t−1,CLt−1))

<!-- page 6 -->

explained above (Eq 6), we stres that the likelihod computation must be based not on the sensory measurement but on the mnemonic measurement because is no longer available at the moment of boundary-updating.

mt m′t mt

As for the boundary likelihod computation (i), BMBU posits that the decision-maker infers how likely the curent PDM episode—i.e., the combination of the mnemonic measure- ment , the choice , and the corective fedback —is generated by hypothetical values of the clas boundary ( ). Since the “true” state of the clas variable is deduced from any given pair of and states in binary clasification as folows, m′t Ct Ft p(m′t,Ct,Ft|Bt) CLt Ct Ft if and or if and ;

CLt = large Ct = large Ft = correct Ct = small Ft = incorrect CLt = small otherwise, m′t CLt : p(m′t,Ct,Ft|Bt) ≡ p(m′t,CLt|Bt) the likelihod can be defined using only and . Hence,

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 21 / 32

PLOS BIOLOGY Corective fedback on perceptual decisions m′t CLt the likelihod of the clas boundary is computed by propagating and inversely over the learned generative model (as defined by Eqs 3–6): p(m′t,CLt|Bt) = ∫ p(m′t,CLt,St|Bt)dSt = ∫ p(m′t|S)p(CLt|St,Bt)p(St|Bt)dSt, (8) which entails the marginalization over every posible state of , a variable unknown to the decisionmaker. Here, since the binary states of ( ) indicates the inequal- ity betwen

CLt CLt ∈ {small,large} St Bt Bt and (Eq 4), is used as the finite limit of the integrals to decompose the origi- nal integral into the one marginalized over the range of satisfying and the other marginalized over the range of satisfying :

St CLt = small St CLt = large

∫ p(m′t|S)p(CLt|St,Bt)p(St|Bt)dSt = p(m′t|St)p(CLt|St,Bt)p(St|Bt)dSt + ∫ p(m′t|St)p(CLt|St,Bt)p(St|Bt)dSt. (9)

Note that the boundary likelihod function is computed based on informed by fed- back. The righthand side of Eq 9 can further be simplified for the informed state by replacing the infinite limits with finite values (Equation S5 in Text in S1 Apendix). For the case of , in the left and right integral terms on the right-hand side of Eq 9 becomes 0 and 1, respectively, while becoming 1 and 0 for the case of in the ranges of of the coresponding integrals (Equation S3–S6 in Text in S1 Apendix). Hence, we find the likelihod of the clas boundary in a reduced form, separately for

CLt CLt CLt = large p(CLt|St,Bt)

CLt = small St and , as folows:

CLt = large CLt = small

<!-- page 10 -->

p(m′t,CLt = small|Bt) = ∫ p(m′t|St)p(St|Bt)dSt; p(m′t,CLt = large|Bt) = ∫ p(m′t|St)p(St|Bt)dSt (10) p(m′t|St) = N(m′t;St,σ2m′ + σ2m) S → m → m′ where , acording to the “chain” relations defined in the learned generative model ( in the left panel of Fig 3D; Eqs 5 and 6; se Equation S2 for derivations in Text in S1 Apendix). Eq 10 indicates that BMBU calculates how likely hypothetical boundary states bring about the mnemonic measurement ( ) while taking into acount the informed state of the clas variable ( ), by constraining the posible range of the stimulus states. To help readers intuitively apreciate these respective contribu- tions of the mnemonic measurement and the informed state of the clas variable (fedback) to the boundary likelihod, we further elaborated on how Eq 9 is reduced to Eq 10 depending on the informed state of (se Text in SI Apendix and S1 Fig).

B → S → m → m′ B → CL ← S

CLt = small N(St;Bt,σ2S) p(m′t|St) = N(m′t;St,σ2m′ + σ2m)

Lastly, we evaluate the integral for in Eq 10 by substituting $p(S_t|B_t) = $ and , from the defined statistical knowledge in the

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 2 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions learned generative model (Eq 3 and Eqs 5 and 6, respectively) and find: p(m′t,CLt = small|Bt)

# 1 √2π( σ

# 2 Mσ2S

σ2M+σ2S )

Btσ2 tσ2

S σ2

+σ2 S σ2 M σ2

S σ2

M+σ2

S dSt × e

# 1 √2π(σ2M + σ2S)

(Bt−m′ t)2 2(σ2 e−

+σ2 S σ2M = σ2m′ where . For the other state in fedback, we evaluate the integral in the same maner and find: p(m′t,CLt = large|Bt)

# 1 √2π( σ

# 2 Mσ2S

σ2M+σ2S )

Btσ2 tσ2

S σ2

+σ2 S σ2 M σ2

S σ2

+σ2

S dSt × e

# 1 √2π(σ2M + σ2S)

(Bt−m′ t)2 2(σ2 e−

+σ2 S

Having calculated the likelihod of , we turn to describe (i) how BMBU combines that likelihod with a prior distribution on trial , which forms a posterior distribution of acording to Bayes rule:

Bt t Bt

<!-- page 13 -->

p(Bt|m′t,CLt) ∝ p(m′t,CLt|Bt)p(Bt). (13) t p(Bt−1|m′t−1,CLt−1) Bt

We asumed that, at the begi ning of the curent trial , the decision-maker recals the posterior belief formed (Eq 13) from the previous trial—to use it as the prior of —into the curent working memory space, and it is thus subject both to decay and difusive noise during the recal proces. As a result, the prior is basicaly the recaled posterior, defined as the normal distribution as folows: λ σdiffusion p(Bt)

N(B^t,σ2B

B^t = λB^postt−1 + (1 − λ)μ0; σ2B

= λσ2t−1post + σ2diffusion, (14)

B^postt−1 σ2t−1post λ = σ where and denote mean and variance of the previous trialʼs posterior distribution. Note that the decay parameter influences the width and location of the belief distribution and that the difusive noise of helps to kep the width of the distribution over multiple trials, thus avoiding sharpening and stoping the updating proces [60]. In this way, and alow BMBU to adres the idiosyncratic choice bias and noise, as we equip the belief-based RL model to do so with and the sofmax rule. In sum, BMBU posits that human individuals cary out a sequence of binary clasification trials with their learned generative model while continualy updating their belief about the location of the clas boundary in that generative model. BMBU describes these decision-making and boundary-updating proceses using a total of 6 parameters ( ), which are set fre to acount for individual diferences.

2 0 σ20+σ2t−1post σdiffusion > 0 λ σdiffusion μ0 θ = {μ0,σm,σs,σ0,σm′

,σdiffusion}

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 23 / 32

PLOS BIOLOGY Corective fedback on perceptual decisions

Referencemodels

As the references for evaluating the belief-based RL model and BMBU in predicting the variability of human choices, we created 3 reference models. The “Base” model captures the choice variability that can be explained by the -computation with the clas boundary fixed at 0 unanimously for al participants and without any value-updating proces. Thus, it has only a single fre parameter representing the variability of the sensory measurement ( ). The “Fixed” model captures the choice variability that can be explained by the -computation with the clas boundary set fre to a fixed constant for each participant and without any value-updating proces. Thus, it has 2 fre parameters ( ). The “Hybrid” model captures the choice variability that can be explained both by the -computation with the infered clas boundary by BMBU and by the value-updating proces implemented by the belief-based RL θ = {σm} p μ0 θ = {μ0,σm} p<!-- page 9 --> model. Thus, it has 9 fre parameters ( ). In Fig 6B–6D, the diferential godnes of fit measures on the y-axis indicate the subtractions of the performance of the “Base” model from those of the remaining models.

θ = {μ0,σm,σs,σ0,σm0,σdiffusion,α,β,Vinit}

Model fitting

For each participant, we fited the models to human choices over N valid trials ( ) of M (= 10) experimental runs under K (= 3) conditions, where invalid trials were the trials in which the participants did not make any response. For any given model, we denote the log likelihod of a set of parameters given the data as folows: θ

Kcond

Mruns

Ntrials

LL(θ,model) = logp(data|θ,model) = logp(Ci,j,k|θ,model), k=1 j=1 i=1 where denotes the participantʼs choice (large or smal) on the i-th trial of the j-th run under the j-th condition. Computation of this is analyticaly intractable given the stochastic nature of choice determination. So, we used inverse binomial sampling (IBS; [61]), an eficient way of generating unbiased estimates via numerical simulations. The maximum-likelihod estimate of the model parameters was obtained with Bayesian Adaptive Direct Search (BADS) [62], a hybrid Bayesian optimization to find the parameter vector that maximizes the log likelihod, which works wel with stochastic target functions. To reduce the risk of being stuck at local optima, we repeated 20 independent fitings by seting the starting positions randomly using Latin hypercube sampling (lhsdesign_modifed.m by Nasim Khlaled; htps:/ w.mathworks.com/matlabcentral/fil exchange/45793-latin-hypercube) and then picked the fiting with the highest log likelihod. To avoid infinite l ops from using IBS, we did not impose individual lapse rates in an arbitrary maner. Instead, we calculated the average of the lapse rate and gues rate from the cumulative Gausian fit to a given individualʼs grand mean (based on the entire trials) psychometric curve. With these individual lapse probabilities (mean rate of 0.05, which ranged [0.051, 0.1714]), trials were randomly designated as lapse trials, in which the choice was randomly determined to be either smal or large.

Ci,j,k

LL θ∗

Model comparisoningodnessoffit

We compared the godnes of fit of the models using AICc based on maximum-likelihod estimation fiting, as folows:

2p(p + 1) (NxMxK) − p − 1

AICc = −2 ⋅ LL(θ∗) + 2p + where is the number of parameters of the model and the total number of trials in the dataset is

<!-- page 10 -->

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 24 / 32

N×M×K. Log model evidence was obtained for each participant by multiplying AICc by −1/2 [35]. Furthermore, we tok a hierarchical Bayesian model selection aproach that infers the posterior over model frequencies in the population based on log model evidence values in each participant. To conclude whether a given model is the most likely model above and beyond chance, we also reported protected excedance probabilities for each model (se Fig 6E and 6F). The random efects model selection at the group level relied on the function VBA_groupBMC.m of the Variational Bayesian Analysis tolbox (htps:/mb-team.github.io/VBA-tolbox/) [63].

Model recoveryanalysis

We performed a model recovery analysis to further validate our model fiting pipeline. In the analysis, we considered the 2 competing models of interest (the world-updating and value- updating models) and the 2 reference models (the Base and Hybrid models). Using the same parameter set, we generated synthetic data for each participantʼs true stimulus sequences. For the realistic synthetic data, the parameter values were chosen based on the best-fiting parame- ter estimates from each individual. We generated 30 sets of synthetic data for each model, with 153, 0 trials in each set. We then fit al 4 models to each synthetic dataset, resulting in 480 fit- ting problems. We asesed the models using the AICc-based log model evidence and com- puted excedance probabilities. Our analysis showed that al models were distinguishable, which confirms the validity of our model fiting pipeline (S3 Fig).

Exanteandexpostmodel simulations

We conducted ex ante model simulations to confirm and preview the value-updating and world- updating modelsʼ distinct predictions on the stimulus-dependent fedback efects under the cur- rent experimental seting. Model simulations were conducted using trial sequences (i.e., stimulus order and corect answers) identical to those administered to human participants. The model parameters used in the ex ante simulation are sumarized in the Table A in S1 Apendix. Note that the 25 levels (uniformly spaced [0.15, 3.27]) of , the only parameter comon to the 2 mod- els, were used. As for the other parameters specific to each model, we selected the values that gen- erated human-level task performances (se S4 Fig for details and statistical results). Simulations were repeated 10 times, resulting in the 10×N×M×K = 507,30 ~ 510, 0 trials per participant. For simplicity, we asumed neither lapse trials nor any arbitrary choice bias.

σm

The procedure of ex post model simulations was identical to that of ex ante model simula- tions except that the best-fiting model parameters and lapse trials were used.

<!-- page 30 -->

Statistical tests

Unles otherwise mentioned, the statistical comparisons were performed using paired t tests (two-tailed, N = 30). To test the reversed fedback efects under conditions of strong sensory evidence, we aplied one-sample t tests (one-tailed, N = 27 for S7A Fig, N = 8 for S7B Fig). Repeated t tests on PSEs betwen data and model (Figs 7B, 7C and S5) were performed (two- tailed, N = 30). In Table D in S1 Apendix, we reported the number of test conditions of signif- icant deviation from the data (Bonferoni-corected threshold; : P < 0. 083, : P < 0. 0167, : P < 0. 0167). Aditionaly, Wilcoxon signed-rank tests were performed with the same threshold aplied (Table D in S1 Apendix). Repeated t tests on each cel of episode frequency maps betwen the data and the models (Figs 7E, 7F and S6) were performed, and P values were subjected to Bonferoni corection (two-tailed, N = 30; value-updating, P < 0. 0631; world-updating, P < 0. 063). Task performances betwen human agents (N = 30) and model agents with diferent sets of parameters (N = 25) were compared based on unpaired t tests (two-tailed, S4 Fig).

PLOS BIOLOGY | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 25 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions

Suportinginformation

**S1 Fig. Schematic ilustration of BMBUʼs acount of how the joint contribution of the sensory and fedback evidence to boundary updating leads to the reversal of choice bias as a function of sensory evidence strength.** (A) Reversal of subsequent choice bias—expresed in PSE—as a function of sensory evidence strength and boundary inference—expresed in likelihod computation—based on a PDM episode. Left panel: The circles with diferent colors (indicated by (b-d), which points to the coresponding panels below (B-D) represent the PSEs asociated with the boundary updating for 3 example PDM episodes, where the stimulus ( ) varies from 0 to 2 while the choice ( ) and fedback (

St Ct Ft

) are large and corect, respectively. Right panel: At the core of boundary inference is the computation of the likelihod of the clas boundary based on the mnemonic measurement ( ) and the informed state of the clas variable ( ), where is jointly determined by and (se Materials and methods for the ful computation of boundary inference in BMBU). (B-D) The likelihods of the clas boundary given the 3 example PDM episodes defined in (A), where sensory evidence varies from the low (B), to the intermediate (C), and to the high (D) level. To help understand why and how, given the same fedback evidence, the direction of boundary updating reverses as the sensory evidence strengthens, we visualize the boundary likelihods as a product of 2 functions (Eq 12), indicated by subpanels marked as (1) and m′t CLt CLt Ft Ct

(2). Top row: As indicated by (1), we plot each boundary likelihod when only the mnemonic measurement is considered, asuming that no fedback is provided. Note that these likelihod functions are centered around the values of , by atracting the clas boundary toward themselves, driving a shift towards the large side (i.e., positive side on the boundary axis). Mi dle-Botom rows: When the fedback evidence is m′t<!-- page 1 --> given—i.e., when the informed state of is revealed as large—in adition to the mnemonic measurement, an aditional piece of information about the clas boundary arises. As indicated by (1) ×

(2), we plot each boundary likelihod (defined in (A). As indicated by (2), we plot each function (Mi dle row), as the result of (Botom row) divided by (Top row). The complementary cumulative distribution functions shown here are also centered around because the large state of means that the clas boundary is located somewhere smaler than . Note that these skewed distributions push the infered clas boundary away from the state of informed by fedback, driving a shift towards the smal side (i.e., negative side on the boundary axis). Consequently, the influences from the sensory evidence and the fedback evidence counteract each other (Botom row). Note that the likelihod functions are centered in the smal side when the sensory evidence is weak (B), in the neutral side when intermediate (C), and in the large side when strong (D). These systematic shifts of the clas-boundary likelihod as a function of the strength of sensory evidence predict that the PSE of the psychometric curve for the subsequent trial ( m′t CLt m′t

) reverses its sign from negative to positive as a function of the stimulus size, as shown in (A). (TIF) t + 1

**S2 Fig. Example trial courses of estimated clas boundary.** (A) An example trial history to show how a temporal trajectory of the clas boundary infered by BMBU. For example, at trial #1 (x-axis), a physical stimulus (symbol x) was 0, a sensory measurement (symbol o) was a positive value when the boundary belief (solid black bar; y-axis) was centered at 0. BMBUʼs choice was large (symbol square on the top of y-axis), and corect fedback (same square filed with gren color) was provided, which indicates that the clas variable at trial #1 was large (arowʼs direction indicates the efect of the trial clas variable on the subsequent boundary-updating). BMBU updates oneʼs belief based on evidence from stimulus (colored symbol o) and fedback ( ), available at the time of boundary-updating. To ilustrate cases where the bias reversal we defined in Fig 3D in the main text hapen and do not hapen, same examples

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 26 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions were intentionaly used as those we used in S1 Fig where we further detailed on the modelʼs mechanisms. Depending on colors, sensory evidence is weak (yelow symbol o) or strong (purple symbol o), which leads to whether or not the reversal hapens. Trial cases featured in a red box indicates that the “Reinforcement” principle is held (predicting subsequent choices to repeat large choice) while those featured in a gren box indicates that the “Reversal” hapens (predicting subsequent choices to reverse the previously made large choice). (B) Temporal trajectories of the clas boundary when the same 6-trial sequence of physical stimuli in (A) was simulated for 10 times. This means diferent and were realized. The data underlying this figure (A, B) can be found in S1 Data. (TIF)

**S3 Fig. Model recovery analysis.** Each square represents excedance probability from model recovery procedure. The “ground-truth” model to simulate synthetic behavior was corectly recovered with for al 4 models considered in the study. The light shade of the diagonal squares indicates that the ground-truth model was the best-fiting model, leading to a sucesful model recovery. Numerical values can also be found in S1 Data. (TIF)

CL1

CL1 pexc pexc > 0.9<!-- page 4 --> **S4 Fig. Histograms of clasification acuracies of the human participants and their model partners in the ex ante simulations.** (A, B) Acros-individual distributions of the clasification acuracy of the beliefbased RL model (A) and BMBU (B) overlaid on those of the human participants. The modelsʼ choices were generated via ex ante simulations with a specific set of model parameters (Table A in S1 Apendix), the results of which are depicted in Figs 4 and 5. The clasification acuracy is measured by calculating the percentage of the trials in which the choice matched the fedback used in the actual experiment. The empty bars corespond to the histogram of human performances, the range of which is demarcated by the dashed vertical lines ([min, max] = [60.65%, 73.94%]). The average human clasification acuracy was 67.85%. (A) Comparison of clasification acuracy betwen the belief-based RL modelʼs simulation (red color) and the human choices. The modelʼs ex ante simulation acuracy was not diferent from the human acuracy ( ; Nul hypothesis: modelʼs performance vector and humansʼ performance vector come from populations with equal means, unpaired two-tailed t test). (B) Comparison of clasification acuracy betwen BMBUʼs simulation (gren color) and the human choices. The modelʼs ex ante simulation acuracy was not diferent from the human acuracy (

, unpaired two-tailed t test). There was no significant diference in clasification acuracy betwen the value-updating model and BMBU ( , unpaired two-tailed t test). The data underlying this figure (A, B) can be found in S1 Data. (TIF)

**S5 Fig. Retrospective (left columns), prospective (mi dle columns), and subtractive (right columns) history efects in PSE for the “Hybrid” modelʼs ex post model simulations.** Top and botom rows in each panel show the PSEs asociated with the toi episodes involving corect and incorect fedback at toi. Symbols with eror bars, mean ± SEM acros the 30 model agents, which corespond to their 30 human partners. The colors of the symbols and lines label choices (blue: smal and yelow: large). The data underlying this figure can be found in S1 Data. (TIF)

**S6 Fig. Maps of frequency deviations of the value-updating (A) and world-updating (B) model agentsʼ clasifications in the ex post simulations from the human decision-makers in the retrospective (left) and prospective (right) history efects.** Each cel represents a pair

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 27 / 32 of PDM episodes, as specified by the column and row labels. At each cel, the color represents how much the episode frequency observed in the model agents deviates from that observed in the coresponding human decision-makers. The results of statistical tests on these deviations are sumarized in Fig 7E and

7F. The data underlying this figure (A, B) can be found in S1 Data. (TIF) t(53) = 1.4429,P = 0.1549 t(53) = 0.9707,P = 0.3361 t(48) = 0.5733,P = 0.5691

**S7 Fig. Retrospective (left columns), prospective (mi dle columns), and subtractive (right columns) history efects in PSE for the human clasification performances of Urai and col- leaguesʼ work [37] (A) and Hachen and coleaguesʼ work [31] (B).** (A, B) We downloaded both publicly available datasets, analyzed them in the same way that we analyzed human observers in our work, and ploted the results in the same format used for Fig 7A. Top and bot- tom rows in each panel show the PSEs asociated with the toi episodes involving corect and incorect fedback. Symbols with eror bars, mean ± SEM acros human observers. The colors of the symbols and lines label choices (blue: smal and yelow: large).

<!-- page 7 -->

The overal paterns of the PSEs ploted here apear similar to those ploted in Fig 7A, displaying the reversals in direction of stimulus-dependent fedback efects. When the same statistical tests used in our work were caried out, some of the data points at the stimuli with strong sensory evidence at toi significantly deviated from zero in the direction oposite to the fedback efect predicted by the valueupdating scenario, as indicated by the asterisks. (A) Sequential features of human observers ( ) analyzed in our way from human dataset that once had ben published [37], which is openly available (htp:/dx.doi.org/10.6084/m9.figshare.43 043), then analyzed in the previous study [9]. In this study, the participants performed a binary clasification task on the diference in motion coherence by sorting the pairs of random-dot-kinematogram sti- muli shown in 2 intervals (s1 and s2) into one of the 2 clases (“s1<s2” vs. “s1>s2”) over con- secutive trials. The presented stimuli were taken from 3 sets of dificulty levels (the diference betwen motion coherence of the test and the reference stimulus; easy: [2.5, 5, 10, 20, 30], medium: [1.25, 2.5, 5, 10, 30], hard: [0.625, 1.25, 2.5, 5, 20]). As done in the original study [9], we bi ned the trials into 8 levels by merging the trials of 2 neighboring coherence levels (e.g., the coherence levels of [0.625, 1.25]) into a single bin. Note that the coherence bins of [20, 35, 45, 48.75, 51.25, 5, 65, 80] (%s1) on the x-axis (50% represents the equal coherence betwen s1 and s2) are matched to the xaxis in Fig 8 of the previous study in which the same dataset had ben used. Asterisks mark the significance of one-sample t tests (uncorected , one-tailed in the direction of fedback efects) on the panel toi+1 (stimulus 80%: 2.0138, ) and on the panel subtracted (stimulus 20%: , , stimulus 80%: , ). (B) Sequential features of human observers ( ) published in another previous study [31]. We used the human dataset openly available as part of the repository (htps:/osf.io/hux4n). In this study, the participants performed a binary clas- sification task on the sped of vibrotactile stimuli by clasifying the sped of the presented vibration as “low-sped (weak)” or “high-sped (strong).” Note that the 9-level stimuli of [−4, −3,−2,−1,0,1,2,3,4] on the x-axis folowed how data were encoded by the original study [31]. Asterisks mark the significance of one-sample t tests (uncorected , one-tailed in the direction of fedback efects) on the panel toi+1 (stimulus −4: , , stimu- lus −3:

P < 0.05 t(26) = P = 0.0272 t(26) = −3.1900 P = 0.0018 t(26) = 3.8810 P = 0.0003 N = 8

P < 0.05 t(7) = −3.6757 P = 0.004 t(7) = −3.5252 P = 0.0048 t(7) = −2.0325 P = 0.04

, , and stimulus −2: , ) and on the panel subtracted (stimulus −4: , ). The data underlying this figure (A, B) can be found in S1 Data. (TIF) t(7) = −1.9848 P = 0.044

S1 Apendix. Suporting details. Suplemental details (Text) on aditional model specifica- tions of BMBU are provided. Suplementary tables (A-D Tables) to suport the Results section

PLOS BIOLOGY | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 28 / 32 are provided. Table A. Parameters used for ex ante simulations. Table B. Parameters recovered from fiting the main models, world-updating and value-updating models, to human choices (N = 30). Table C. Parameters recovered from fiting the rest of the models to human choices (N = 30). Table D. Statistical results on model behavior versus human behavior in terms of PSE measures. (DOCX)<!-- page 2 --> S1 Data. Excel spreadshet containing, in separate shets, the underlying numerical data for Figs 2D, 4B, 4D, 4E, 4G, 4H, 5B, 5D, 5E, 5G, 5H, 6B, 6C, 6D, 7A, 7B, 7C, 7D, 7E, 7F, S2A, S2B, S3, S4A, S4B, S5, S6A, S6B, S7A and S7B. (XLSX)

S2 Data. Excel spreadshet containing detailed statistical information comparing alternative PSE estimation methods. (XLSX)

Acknowledgments

The authors are grateful to Daeyeol Le for his insightful coments and inspiring conversations concerning the prior version of the manuscript.

AuthorContributions

Conceptualization: Hyang-Jung Le, Heseung Le, Sang-Hun Le. Data curation: Isac Rhim. Formal analysis: Hyang-Jung Le. Funding acquisition: Sang-Hun Le. Investigation: Hyang-Jung Le. Methodology: Hyang-Jung Le, Chae Young Lim, Sang-Hun Le. Resources: Sang-Hun Le. Software: Hyang-Jung Le. Supervision: Sang-Hun Le. Validation: Hyang-Jung Le, Chae Young Lim, Sang-Hun Le. Visualization: Hyang-Jung Le, Sang-Hun Le. Writing – original draft: Hyang-Jung Le. Writing – review & editing: Hyang-Jung Le, Heseung Le, Chae Young Lim, Isac Rhim, Sang-Hun Le.

References

1. Gold JI, Law CT, Conoly P, Benur S. The relative influences of priors and sensory evidence on an oculomotor decision variable during perceptual learning. J Neurophysiol. 208; 10(5):2653–268. htps:/doi.org/10.152/jn.90629.208 PMID: 1875326

2. Hwang EJ, Dahlen JE, Mukundan M, Komiyama T. History-based action selection bias in posterior parietal cortex. Nat Comun. 2017; 8(1):1242. htps:/doi.org/10.1038/s41467-017-01356-z PMID: 2908950

PLOS BIOLOGY Corective fedback on perceptual decisions PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 29 / 32

PLOS BIOLOGY Corective fedback on perceptual decisions

3. Abrahamyan A, SilvaL, Dakin SC, Carandini M, Gardner JL. Adaptable history biases in human per ceptual decisions. Proc National Acad Sci. 2016; 13(25):E3548–E357. htps:/doi.org/10.1073/pnas. 151878613 PMID: 273086

<!-- page 4 -->

4. Buse L, Ayaz A, Dhruv NT, Katzner S, Sal em AB, Scholvinck ML, et al. The detection of visual con trast in the behaving mouse. J Neurosci. 201; 31(31):1351–1361. htps:/doi.org/10.1523/ JNEUROSCI. 689-10.201 PMID: 21813694

5. Scot B, Constantinople CM, Erlich JC, Tank DW, Brody CD. Sources of noise during acumulation of evidence in unrestrained and voluntarily head-restrained rats. eLife. 2015; 4:e1308. htps:/doi.org/10. 754/eLife.1308 PMID: 2673896

6. Mendonc¸a AG, Drugowitsch J, Vicente MI, DeWit EJ, Pouget A, Mainen ZF. The impact of learning on perceptual decisions and its implication for sped-acuracy tradeofs. Nat Comun. 2020; 1 #

(1):2757. htps:/doi.org/10.1038/s41467-020-16196-7 PMID: 3248065

7. Fernberger SW. Interdependence of judgments within the series for the method of constant stimuli. J Exp Psychol. 1920; 3(2):126–150.

8. Lak A, Nomoto K, Keramati M, Sakagami M, Kepecs A. Midbrain dopamine neurons signal belief in choice acuracy during a perceptual decision. Cur Biol. 2017; 27(6):821–832. htps:/doi.org/10.1016/j. cub.2017.02.026 PMID: 2828594

9. Lak A, Hueske E, Hirokawa J, Maset P, Ot T, Urai AE, et al. Reinforcement biases subsequent per ceptual decisions when confidence is low, a widespread behavioral phenomenon. eLife. 2020; 9: e49834. htps:/doi.org/10.754/eLife.49834 PMID: 328627

10. Lak A, Okun M, Mos M, Gurnani H, Farel K, Wels MJ, et al. Dopaminergic and prefrontal basis of learning from sensory confidence and reward value. Neuron. 2020; 105(4):70–71.e6. htps:/doi.org/ 10.1016/j.neuron.2019.1.018 PMID: 31859030

1. Nogueira R, Abolafia JM, Drugowitsch J, Balaguer-Balester E, Sanchez-Vives MV, Moreno-Bote R. Lateral orbitofrontal cortex anticipates choices and integrates prior with curent information. Nat Com mun. 2017; 8(1):14823. htps:/doi.org/10.1038/ncoms14823 PMID: 283790

12. Le D, Seo H, Jung MW. Neural basis of reinforcement learning and decision making. Anu Rev Neu rosci. 2012; 35(1):287–308. htps:/doi.org/10.146/anurev-neuro-0621-150512 PMID: 2462543

# 13. Daw ND, Doya K. The computational neurobiology of learning and reward. Cur Opin Neurobiol. 206; 16(2):19–204. htps:/doi.org/10.1016/j.conb.206.03.06 PMID: 16563737

13. Suton R, Barto A. Reinforcement Learning: An Introduction. Cambridge, MA: MIT Pres; 198.

14. Corado GS, Sugrue LP, Seung HS, Newsome WT. Linear-nonlinear-poison models of primate choice dynamics. J Exp Anal Behav. 205; 84(3):581–617. htps:/doi.org/10.1901/jeab.205.23-05 PMID: 16596981

15. Lau B, Glimcher PW. Dynamic response-by-response models of matching behavior in rhesus monkeys. J Exp Anal Behav. 205; 84(3): 5–579. htps:/doi.org/10.1901/jeab.205.10-04 PMID: 16596980

16. Gla¨scher J, Daw N, Dayan P, OʼDoherty JP. States versus rewards: disociable neural prediction eror signals underlying model-based and model-fre reinforcement learning. Neuron. 2010; 6(4):585–

595. htps:/doi.org/10.1016/j.neuron.2010.04.016 PMID: 20510862

17. Le SW, Shimojo S, OʼDoherty JP. Neural computations underlying arbitration betwen model-based and model-fre learning. Neuron. 2014; 81(3):687–69. htps:/doi.org/10.1016/j.neuron.2013.1.028 PMID: 2450719

<!-- page 38 -->

18. Odoemene O, Pisupati S, Nguyen H, Churchland AK. Visual evidence acumulation guides decision making in unrestrained mice. J Neurosci. 2018; 38(47):10143–1015. htps:/doi.org/10.1523/ JNEUROSCI.3478-17.2018 PMID: 3032902

19. Hermoso-Mendizabal A, Hyafil A, Rueda-Orozco PE, Jaramilo S, Robe D, de la Rocha J. Response outcomes gate the impact of expectations on perceptual decisions. Nat Comun. 2020; 1(1):1057. htps:/doi.org/10.1038/s41467-020-14824-w PMID: 3210309

20. Akrami A, Kopec CD, Diamond ME, Brody CD. Posterior parietal cortex represents sensory history and mediates its efects on behaviour. Nature. 2018; 54(7692):368–372. htps:/doi.org/10.1038/ nature2510 PMID: 2941494

21. Sumerfield C, Tsetsos K. Building bridges betwen perceptual and economic decision-making: neural and computational mechanisms. Front Neurosci. 2012; 6:70. htps:/doi.org/10. 389/fnins.2012. 070 PMID: 2654730

2. Kahnt T, Grueschow M, Speck O, Haynes JD. Perceptual learning and decision-making in human medial frontal cortex. Neuron. 201; 70(3):549–59. htps:/doi.org/10.1016/j.neuron.201.02.054 PMID: 21 5079

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 30 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions

24. Polanı´a R, Krajbich I, Grueschow M, Ruf C. Neural oscilations and synchronization diferentialy suport evidence acumulation in perceptual and value-based decision making. Neuron. 2014; 82(3):709–720. htps:/doi.org/10.1016/j.neuron.2014.03.014 PMID: 2481387

25. Ko¨rding KP, Wolpert DM. Bayesian decision theory in sensorimotor control. Trends Cogn Sci. 206; 10(7):319–326. htps:/doi.org/10.1016/j.tics.206.05.03 PMID: 16807063

26. Tromersha¨user J, Maloney LT, Landy MS. Decision making, movement planing and statistical decision theory. Trends Cogn Sci. 208; 12(8):291–297. htps:/doi.org/10.1016/j.tics.208.04.010 PMID: 18614390

27. Grifiths TL, Tenenbaum JB. Optimal predictions in everyday cognition. Psychol Sci. 206; 17(9):767–

73. htps:/doi.org/10. 1/j.1467-9280.206.01780.x PMID: 16984293

28. Tenenbaum JB, Kemp C, Grifiths TL, Godman ND. How to grow a mind: statistics, structure, and abstraction. Science. 201; 31(602):1279–1285. htps:/doi.org/10.126/science.19278 PMID: 21393536

29. Glaze CM, Filipowicz ALS, Kable JW, Balasubramanian V, Gold JI. A bias–variance trade-of governs individual diferences in on-line learning in an unpredictable environment. Nat Hum Behav. 2018; 2(3):213–24.

30. Ma WJ. Bayesian decision models: A primer. Neuron. 2019; 104(1):164–175. htps:/doi.org/10.1016/j.neuron.2019.09.037 PMID: 3160512

31. Hachen I, Reinartz S, Braselet R, Stroligo A, Diamond ME. Dynamics of history-dependent perceptual judgment. Nat Comun. 2021; 12(1):6036. htps:/doi.org/10.1038/s41467-021-26104-2 PMID: 34654804

<!-- page 32 -->

32. Burnham KP, Anderson DR. Model Selection and Inference, A Practical Information-Heuristic Aproach. New York: Springer-Verlag; 202.

3. Stephan KE, Peny WD, Daunizeau J, Moran RJ, Friston KJ. Bayesian model selection for group studies. Neuroimage. 209; 46(4):104–1017. htps:/doi.org/10.1016/j.neuroimage.209.03.025 PMID: 19306932

34. Rigoux L, Stephan KE, Friston KJ, Daunizeau J. Bayesian model selection for group studies—Revisited. Neuroimage. 2014; 84:971–985. htps:/doi.org/10.1016/j.neuroimage.2013.08.065 PMID: 24018303

35. Cao Y, Sumerfield C, Park H, Giordano BL, Kayser C. Causal inference in the multisensory brain. Neuron. 2019; 102(5):1076–1087.e8. htps:/doi.org/10.1016/j.neuron.2019.03.043 PMID: 3104 78

36. Palminteri S, Wyart V, Koechlin E. The importance of falsification in computational cognitive modeling. Trends Cogn Sci. 2017; 21(6):425–43. htps:/doi.org/10.1016/j.tics.2017.03.01 PMID: 28476348

37. Urai AE, Braun A, Doner TH. Pupil-linked arousal is driven by decision uncertainty and alters serial choice bias. Nat Comun. 2017; 8(1):14637. htps:/doi.org/10.1038/ncoms14637 PMID: 28256514

38. Zariwala HA, Kepecs A, Uchida N, Hirokawa J, Mainen ZF. The limits of deliberation in a perceptual decision task. Neuron. 2013; 78(2): 39–351. htps:/doi.org/10.1016/j.neuron.2013.02.010 PMID: 23541901

39. Renart A, Machens CK. Variability in neural activity and behavior. Cur Opin Neurobiol. 2014; 25:21–

20. htps:/doi.org/10.1016/j.conb.2014.02.013 PMID: 2463234

40. Qamar AT, Coton RJ, George RG, Beck JM, Prezhdo E, Laudano A, et al. Trial-to-trial, uncertaintybased adjustment of decision boundaries in visual categorization. Proc National Acad Sci. 2013;

10(50):2032–2037. htps:/doi.org/10.1073/pnas.121975610 PMID: 24272938

41. Sumerfield C, Behrens TE, Koechlin E. Perceptual clasification in a rapidly changing environment. Neuron. 201; 71(4):725–736. htps:/doi.org/10.1016/j.neuron.201.06.02 PMID: 2186787

42. Norton EH, Fleming SM, Daw ND, Landy MS. Suboptimal criterion learning in static and dynamic environments. PLoS Comput Biol. 2017; 13(1):e105304. htps:/doi.org/10.1371/journal.pcbi.105304 PMID: 2804606

43. Treisman M, Wiliams TC. A theory of criterion seting with an aplication to sequential dependencies. Psychol Rev. 1984; 91(1):68– 1.

4. Lages M, Treisman M. A criterion seting theory of discrimination learning that acounts for anisotropies and context efects. Seing Perceiving. 2010; 23(5):401–434. htps:/doi.org/10.163/187847510x5417 PMID: 2146134

45. Fritsche M, Mostert P, Lange FP de. Oposite efects of recent history on perception and decision. Cur Biol. 2017; 27(4):590–5.

46. Drugowitsch J, Mendonc¸a AG, Mainen ZF, Pouget A. Learning optimal decisions with confidence. Proc National Acad Sci. 2019; 16(49):24872–2480. htps:/doi.org/10.1073/pnas.190678716 PMID: 31732671

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 31 / 32

PLOS BIOLOGY

<!-- page 47 -->

47. Mochol G, Kiani R, Moreno-Bote R. Prefrontal cortex represents heuristics that shape choice bias and its integration into future behavior. Cur Biol. 2021; 31(6):1234–124.e6. htps:/doi.org/10.1016/j.cub. 2021.01.068 PMID: 3639107

48. Gupta D, Brody CD. Limitations of a proposed corection for slow drifts in decision criterion. arXiv pre print arXiv: 20510912. 202.

49. Car EH. What is History? London: University of Cambridge & Penguin Boks; 1961.

50. Wichman FA, Hil NJ. The psychometric function: I. Fiting, sampling, and godnes of fit. Percept Psy chophys. 201; 63(8):1293–1313. htps:/doi.org/10.3758/bf0319454 PMID: 180458

51. Wichman FA, Hil NJ. The psychometric function: I. Botstrap-based confidence intervals and sam pling. Percept Psychophys. 201; 63(8):1314–1329. htps:/doi.org/10.3758/bf03194545 PMID:

52. Schu¨t H, Harmeling S, Macke JH, Wichman FA. Painfre and acurate Bayesian estimation of psy chometric functions for (potentialy) overdispersed data. Vision Res. 2016; 12:105–123. htps:/doi. org/10.1016/j.visres.2016.02.02 PMID: 27013261

53. Ma WJ. Organizing probabilistic models of perception. Trends Cogn Sci. 2012; 16(10):51–518. htps:/ doi.org/10.1016/j.tics.2012.08.010 PMID: 2981359

54. Haefner RM, Berkes P, Fiser J. Perceptual decision-making as probabilistic inference by neural sam pling. Neuron. 2016; 90(3):649–60. htps:/doi.org/10.1016/j.neuron.2016.03.020 PMID: 27146267

# 5. Le H, Le HJ, Choe KW, Le SH. Neural evidence for boundary updating as the source of the

repulsive bias in clasification. J Neurosci. 2023; 43(25):464–4683. htps:/doi.org/10.1523/JNEUROSCI.016- 23.2023 PMID: 37286349

56. Wilken P, Ma WJ. A detection theory acount of change detection. J Vis. 204; 4(12):1. htps:/doi.org/ 10.167/4.12.1 PMID: 156916

57. Bays PM, Gorgoraptis N, We N, Marshal L, Husain M. Temporal dynamics of encoding, storage, and realocation of visual working memory. J Vis. 201; 1(10):htps:/doi.org/10.167/1.10.6 PMID: 2191739

58. Lu L, Stocker A. Post-decision biases reveal a self-consistency principle in perceptual inference. eLife. 2018; 7:e 34. htps:/doi.org/10.754/eLife. 34 PMID: 29785928

59. Lu L, Stocker A. Categorical judgments do not modify sensory representations in working memory. PLoS Comput Biol. 2021; 17(6):e108968. htps:/doi.org/10.1371/journal.pcbi.108968 PMID: 34061849

60. Daw ND OʼDoherty JP, Dayan P, Seymour B, Dolan RJ. Cortical substrates for exploratory decisions in humans. Nature. 206; 41(7095):876–879.

61. Opheusden B van, Acerbi L, Ma WJ. Unbiased and eficient log-likelihod estimation with inverse bino mial sampling. PLoS Comput Biol. 2020; 16(12):e108483. htps:/doi.org/10.1371/journal.pcbi. 108483 PMID: 362195

62. Acerbi L, Ma WJ. Practical Bayesian optimization for model fiting with Bayesian adaptive direct search. Adv Neural Inf Proces Syst 2017; 30:1836–1846.

63. Daunizeau J, Adam V, Rigoux L. VBA: A Probabilistic Treatment of Nonlinear Models for Neurobiologi cal and Behavioural Data. PLoS Comput Biol. 2014; 10(1):e10341. htps:/doi.org/10.1371/journal. pcbi.10341 PMID: 2465198

<!-- page 10 -->

Corective fedback on perceptual decisions PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 32 / 32