PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 20 / 32

PLOS BIOLOGY Corective fedback on perceptual decisions

Fig 2B) stimulus duration—at the moment of updating the state of the clas boundary (as wil be shown below in the subsection titled “Boundary-updating”) and instead must be retrieved from the working memory system. The mnemonic recal of the stimulus is known to be noisy, becoming quickly deteriorated right away after stimulus ofset, especialy for continuous visual evidence such as color and orientation [56,57]. The generative proces relating to has ben adopted for the same reason by recent studies [58,59], including our group [5], and is consistent with the nonzero levels of memory noise in the modelfit results ( ). The substantial acros-individual variability of the fited levels of is also consistent with the previous studies [5,58,59].

σ2m′ = [1.567, 5.606] σ2m′

With the learned generative model defined above, the decision-maker comits to a deci- sion by infering the curent state of the clas variable from the curent sensory measure- ment and then updates the curent state of the boundary variable from both the curent mnemonic measurement and the curent fedback .

CL m

m′ F

Decision-making. As for decision-making, BMBU, unlike the belief-based RL model, does not consider the choice values but completely relies on the -computation by selecting the large clas if and the smal clas if . The -computation is caried out by propagating the sensory measurement

p pL > 0.5 pL < 0.5 p

within its learned generative model:

pL = ∫

p(S|m)dS, (7)

where the finite limit of the integral is defined by the infered state of the boundary , which is continualy updated on a trial-to-trial basis (as wil be described below). This means that the behavioral choice can vary depending on even for the same value of (as depicted in the “perception” stage of Fig 3A and 3B).

B^ m

Boundary-updating. After having experienced a PDM episode in any given trial , BMBU (i) computes the likelihod of the clas boundary by concurently propagating the mnemonic measurement and the “informed” state of the clas variable , which can be informed by fedback and choice in the curent PDM episode, within its learned generative model ( ) and then (i) forms a posterior distribution of the clas boundary ( ) by combining that likelihod with its prior belief about the clas boundary at the moment ( ), which is inherited from the posterior distribution formed in the previous trial . Intuitively put, as BMBU undergoes sucesive trials, its poste- rior belief in the previous trial becomes the prior in the curent trial, being used as the clas boundary for decision-making and then being combined with the likelihod to be updated as the posterior belief in the curent trial. Below, we wil first describe the computations for (i) and then those for (i). As

m′t CLt Ft Ct

p(m′t,CLt|Bt) p(Bt|m′t,CLt)

p(Bt) t − 1(p(Bt−1|m′t−1,CLt−1))