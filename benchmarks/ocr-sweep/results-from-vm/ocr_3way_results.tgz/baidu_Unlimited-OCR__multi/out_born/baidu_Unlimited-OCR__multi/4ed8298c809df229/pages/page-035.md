PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 24 / 32

N×M×K. Log model evidence was obtained for each participant by multiplying AICc by −1/2 [35]. Furthermore, we tok a hierarchical Bayesian model selection aproach that infers the posterior over model frequencies in the population based on log model evidence values in each participant. To conclude whether a given model is the most likely model above and beyond chance, we also reported protected excedance probabilities for each model (se Fig 6E and 6F). The random efects model selection at the group level relied on the function VBA_groupBMC.m of the Variational Bayesian Analysis tolbox (htps:/mb-team.github.io/VBA-tolbox/) [63].

Model recoveryanalysis

We performed a model recovery analysis to further validate our model fiting pipeline. In the analysis, we considered the 2 competing models of interest (the world-updating and value- updating models) and the 2 reference models (the Base and Hybrid models). Using the same parameter set, we generated synthetic data for each participantʼs true stimulus sequences. For the realistic synthetic data, the parameter values were chosen based on the best-fiting parame- ter estimates from each individual. We generated 30 sets of synthetic data for each model, with 153, 0 trials in each set. We then fit al 4 models to each synthetic dataset, resulting in 480 fit- ting problems. We asesed the models using the AICc-based log model evidence and com- puted excedance probabilities. Our analysis showed that al models were distinguishable, which confirms the validity of our model fiting pipeline (S3 Fig).

Exanteandexpostmodel simulations

We conducted ex ante model simulations to confirm and preview the value-updating and world- updating modelsʼ distinct predictions on the stimulus-dependent fedback efects under the cur- rent experimental seting. Model simulations were conducted using trial sequences (i.e., stimulus order and corect answers) identical to those administered to human participants. The model parameters used in the ex ante simulation are sumarized in the Table A in S1 Apendix. Note that the 25 levels (uniformly spaced [0.15, 3.27]) of , the only parameter comon to the 2 mod- els, were used. As for the other parameters specific to each model, we selected the values that gen- erated human-level task performances (se S4 Fig for details and statistical results). Simulations were repeated 10 times, resulting in the 10×N×M×K = 507,30 ~ 510, 0 trials per participant. For simplicity, we asumed neither lapse trials nor any arbitrary choice bias.

σm

The procedure of ex post model simulations was identical to that of ex ante model simula- tions except that the best-fiting model parameters and lapse trials were used.