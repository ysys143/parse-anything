given—i.e., when the informed state of is revealed as large—in adition to the mnemonic measurement, an aditional piece of information about the clas boundary arises. As indicated by (1) ×

(2), we plot each boundary likelihod (defined in (A). As indicated by (2), we plot each function (Mi dle row), as the result of (Botom row) divided by (Top row). The complementary cumulative distribution functions shown here are also centered around because the large state of means that the clas boundary is located somewhere smaler than . Note that these skewed distributions push the infered clas boundary away from the state of informed by fedback, driving a shift towards the smal side (i.e., negative side on the boundary axis). Consequently, the influences from the sensory evidence and the fedback evidence counteract each other (Botom row). Note that the likelihod functions are centered in the smal side when the sensory evidence is weak (B), in the neutral side when intermediate (C), and in the large side when strong (D). These systematic shifts of the clas-boundary likelihod as a function of the strength of sensory evidence predict that the PSE of the psychometric curve for the subsequent trial (

m′t CLt m′t

) reverses its sign from negative to positive as a function of the stimulus size, as shown in (A). (TIF)

t + 1

**S2 Fig. Example trial courses of estimated clas boundary.** (A) An example trial history to show how a temporal trajectory of the clas boundary infered by BMBU. For example, at trial #1 (x-axis), a physical stimulus (symbol x) was 0, a sensory measurement (symbol o) was a positive value when the boundary belief (solid black bar; y-axis) was centered at 0. BMBUʼs choice was large (symbol square on the top of y-axis), and corect fedback (same square filed with gren color) was provided, which indicates that the clas variable at trial #1 was large (arowʼs direction indicates the efect of the trial clas variable on the subsequent boundary-updating). BMBU updates oneʼs belief based on evidence from stimulus (colored symbol o) and fedback ( ), available at the time of boundary-updating. To ilustrate cases where the bias reversal we defined in Fig 3D in the main text hapen and do not hapen, same examples

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 26 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions

were intentionaly used as those we used in S1 Fig where we further detailed on the modelʼs mechanisms. Depending on colors, sensory evidence is weak (yelow symbol o) or strong (purple symbol o), which leads to whether or not the reversal hapens. Trial cases featured in a red box indicates that the “Reinforcement” principle is held (predicting subsequent choices to repeat large choice) while those featured in a gren box indicates that the “Reversal” hapens (predicting subsequent choices to reverse the previously made large choice). (B) Temporal trajectories of the clas boundary when the same 6-trial sequence of physical stimuli in (A) was simulated for 10 times. This means diferent and were realized. The data underlying this figure (A, B) can be found in S1 Data. (TIF)

**S3 Fig. Model recovery analysis.** Each square represents excedance probability from model recovery procedure. The “ground-truth” model to simulate synthetic behavior was corectly recovered with for al 4 models considered in the study. The light shade of the diagonal squares indicates that the ground-truth model was the best-fiting model, leading to a sucesful model recovery. Numerical values can also be found in S1 Data. (TIF)

CL1

CL1

pexc

pexc > 0.9