32. Burnham KP, Anderson DR. Model Selection and Inference, A Practical Information-Heuristic Aproach. New York: Springer-Verlag; 202.

3. Stephan KE, Peny WD, Daunizeau J, Moran RJ, Friston KJ. Bayesian model selection for group studies. Neuroimage. 209; 46(4):104–1017. htps:/doi.org/10.1016/j.neuroimage.209.03.025 PMID: 19306932

34. Rigoux L, Stephan KE, Friston KJ, Daunizeau J. Bayesian model selection for group studies—Revisited. Neuroimage. 2014; 84:971–985. htps:/doi.org/10.1016/j.neuroimage.2013.08.065 PMID: 24018303

35. Cao Y, Sumerfield C, Park H, Giordano BL, Kayser C. Causal inference in the multisensory brain. Neuron. 2019; 102(5):1076–1087.e8. htps:/doi.org/10.1016/j.neuron.2019.03.043 PMID: 3104 78

36. Palminteri S, Wyart V, Koechlin E. The importance of falsification in computational cognitive modeling. Trends Cogn Sci. 2017; 21(6):425–43. htps:/doi.org/10.1016/j.tics.2017.03.01 PMID: 28476348

37. Urai AE, Braun A, Doner TH. Pupil-linked arousal is driven by decision uncertainty and alters serial choice bias. Nat Comun. 2017; 8(1):14637. htps:/doi.org/10.1038/ncoms14637 PMID: 28256514

38. Zariwala HA, Kepecs A, Uchida N, Hirokawa J, Mainen ZF. The limits of deliberation in a perceptual decision task. Neuron. 2013; 78(2): 39–351. htps:/doi.org/10.1016/j.neuron.2013.02.010 PMID: 23541901

39. Renart A, Machens CK. Variability in neural activity and behavior. Cur Opin Neurobiol. 2014; 25:21–

20. htps:/doi.org/10.1016/j.conb.2014.02.013 PMID: 2463234

40. Qamar AT, Coton RJ, George RG, Beck JM, Prezhdo E, Laudano A, et al. Trial-to-trial, uncertaintybased adjustment of decision boundaries in visual categorization. Proc National Acad Sci. 2013;

10(50):2032–2037. htps:/doi.org/10.1073/pnas.121975610 PMID: 24272938

41. Sumerfield C, Behrens TE, Koechlin E. Perceptual clasification in a rapidly changing environment. Neuron. 201; 71(4):725–736. htps:/doi.org/10.1016/j.neuron.201.06.02 PMID: 2186787

42. Norton EH, Fleming SM, Daw ND, Landy MS. Suboptimal criterion learning in static and dynamic environments. PLoS Comput Biol. 2017; 13(1):e105304. htps:/doi.org/10.1371/journal.pcbi.105304 PMID: 2804606

43. Treisman M, Wiliams TC. A theory of criterion seting with an aplication to sequential dependencies. Psychol Rev. 1984; 91(1):68– 1.

4. Lages M, Treisman M. A criterion seting theory of discrimination learning that acounts for anisotropies and context efects. Seing Perceiving. 2010; 23(5):401–434. htps:/doi.org/10.163/187847510x5417 PMID: 2146134

45. Fritsche M, Mostert P, Lange FP de. Oposite efects of recent history on perception and decision. Cur Biol. 2017; 27(4):590–5.

46. Drugowitsch J, Mendonc¸a AG, Mainen ZF, Pouget A. Learning optimal decisions with confidence. Proc National Acad Sci. 2019; 16(49):24872–2480. htps:/doi.org/10.1073/pnas.190678716 PMID: 31732671

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 31 / 32

PLOS BIOLOGY