represent the ways the history factors (fedback and stimulus) exert their contribution to choice bias. In the right panels, , which quantifies the choice bias in the trials folowing a certain PDM episode at , is ploted as a function of the stimulus size at . The color indicates the direction of choice bias, as in (B) and (C).

PSEtoi+1 toi = [0;large;correct] toi

htps:/doi.org/10.1371/journal.pbio.302373.g03

δ = r − Qlarge(small) = r − p(CL = large(small)) × Vlarge(small), α δ r

where , , and are the learning rate, the reward prediction eror, and the reward, respectively. The state of fedback determines the value of : for corect; for incorect. Note that has the statistical decision confidence at the perception stage, i.e., , as one of its 3 arguments. As stresed by the authors who developed this algorithm [9], this feature makes the strength of sensory evidence—i.e., statistical decision confidence—modulate

r r = 1 r = 0 δ p(CL = large(small))

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 7 / 32

the degre to which the decision-maker updates the chosen value based on fedback (Fig 3E, left). Hence, this belief (confidence)-based modulation of value-updating underlies the stimulus-dependent fedback efects: The amount of fedback efects decreases as sensory evidence becomes stronger since the reward prediction eror decreases as a function of , which is proportional to sensory evidence (Fig 3E, right).

p(CL = large (small))

TheBayesianmodel ofboundary-updating(BMBU)

To implement the world-updating scenario, we developed BMBU, which updates the clas boundary based on the previous PDM episode in the framework of BDT. Specificaly, given “a state of the clas variable that is indicated jointly by fedback and choice,” CL, and “a noisy memory recal of the sensory measurement (which wil be refered to as ‘mnemonic measurementʼ hereinafter),” , BMBU infers the mean of the size distribution (i.e., clas boundary), , by updating its prior belief about , , with the likelihod of , , by inverting its learned generative model of how and CL are generated (Fig 3D, left; Eqs 3–6 in Materials and methods for the detailed formalisms for the learned generative model), as folows:

B B p(B) B p(m′,CL|B) m′

p(B|m′,CL) ∝ p(m′,CL|B)p(B) ≡ p(m′,C,F|B)p(B) :

This inference uses multiple pieces of information from the PDM episode just experienced, including the mnemonic measurement, choice, and fedback, to update the belief about the location of the clas boundary (refer to Eqs 8–14 in Materials and methods for more detailed formalisms for the inference). In what folows, we wil explain why and how this inference leads to the specific stimulus-dependent fedback efects predicted by the world-updating scenario (Fig 3D, right), where world knowledge is continuously updated.