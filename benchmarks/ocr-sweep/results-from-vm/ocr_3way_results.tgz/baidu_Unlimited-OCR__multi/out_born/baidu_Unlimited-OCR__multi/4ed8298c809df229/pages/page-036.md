Statistical tests

Unles otherwise mentioned, the statistical comparisons were performed using paired t tests (two-tailed, N = 30). To test the reversed fedback efects under conditions of strong sensory evidence, we aplied one-sample t tests (one-tailed, N = 27 for S7A Fig, N = 8 for S7B Fig). Repeated t tests on PSEs betwen data and model (Figs 7B, 7C and S5) were performed (two- tailed, N = 30). In Table D in S1 Apendix, we reported the number of test conditions of signif- icant deviation from the data (Bonferoni-corected threshold; : P < 0. 083, : P < 0. 0167, : P < 0. 0167). Aditionaly, Wilcoxon signed-rank tests were performed with the same threshold aplied (Table D in S1 Apendix). Repeated t tests on each cel of episode frequency maps betwen the data and the models (Figs 7E, 7F and S6) were performed, and P values were subjected to Bonferoni corection (two-tailed, N = 30; value-updating, P < 0. 0631; world-updating, P < 0. 063). Task performances betwen human agents (N = 30) and model agents with diferent sets of parameters (N = 25) were compared based on unpaired t tests (two-tailed, S4 Fig).

PLOS BIOLOGY | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 25 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions

Suportinginformation

**S1 Fig. Schematic ilustration of BMBUʼs acount of how the joint contribution of the sensory and fedback evidence to boundary updating leads to the reversal of choice bias as a function of sensory evidence strength.** (A) Reversal of subsequent choice bias—expresed in PSE—as a function of sensory evidence strength and boundary inference—expresed in likelihod computation—based on a PDM episode. Left panel: The circles with diferent colors (indicated by (b-d), which points to the coresponding panels below (B-D) represent the PSEs asociated with the boundary updating for 3 example PDM episodes, where the stimulus ( ) varies from 0 to 2 while the choice ( ) and fedback (

St Ct Ft

) are large and corect, respectively. Right panel: At the core of boundary inference is the computation of the likelihod of the clas boundary based on the mnemonic measurement ( ) and the informed state of the clas variable ( ), where is jointly determined by and (se Materials and methods for the ful computation of boundary inference in BMBU). (B-D) The likelihods of the clas boundary given the 3 example PDM episodes defined in (A), where sensory evidence varies from the low (B), to the intermediate (C), and to the high (D) level. To help understand why and how, given the same fedback evidence, the direction of boundary updating reverses as the sensory evidence strengthens, we visualize the boundary likelihods as a product of 2 functions (Eq 12), indicated by subpanels marked as (1) and

m′t CLt CLt Ft Ct

(2). Top row: As indicated by (1), we plot each boundary likelihod when only the mnemonic measurement is considered, asuming that no fedback is provided. Note that these likelihod functions are centered around the values of , by atracting the clas boundary toward themselves, driving a shift towards the large side (i.e., positive side on the boundary axis). Mi dle-Botom rows: When the fedback evidence is

m′t