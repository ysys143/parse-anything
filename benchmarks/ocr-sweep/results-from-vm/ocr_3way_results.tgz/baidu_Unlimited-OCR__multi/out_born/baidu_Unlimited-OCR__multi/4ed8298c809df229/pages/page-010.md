Lastly, at the stage of “decision,” the decision-maker comits to the choice whose expected value is greater than the other. In this platform, choice bias may originate from the perception or valuation stage. Supose the decision-makerʼs belief about size distribution at the perception stage is not fixed but changes depending on previous PDM episodes (Fig 3B, top). Such changes lead to the changes in PSE of the psychometric curve because the clas probabilities change as the clas boundary changes (Fig 3B, botom). Alternatively, supose the decision makerʼs learned values of the choices are not fixed but change similarly (Fig 3C, top). These changes also lead to the changes in PSE of the psychometric curve because the expected values change as the choice values change (Fig 3C, botom).

Thebelief-basedRLmodel

To implement the value-updating scenario, we adapted the belief-based RL model [9] to the curent experimental setup. Here, fedback acts like a reward by positively or negatively reinforcing the value of choice ( ) with the deviation of the reward outcome (r) from the expected value of that choice (

Vlarge(small) Qlarge(small)

), as folows:

Vlarge(small) ← Vlarge(small) + αδ;

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 6 / 32