
Competing interests: The authors have declared that no competing interests exist.

Abreviations: AICc, Akaike information criterion corected; BADS, Bayesian Adaptive Direct Search; BDT, Bayesian Decision Theory; BMBU, Bayesian model of boundary-updating; DVA, degre in visual angle; IBS, inverse binomial sampling; PDM, perceptual decision-making; PSE, point of subjective equality; RL, reinforcement learning; toi, trial of interest; VDM, value-based decision-making.

Unlike PDM, value-based decision-making (VDM) involves making choices based on decision-makersʼ subjective preferences (e.g., “chosing betwen two drinks based on their tastes”). Reinforcement learning (RL) algorithms have proven efective in explaining how past rewards afect future VDM based on eror-driven incremental mechanisms [12–18]. Intriguingly, there have ben atempts to explain the impact of past fedback on subsequent PDM by grafting an RL algorithm onto the PDM proceses [3,4,8–10]. This grafting premises that decision-makers treat corective fedback in PDM similarly to reward fedback in VDM. On this premise, this RL-grafting acount proposes that decision-makers update the value of their choice to minimize the diference betwen the expected reward and the actual reward received, caled “reward prediction eror” (red dashed arows in Fig 1A). Importantly, the amount of reward prediction eror is inversely related to the strength of sensory evidence—i.e., the extent to which a given sensory measurement of the stimulus suports the choice—because the expected

**Fig 1. Two posible scenarios for what humans learn from fedback for PDM and their distinct predictions of fedback efects.** (A) Decision-making platform for perceptual binary clasification. The gray arows depict how a sensory measurement and fedback are generated from a stimulus , which is sampled from the world, and a choice . The black arows depict the computational proces, where, for a given choice option, a decision-maker computes its expected value by multiplying the probability that the choice is corect given and the clas boundary with the value of that choice and make a choice based on . In principle, the decision-maker may update either (red dashed arows; value-updating) or world (gren dashed arows; world-updating) from . (B) Distinct sensory evidence–dependent fedback efects predicted by the value-updating and worldupdating scenarios. Acording to the value-updating scenario (left), as sensory evidence becomes stronger, increases, and acordingly, so does . As a result, reward prediction erors become smaler but remain in the direction congruent with fedback, which predicts that fedback efects on subsequent trials diminish asymptoticaly as a function of the strength of sensory evidence. Acording to the world-updating scenario (right), as sensory evidence becomes stronger, the stimulus distribution, and acordingly to, becomes shifted farther towards the stimulus in the direction counteracting the influence of fedback. As a result, the direction of fedback efects is the same as that predicted by the value-updating scenario for weak sensory evidence but eventualy reverses to the direction incongruent with fedback as sensory evidence becomes stronger.

m F S C

Qoption

poption m B Voption C Qoption Voption

m,C,and F

poption Qoption

htps:/doi.org/10.1371/journal.pbio.302373.g01

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 2 / 32