model. Thus, it has 9 fre parameters ( ). In Fig 6B–6D, the diferential godnes of fit measures on the y-axis indicate the subtractions of the performance of the “Base” model from those of the remaining models.

θ = {μ0,σm,σs,σ0,σm0,σdiffusion,α,β,Vinit}

Model fitting

For each participant, we fited the models to human choices over N valid trials ( ) of M (= 10) experimental runs under K (= 3) conditions, where invalid trials were the trials in which the participants did not make any response. For any given model, we denote the log likelihod of a set of parameters given the data as folows:

θ

Kcond

Mruns

Ntrials

LL(θ,model) = logp(data|θ,model) =

logp(Ci,j,k|θ,model),

k=1

j=1

i=1

where denotes the participantʼs choice (large or smal) on the i-th trial of the j-th run under the j-th condition. Computation of this is analyticaly intractable given the stochastic nature of choice determination. So, we used inverse binomial sampling (IBS; [61]), an eficient way of generating unbiased estimates via numerical simulations. The maximum-likelihod estimate of the model parameters was obtained with Bayesian Adaptive Direct Search (BADS) [62], a hybrid Bayesian optimization to find the parameter vector that maximizes the log likelihod, which works wel with stochastic target functions. To reduce the risk of being stuck at local optima, we repeated 20 independent fitings by seting the starting positions randomly using Latin hypercube sampling (lhsdesign_modifed.m by Nasim Khlaled; htps:/ w.mathworks.com/matlabcentral/fil exchange/45793-latin-hypercube) and then picked the fiting with the highest log likelihod. To avoid infinite l ops from using IBS, we did not impose individual lapse rates in an arbitrary maner. Instead, we calculated the average of the lapse rate and gues rate from the cumulative Gausian fit to a given individualʼs grand mean (based on the entire trials) psychometric curve. With these individual lapse probabilities (mean rate of 0.05, which ranged [0.051, 0.1714]), trials were randomly designated as lapse trials, in which the choice was randomly determined to be either smal or large.

Ci,j,k

LL

θ∗

Model comparisoningodnessoffit

We compared the godnes of fit of the models using AICc based on maximum-likelihod estimation fiting, as folows:

2p(p + 1) (NxMxK) − p − 1

AICc = −2 ⋅ LL(θ∗) + 2p +

where is the number of parameters of the model and the total number of trials in the dataset is
