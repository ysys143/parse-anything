4. Buse L, Ayaz A, Dhruv NT, Katzner S, Sal em AB, Scholvinck ML, et al. The detection of visual con trast in the behaving mouse. J Neurosci. 201; 31(31):1351–1361. htps:/doi.org/10.1523/ JNEUROSCI. 689-10.201 PMID: 21813694

5. Scot B, Constantinople CM, Erlich JC, Tank DW, Brody CD. Sources of noise during acumulation of evidence in unrestrained and voluntarily head-restrained rats. eLife. 2015; 4:e1308. htps:/doi.org/10. 754/eLife.1308 PMID: 2673896

6. Mendonc¸a AG, Drugowitsch J, Vicente MI, DeWit EJ, Pouget A, Mainen ZF. The impact of learning on perceptual decisions and its implication for sped-acuracy tradeofs. Nat Comun. 2020; 1 #

(1):2757. htps:/doi.org/10.1038/s41467-020-16196-7 PMID: 3248065

7. Fernberger SW. Interdependence of judgments within the series for the method of constant stimuli. J Exp Psychol. 1920; 3(2):126–150.

8. Lak A, Nomoto K, Keramati M, Sakagami M, Kepecs A. Midbrain dopamine neurons signal belief in choice acuracy during a perceptual decision. Cur Biol. 2017; 27(6):821–832. htps:/doi.org/10.1016/j. cub.2017.02.026 PMID: 2828594

9. Lak A, Hueske E, Hirokawa J, Maset P, Ot T, Urai AE, et al. Reinforcement biases subsequent per ceptual decisions when confidence is low, a widespread behavioral phenomenon. eLife. 2020; 9: e49834. htps:/doi.org/10.754/eLife.49834 PMID: 328627

10. Lak A, Okun M, Mos M, Gurnani H, Farel K, Wels MJ, et al. Dopaminergic and prefrontal basis of learning from sensory confidence and reward value. Neuron. 2020; 105(4):70–71.e6. htps:/doi.org/ 10.1016/j.neuron.2019.1.018 PMID: 31859030

1. Nogueira R, Abolafia JM, Drugowitsch J, Balaguer-Balester E, Sanchez-Vives MV, Moreno-Bote R. Lateral orbitofrontal cortex anticipates choices and integrates prior with curent information. Nat Com mun. 2017; 8(1):14823. htps:/doi.org/10.1038/ncoms14823 PMID: 283790

12. Le D, Seo H, Jung MW. Neural basis of reinforcement learning and decision making. Anu Rev Neu rosci. 2012; 35(1):287–308. htps:/doi.org/10.146/anurev-neuro-0621-150512 PMID: 2462543

# 13. Daw ND, Doya K. The computational neurobiology of learning and reward. Cur Opin Neurobiol. 206; 16(2):19–204. htps:/doi.org/10.1016/j.conb.206.03.06 PMID: 16563737

13. Suton R, Barto A. Reinforcement Learning: An Introduction. Cambridge, MA: MIT Pres; 198.

14. Corado GS, Sugrue LP, Seung HS, Newsome WT. Linear-nonlinear-poison models of primate choice dynamics. J Exp Anal Behav. 205; 84(3):581–617. htps:/doi.org/10.1901/jeab.205.23-05 PMID: 16596981

15. Lau B, Glimcher PW. Dynamic response-by-response models of matching behavior in rhesus monkeys. J Exp Anal Behav. 205; 84(3): 5–579. htps:/doi.org/10.1901/jeab.205.10-04 PMID: 16596980

16. Gla¨scher J, Daw N, Dayan P, OʼDoherty JP. States versus rewards: disociable neural prediction eror signals underlying model-based and model-fre reinforcement learning. Neuron. 2010; 6(4):585–

595. htps:/doi.org/10.1016/j.neuron.2010.04.016 PMID: 20510862

17. Le SW, Shimojo S, OʼDoherty JP. Neural computations underlying arbitration betwen model-based and model-fre learning. Neuron. 2014; 81(3):687–69. htps:/doi.org/10.1016/j.neuron.2013.1.028 PMID: 2450719