**S4 Fig. Histograms of clasification acuracies of the human participants and their model partners in the ex ante simulations.** (A, B) Acros-individual distributions of the clasification acuracy of the beliefbased RL model (A) and BMBU (B) overlaid on those of the human participants. The modelsʼ choices were generated via ex ante simulations with a specific set of model parameters (Table A in S1 Apendix), the results of which are depicted in Figs 4 and 5. The clasification acuracy is measured by calculating the percentage of the trials in which the choice matched the fedback used in the actual experiment. The empty bars corespond to the histogram of human performances, the range of which is demarcated by the dashed vertical lines ([min, max] = [60.65%, 73.94%]). The average human clasification acuracy was 67.85%. (A) Comparison of clasification acuracy betwen the belief-based RL modelʼs simulation (red color) and the human choices. The modelʼs ex ante simulation acuracy was not diferent from the human acuracy ( ; Nul hypothesis: modelʼs performance vector and humansʼ performance vector come from populations with equal means, unpaired two-tailed t test). (B) Comparison of clasification acuracy betwen BMBUʼs simulation (gren color) and the human choices. The modelʼs ex ante simulation acuracy was not diferent from the human acuracy (

, unpaired two-tailed t test). There was no significant diference in clasification acuracy betwen the value-updating model and BMBU ( , unpaired two-tailed t test). The data underlying this figure (A, B) can be found in S1 Data. (TIF)

**S5 Fig. Retrospective (left columns), prospective (mi dle columns), and subtractive (right columns) history efects in PSE for the “Hybrid” modelʼs ex post model simulations.** Top and botom rows in each panel show the PSEs asociated with the toi episodes involving corect and incorect fedback at toi. Symbols with eror bars, mean ± SEM acros the 30 model agents, which corespond to their 30 human partners. The colors of the symbols and lines label choices (blue: smal and yelow: large). The data underlying this figure can be found in S1 Data. (TIF)

**S6 Fig. Maps of frequency deviations of the value-updating (A) and world-updating (B) model agentsʼ clasifications in the ex post simulations from the human decision-makers in the retrospective (left) and prospective (right) history efects.** Each cel represents a pair

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 27 / 32

of PDM episodes, as specified by the column and row labels. At each cel, the color represents how much the episode frequency observed in the model agents deviates from that observed in the coresponding human decision-makers. The results of statistical tests on these deviations are sumarized in Fig 7E and

7F. The data underlying this figure (A, B) can be found in S1 Data. (TIF)

t(53) = 1.4429,P = 0.1549

t(53) = 0.9707,P = 0.3361

t(48) = 0.5733,P = 0.5691

**S7 Fig. Retrospective (left columns), prospective (mi dle columns), and subtractive (right columns) history efects in PSE for the human clasification performances of Urai and col- leaguesʼ work [37] (A) and Hachen and coleaguesʼ work [31] (B).** (A, B) We downloaded both publicly available datasets, analyzed them in the same way that we analyzed human observers in our work, and ploted the results in the same format used for Fig 7A. Top and bot- tom rows in each panel show the PSEs asociated with the toi episodes involving corect and incorect fedback. Symbols with eror bars, mean ± SEM acros human observers. The colors of the symbols and lines label choices (blue: smal and yelow: large).