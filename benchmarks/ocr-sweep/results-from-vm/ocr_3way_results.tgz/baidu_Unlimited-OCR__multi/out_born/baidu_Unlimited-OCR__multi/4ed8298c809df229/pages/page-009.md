![Fig 2](assets/p10_1.png)

fedback indicating whether the clasification was corect or incorect by the color around the fixation. (C) The 3D state space of the PDM episodes in the experiment. The example episode of toi in (A) is marked by the black cube. (D) Definition of retrospective and prospective history efects. As ilustrated in (A) and (C), for any given episode of toi, al the trials labeled with toi−1 and toi+1 are stacked and used to derive the psychometric curves, respectively. The PSEs estimated for the toi−1 and toi+1 psychometric curves quantify the retrospective and prospective history efects, respectively. In this example, the black and gray curves were defined for toi = [0; large; corect] and toi = [0; smal; corect], respectively, with circles and bars representing the mean and SEM acros 30 participants, respectively. The data underlying this figure (D) can be found in S1 Data. htps:/doi.org/10.1371/journal.pbio.302373.g02

and prospective trials quantify the choice biases that exist before and after the PDM episode of interest ocurs, respectively, with negative and positive values signifying that choices are biased to large and smal, respectively.

Decision-makingprocessesforbinaryclassification

As a first step of evaluating the value-updating and world-updating scenarios, we constructed a comon platform of decision-making for binary clasification where both scenarios play out. This platform consists of 3 procesing stages (Fig 3A). At the stage of “perception,” the decision maker infers the clas probabilities, i.e., the probabilities that the ring size (S) is larger and smaler, respectively, than the clas boundary (B) given a noisy sensory measurement (m), as folows:

where CL stands for the clas variable with the 2 (smal and large) states.

At the stage of “valuation,” the decision-maker forms the expected values for the 2 choices ( and ) by multiplying the clas probabilities by the learned values of the coresponding choices (

p(CL = large) = p(S > B|m) = ∫

p(CL = small) = 1 − p(CL = large),

Qlarge Qsmall Vlarge Vsmall

and ) as folows:

Qlarge = p(CL = large) × Vlarge; Qsmall = p(CL = small) × Vsmall.