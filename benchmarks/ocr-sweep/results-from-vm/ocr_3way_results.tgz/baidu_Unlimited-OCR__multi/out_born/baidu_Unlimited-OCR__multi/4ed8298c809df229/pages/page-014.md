We stres that this “stimulus-dependent bias reversal” is a halmark of the world-updating scenarioʼs prediction of the history efects in PDM. Specificaly, the direction of bias reversal is always from smal to large as long as the fedback in conjunction with the choice indicates (e.g.,

CL = small

or

{S = 0 → −1 → −2,C = small,F = correct} {S = 0 → −1 → −2,C = large,F = incorrect}

) and always from large to smal as long as the fedback in conjunction with the choice indicates (e.g.,

CL = large {S = 0 → 1 → 2,C = large,F = correct} {S = 0 → 1 → 2,C = small,F = incorrect}

or ). Criticaly, the value-updating scenario does not predict the bias reversal (Fig 3E, right). It predicts that the fedback efects only asymptoticaly decrease as a function of sensory evidence but never switch to the other direction. This is because the decision confidence, , only modulates the amount of value-updating but never changes the direction of value-updating.

p(CL = large(small))

Exantesimulationofthefeedbackeffectsunderthe2 scenarios

Above, we have conceptualy explained why and how the 2 scenarios imply the distinct paterns of stimulus-dependent fedback efects. Though this implication sems intuitively aparent, it must be confirmed under the experimental seting of the curent study. Moreover, there are god reasons to expect any history efect to exhibit complex dynamics over trials. First, sensory and mnemonic measurements are subject to stochastic noises, which propagates through decision-making and value/boundary-updating proceses to subsequent trials (e.g., a sensory measurement that hapens to fal on a relatively smal side is likely to lead to a smal choice, which afects the subsequent value/boundary-updating proces, and so on). Second, provided that any deterministic value/boundaryupdating proceses are presumed to be at work, the PDM episode on a given trial must, in principle, be probabilisticaly conditioned on the episodes in past trials (e.g., the curent smal choice on the ring of

is likely to have folowed the previous episodes leading to “boundary-updating in the large direction” or “positive value-updating of the smal choice”). Third, 2 steps of deterministic value/boundary-updating ocur betwen what can be observed at and at (as indicated by the psychometric curves in Fig 4A), once folowing the episode at ( in Fig 4A) and next folowing the episode at ( in Fig 4A). Thus, the diferences betwen the retrospective and prospective history efects should be construed as reflecting not only but also . The nuanced impacts of this hi den updating on the history efects must be complicated and thus be inspected with realistic simulations. Further, considering that these multiple stochastic and deterministic events interplay to create diverse temporal contexts, history efects are suposed to reveal themselves in multiplexed dynamics.

S = 0

toi − 1 toi + 1 toi − 1 Utoi−1

toi Utoi

Utoi Utoi−1

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 9 / 32