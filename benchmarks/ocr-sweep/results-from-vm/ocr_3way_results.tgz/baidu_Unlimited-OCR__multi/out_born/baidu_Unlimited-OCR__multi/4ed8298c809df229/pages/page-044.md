47. Mochol G, Kiani R, Moreno-Bote R. Prefrontal cortex represents heuristics that shape choice bias and its integration into future behavior. Cur Biol. 2021; 31(6):1234–124.e6. htps:/doi.org/10.1016/j.cub. 2021.01.068 PMID: 3639107

48. Gupta D, Brody CD. Limitations of a proposed corection for slow drifts in decision criterion. arXiv pre print arXiv: 20510912. 202.

49. Car EH. What is History? London: University of Cambridge & Penguin Boks; 1961.

50. Wichman FA, Hil NJ. The psychometric function: I. Fiting, sampling, and godnes of fit. Percept Psy chophys. 201; 63(8):1293–1313. htps:/doi.org/10.3758/bf0319454 PMID: 180458

51. Wichman FA, Hil NJ. The psychometric function: I. Botstrap-based confidence intervals and sam pling. Percept Psychophys. 201; 63(8):1314–1329. htps:/doi.org/10.3758/bf03194545 PMID:

52. Schu¨t H, Harmeling S, Macke JH, Wichman FA. Painfre and acurate Bayesian estimation of psy chometric functions for (potentialy) overdispersed data. Vision Res. 2016; 12:105–123. htps:/doi. org/10.1016/j.visres.2016.02.02 PMID: 27013261

53. Ma WJ. Organizing probabilistic models of perception. Trends Cogn Sci. 2012; 16(10):51–518. htps:/ doi.org/10.1016/j.tics.2012.08.010 PMID: 2981359

54. Haefner RM, Berkes P, Fiser J. Perceptual decision-making as probabilistic inference by neural sam pling. Neuron. 2016; 90(3):649–60. htps:/doi.org/10.1016/j.neuron.2016.03.020 PMID: 27146267

# 5. Le H, Le HJ, Choe KW, Le SH. Neural evidence for boundary updating as the source of the

repulsive bias in clasification. J Neurosci. 2023; 43(25):464–4683. htps:/doi.org/10.1523/JNEUROSCI.016- 23.2023 PMID: 37286349

56. Wilken P, Ma WJ. A detection theory acount of change detection. J Vis. 204; 4(12):1. htps:/doi.org/ 10.167/4.12.1 PMID: 156916

57. Bays PM, Gorgoraptis N, We N, Marshal L, Husain M. Temporal dynamics of encoding, storage, and realocation of visual working memory. J Vis. 201; 1(10):htps:/doi.org/10.167/1.10.6 PMID: 2191739

58. Lu L, Stocker A. Post-decision biases reveal a self-consistency principle in perceptual inference. eLife. 2018; 7:e 34. htps:/doi.org/10.754/eLife. 34 PMID: 29785928

59. Lu L, Stocker A. Categorical judgments do not modify sensory representations in working memory. PLoS Comput Biol. 2021; 17(6):e108968. htps:/doi.org/10.1371/journal.pcbi.108968 PMID: 34061849

60. Daw ND OʼDoherty JP, Dayan P, Seymour B, Dolan RJ. Cortical substrates for exploratory decisions in humans. Nature. 206; 41(7095):876–879.

61. Opheusden B van, Acerbi L, Ma WJ. Unbiased and eficient log-likelihod estimation with inverse bino mial sampling. PLoS Comput Biol. 2020; 16(12):e108483. htps:/doi.org/10.1371/journal.pcbi. 108483 PMID: 362195

62. Acerbi L, Ma WJ. Practical Bayesian optimization for model fiting with Bayesian adaptive direct search. Adv Neural Inf Proces Syst 2017; 30:1836–1846.

63. Daunizeau J, Adam V, Rigoux L. VBA: A Probabilistic Treatment of Nonlinear Models for Neurobiologi cal and Behavioural Data. PLoS Comput Biol. 2014; 10(1):e10341. htps:/doi.org/10.1371/journal. pcbi.10341 PMID: 2465198