Dataanalysis

For any given PDM episode at a toi, we quantified the retrospective and prospective history efects by probing the psychometric curves at the trials before and after toi, respectively. The psychometric function ( ) was estimated by fiting the cumulative Gausian distribution ( ) to the curves using Psignifit package [50–52] (htps:/github.com/wichman-lab/psignifit), as folows:

ψ(x) F

ψ(x;μ,σ) = F(x;μ,σ), μ σ F μ

where and are the mean and standard deviation of . By finding the best-fiting value of , we defined the PSE (the stimulus level with equal probability for a smal or large choice), which was used as the sumary statistics that quantifies the history efects asociated with a given PDM episode. To ensure reliable PSE estimates, we acquired botstrap samples ( ) of psychometric curves based on the binomial random proces and tok their aver- age as the final estimate for each PDM episode. In our main data analysis, the results of which are displayed in Fig 7, we chose not to include the parameters for gues or lapse rates in esti- mating PSEs. This was done to prevent unfair overfiting problems from ocuring in infre- quent episode types with smal numbers of trials available for fiting. On the other hand, to preclude any potential confounding problem related to the task dificulty asociated with PDM

N = 5,000

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 18 / 32

episode types, we also repeated the above PSE estimation procedure with gues () and lapse ( ) rates included as fre parameters: . The results did not difer betwen the original estimation procedure without the lapse and gues rates and the procedure with the lapse and gues rates (Bonferoni-corected P = 0.2023 ~ 1. 0; paired two-tailed t tests; se S2 Data for detailed statistical information).

γ λ ψ(x;μ,σ,γ,λ) = γ + (1 − γ − λ)F(x;μ,σ)

Value-updatingmodel

As a model of the value-updating scenario, we used the belief-based RL model proposed in the previous work [9,10]. This model incorporates RL algorithm into the conventional Bayesian formalism of decision confidence—also known as statistical decision confidence using a partialy observable Markov decision proces (Fig 3E). In this model, the decision-maker, given sensory measurement , computes the probability that the stimulus belongs to “large” ( ) or “smal” ( ) clas (hereinafter the pcomputation), where . This probability wil be refered to as a “belief-state,” as in the

m pL pS = 1 − pL

pL = ∫μ∞

original work [9,10]. Here, the probability distribution is defined as a normal distribution with mean and standard deviation . Whereas was asumed to be zero in the original work, we set fre as a constant parameter to alow the belief-based RL model to deal with any potential individualsʼ idiosyncratic choice bias, as we wil alow the world-updating model (BMBU) to do so (se below). Next,

p(S|m) m σm μ0 μ0