p(Bt|m′t,CLt) ∝ p(m′t,CLt|Bt)p(Bt). (13) t p(Bt−1|m′t−1,CLt−1) Bt

We asumed that, at the begi ning of the curent trial , the decision-maker recals the posterior belief

formed (Eq 13) from the previous trial—to use it as the prior of —into the curent working memory space, and it is thus subject both to decay and difusive noise during the recal proces. As a result, the prior is basicaly the recaled posterior, defined as the normal distribution as folows:

λ σdiffusion p(Bt)

N(B^t,σ2B

B^t = λB^postt−1 + (1 − λ)μ0; σ2B

= λσ2t−1post + σ2diffusion, (14)

B^postt−1 σ2t−1post λ = σ

where and denote mean and variance of the previous trialʼs posterior distribution. Note that the decay parameter influences the width and location of the belief distribution and that the difusive noise of helps to kep the width of the distribution over multiple trials, thus avoiding sharpening and stoping the updating proces [60]. In this way, and alow BMBU to adres the idiosyncratic choice bias and noise, as we equip the belief-based RL model to do so with and the sofmax rule. In sum, BMBU posits that human individuals cary out a sequence of binary clasification trials with their learned generative model while continualy updating their belief about the location of the clas boundary in that generative model. BMBU describes these decision-making and boundary-updating proceses using a total of 6 parameters ( ), which are set fre to acount for individual diferences.

2 0

σ20+σ2t−1post

σdiffusion > 0

λ σdiffusion

μ0

θ = {μ0,σm,σs,σ0,σm′

,σdiffusion}

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 23 / 32

PLOS BIOLOGY Corective fedback on perceptual decisions

Referencemodels

As the references for evaluating the belief-based RL model and BMBU in predicting the variability of human choices, we created 3 reference models. The “Base” model captures the choice variability that can be explained by the -computation with the clas boundary fixed at 0 unanimously for al participants and without any value-updating proces. Thus, it has only a single fre parameter representing the variability of the sensory measurement ( ). The “Fixed” model captures the choice variability that can be explained by the -computation with the clas boundary set fre to a fixed constant for each participant and without any value-updating proces. Thus, it has 2 fre parameters ( ). The “Hybrid” model captures the choice variability that can be explained both by the -computation with the infered clas boundary by BMBU and by the value-updating proces implemented by the belief-based RL

θ = {σm} p μ0

θ = {μ0,σm} p