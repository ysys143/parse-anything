S1 Data. Excel spreadshet containing, in separate shets, the underlying numerical data for Figs 2D, 4B, 4D, 4E, 4G, 4H, 5B, 5D, 5E, 5G, 5H, 6B, 6C, 6D, 7A, 7B, 7C, 7D, 7E, 7F, S2A, S2B, S3, S4A, S4B, S5, S6A, S6B, S7A and S7B. (XLSX)

S2 Data. Excel spreadshet containing detailed statistical information comparing alternative PSE estimation methods. (XLSX)

Acknowledgments

The authors are grateful to Daeyeol Le for his insightful coments and inspiring conversations concerning the prior version of the manuscript.

AuthorContributions

Conceptualization: Hyang-Jung Le, Heseung Le, Sang-Hun Le. Data curation: Isac Rhim. Formal analysis: Hyang-Jung Le. Funding acquisition: Sang-Hun Le. Investigation: Hyang-Jung Le. Methodology: Hyang-Jung Le, Chae Young Lim, Sang-Hun Le. Resources: Sang-Hun Le. Software: Hyang-Jung Le. Supervision: Sang-Hun Le. Validation: Hyang-Jung Le, Chae Young Lim, Sang-Hun Le. Visualization: Hyang-Jung Le, Sang-Hun Le. Writing – original draft: Hyang-Jung Le. Writing – review & editing: Hyang-Jung Le, Heseung Le, Chae Young Lim, Isac Rhim, Sang-Hun Le.

References

1. Gold JI, Law CT, Conoly P, Benur S. The relative influences of priors and sensory evidence on an oculomotor decision variable during perceptual learning. J Neurophysiol. 208; 10(5):2653–268. htps:/doi.org/10.152/jn.90629.208 PMID: 1875326

2. Hwang EJ, Dahlen JE, Mukundan M, Komiyama T. History-based action selection bias in posterior parietal cortex. Nat Comun. 2017; 8(1):1242. htps:/doi.org/10.1038/s41467-017-01356-z PMID: 2908950

PLOS BIOLOGY Corective fedback on perceptual decisions PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 29 / 32

PLOS BIOLOGY Corective fedback on perceptual decisions

3. Abrahamyan A, SilvaL, Dakin SC, Carandini M, Gardner JL. Adaptable history biases in human per ceptual decisions. Proc National Acad Sci. 2016; 13(25):E3548–E357. htps:/doi.org/10.1073/pnas. 151878613 PMID: 273086