any given model is more frequent than the other models (pro- tected excedance probability; dots with horizontal bars in Fig 6D). Both measures corobo- rated the outcomes of the pairwise comparisons: The world-updating model predominated in expected posterior probability (0.592) and protected excedance probability (0.8938).

In sum, the world-updating scenario was superior to the value-updating scenario in pre- dicting the choice behavior of human participants performing the binary clasification task.

Expostsimulationofthefeedbackeffectsunderthe2 scenarios

The godnes of fit results sumarized above simply indicate that the world-updating model is beter than the value-updating model in predicting the trial-to-trial variability in choice behavior while taking into acount model complexity. Our study aims to examine whether these 2 competing models of interest can acount for the stimulus-dependent fedback efects observed in human decision-makers. To do so, we caried out ex post simulations based on the godnes of fit results [36] by testing whether the valueupdating and world-updating models can reproduce the observed stimulus-dependent fedback efects.

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 13 / 32