PLOS BIOLOGY Corective fedback on perceptual decisions

**Fig 5. Ex ante simulation results for the PDM episodes with incorect fedback.** The format is identical to that in Fig 4. The data underlying this figure (B, D, E, G, H) can be found in S1 Data.

htps:/doi.org/10.1371/journal.pbio.302373.g05

conditioned on the toi with weak sensory evidence because the stochastic bias consistent with the choice that would be made in the toi is required more in those trials. This testifies to the presence of the complex dynamics of history efects discused above and is also consistent with what has ben previously observed (e.g., se Fig 2 of the previous study [9]). Importantly, in line with our conceptual conjecture (Fig 3D and 3E), the 2 agents evidently disagre on the prospective history efects. While the valueupdating agent always exhibits the fedback-congruent bias but never reverses the direction of bias, the world-updating agent shows the fedback-congruent bias after viewing the ambiguous stimulus but progresively reversed the direction of bias as the stimulus evidence suporting the decision becomes stronger (Fig 4C, 4D and 4F–4H).

Next, Fig 5 sumarizes the history efects for the PDM episodes with incorect fedback. The retrospective history efects show that both agents exhibit the choice bias consistent with the choice they wil make next trial, as in the case for corect fedback, but the amounts of bias are much greater compared to those in the corect-fedback condition (Fig 5B and 5E). These pronounced retrospective efects conditioned on the incorect-fedback episodes are intuitively understod as folows: The valueupdating agentʼs value ratio or the world-updating agentʼs clas boundary was likely to be somehow “unusualy and strongly” biased before the toi, given that they make an incorect—thus “unusual”—choice in the toi. Suporting this intuition, the

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 20231 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions

retrospective bias increases as sensory evidence increases, since the prior value ratio or clas boundary must be strongly biased to result in that particular incorect choice despite such strong sensory evidence. Importantly, despite these large retrospective biases, the prospective history efects indicate that both agents adjust their value and clas boundary, respectively, in their own maners identical to those for the corect-fedback episodes (Fig 5C, 5D, 5F and 5G). Thus, as in the case of the corect-fedback episodes, the direction reversal is displayed only by the world-updating agent, but not by the valueupdating agent (Fig 5H).

In sum, the ex ante simulation confirmed that the bias reversal of the stimulus-dependent fedback efects ocurs only under the world-updating scenario but not under the value- updating scenario, regardles of the (corect or incorect) states of fedback. The simulation results also confirmed that, with the curent experimental seting, we can empiricaly deter- mine which of the 2 scenarios provides a beter acount of fedback efects.