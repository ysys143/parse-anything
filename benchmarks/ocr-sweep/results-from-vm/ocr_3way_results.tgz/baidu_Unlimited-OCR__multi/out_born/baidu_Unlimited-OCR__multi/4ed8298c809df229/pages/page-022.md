The ex post simulation was identical to the ex ante simulation except that each decision-makerʼs best-fit model parameters were used (Table B in S1 Apendix; Materials and methods). We asesed how wel the models reproduce the human history efects of fedback in 2 diferent ways. First, we compared the models and the humans similarly to the ex ante simulation (Fig 7A–7C). We included the PDM episodes with nonveridical fedback (symbols with doted lines in Fig 7A–7C), though those episodes infrequently ocured (12.09 ± 0.02% (mean ± SEM) out of total toi episode trials; bars with doted outlines in Fig 7D). As a result, we inspected the retrospective and prospective history efects, and their diferences, for al the posible combinations of “stimulus,” “choice,” and “fedback” (20 PDM episodes in total), which resulted in a total of 60 PSE pairs to compare. The PSEs simulated by the world-update model closely matched the human PSEs, in both patern and magnitude (Fig 7A and 7C), whereas those by the valueupdate model substantively deviated from the human PSEs (Fig 7A and 7B). The statistical comparison (paired two-tailed t tests with Bonferoni corection)

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 14 / 32

indicates that the value-updating modelʼs PSEs significantly deviated from the coresponding human PSEs for almost half of the entire pairs (29 out of 60 pairs), whereas none of the world-updating modelʼs PSEs significantly difered from the human PSEs (0 out of 60 pairs). Notably, most mismatches ocured because the value-updating model does not reverse the direction of fedback efects as sensory evidence becomes stronger while humans do so (compare the third columns of Fig 7A and 7B).

Second, we compared the models and the humans in the probability distribution of retrospective and prospective episodes conditioned on each episode of (Fig 7D–7F). This comparison alows us to ases the modelsʼ reproducibility not just for fedback efects but also for the history efects in general and to explore the origin of the value-based modelʼs failure. By colapsing al the preceding and folowing trials onto each of the 20 episodes (the columns of Fig 7E and 7F) and computing their probability distributions acros—again—the 20 types of and 20 types of episodes (the rows of Fig 7E and 7F), respectively, we could create 40 joint-probability cels.

toi

toi

toi − 1 toi + 1

We caried out repeated tests with Bonferoni corection to se where the model-human mismatches ocur (data were mising for a few cels—mostly those including nonveridical fedback episodes, as indicated by the empty cels in Fig 7E and 7F, because those episodes were to rare (Fig 7D) to ocur for al participants). For the remaining cels, the world-updating model showed a remarkable level of corespondence with the humans, deviating from the humans at only 2 cels (out of 790 cels, 0.25%; Fig 7F). By contrast, the value-updating model failed to match the humans for 94 cels (out of 792 cels,

1.87%; Fig 7E). Here, the mismatches ocured systematicaly: They were frequent when the preceding episode defining any given cel (i.e., episodes at for the retrospective cels or episodes at for the prospective cels) was featured with strong sensory evidence (as indicated by the arows in Fig 7E). This systematic deviation precisely reflects the incapability of the value-updating model to reverse the direction of fedback efects as sensory evidence strengthens.

toi − 1 toi

In sum, the stimulus-dependent history efects of fedback observed in humans could be reproduced by the world-updating scenario but not by the value-based scenario.