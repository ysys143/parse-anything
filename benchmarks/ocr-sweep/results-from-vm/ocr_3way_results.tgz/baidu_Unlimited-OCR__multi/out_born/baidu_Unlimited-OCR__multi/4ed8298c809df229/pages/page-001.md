outperforms the former in explaining how corective fedback adjusts the decision-making strategy along with past stimuli and choices. Our work sugests that humans learn about what has hapened in their environment rather than the values of their own choices through corective fedback during perceptual decision-making.

Introduction

Perceptual decision-making (PDM) means comiting to a proposition about an objective world state (e.g., “The temperature today is low.”). Decision-makers adjust future comitments based on what they experienced from past comitments, including what they perceived, what they chose, and what the environment gave them in return. Among these history factors, trial-to-trial corective fedbackfedback about the corectnes of a decision-makerʼs choices on a trial-to-trial basis—is widely used by experimenters to train participants on PDM tasks. Despite this clear utility of fedback and a pile of evidence for its impact on subsequent PDM behavior acros species and sensory modalities [1–1], much remains elusive about how corective fedback, in conjunction with other history factors, exerts its trialto-trial influence on subsequent decisions.

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 1 / 32

![figure](assets/p2_2.png)
