Quantifyingtheretrospectiveandprospectivehistoryefectsof fedbackonbinaryclasification

To study the stimulus-dependent fedback efects in PDM, we acquired long sequences (170 trials/sequence) of binary choices ( ) many times (30 sequences/participant) from each of 30 human participants while varying the ring size ( ) and providing corective fedback ( ) (Fig 2A). On each trial, participants viewed a ring, judged whether its size is smal or large as acurately as posible while receiving fedback, which indicated by color whether the choice was corect or incorect (Fig 2B). We ensured the ring size varied suficiently—including the ones very easy and dificult for clasification—so that the 2 scenariosʼ distinct predictions on the stimulus-dependent fedback efects could be readily compared. Also, we used stochastic fedback, where corect and incorect fedback was ocasionaly given to incorect and corect choices, respectively, to cover the entire 3D space of decision-making episodes defined orthogonaly over “stimulus,” “choice,” and “fedback” ( episodes; Fig 2C; Materials and methods).

C ∈ {small,large}

S ∈ {−2,−1,0,1,2} F ∈ {correct,incorrect}

# 5 × 2 × 2 = 20

To rigorously evaluate the corespondence betwen model prediction and human behavior, we quantified the history efects in both retrospective and prospective directions of time, as folows (Fig 2D). First, we localized the trials in which a PDM episode of interest ocured (trial of interest, toi) and stacked the trials that preceded (the retrospective block of trials, toi−1) and those that folowed (the prospective block of trials, toi+1) the toi. Second, we derived the 2 psychometric curves from the retrospective and prospective blocks of trials, respectively, and fit the cumulative normal distribution function to these curves to estimate the point of subjective equality (PSE) measures, which have previously ben used [19– 21] and known to reliably estimate the history-dependent choice biases in PDM [31]. Thus, the PSEs of the retrospective

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 4 / 32

PLOS BIOLOGY Corective fedback on perceptual decisions

A toi = [0; large; corect] # 170 trials/run

B binary clasification of ring size Stimulus Choice Fedback

C

D

S ∈ {−2,−1,0,1,2} C ∈ {small,large} F ∈ {correct,incorrect}

**Fig 2. Experimental design and definition of retrospective and prospective history efects.** (A) A chain of PDM episodes over a single sequence of trials. Each trial sequence consists of 170 column vectors of PDM episode [stimulus; choice; fedback]. In this example, the trial of interest (toi) is characterized by an