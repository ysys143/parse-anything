the expected values of the 2 choices and can be obtained by and multiplied with the learned values of the options of smal and large, and , respectively. Acordingly, the expected value

QS QL pS pL VS VL QC QS QL

is also defined separately for the choice made betwen smal and large: and .

In the original work, the argmax rule was aplied to determine the choice (i.e., the higher determines the choice ). Instead, here, we aplied the softmax rule, which selects large with probability

Q C

exp(βQL)

(the higher preferentialy selects ) where is an inverse temperature. This feature

exp(βQS)+exp(βQL) Q C β

did not exist in the original model but was introduced here to alow the belief-based RL model to deal with stochastic noise at the decision stage, as we alow the world-updating model (BMBU) to do so.

The initial values of smal and large choices were set identicaly as a fre parameter . Upon receiving fedback on the decision, the decision-maker updates the value of the selected choice by the reward prediction eror with learning rate :

Vinit

VC δ α

VC ← VC + αδ

No temporal discounting is asumed for simplicity. Since the decision-maker treats corective fedback as rewards (corect: , incorect: ), the reward prediction eror is computed as the deviation of the reward from the expected value:

r = +1 r = 0 δ

δ = r − QC = r − pCVC pC δ δ pC

Note that the belief state (i.e., statistical decision confidence) modulates such that increases as decreases, which is the crucial relationship constraining the belief-based RL modelʼs key prediction on the stimulus-dependent fedback efects. Specificaly, upon corect fedback, wil take a positive value and reinforce the choice value. However, as increases, the magnitude of such reinforcement wil decrease. Criticaly, despite the decrease of reinforcement as a function of , the sign of reinforcement wil never be reversed until the expected value reaches the maximum reward value ( ). Based on the same ground, the sign of reinforcement wil never be reversed either in the case of incorect fedback. The fre parameters of the value-updating model are .

δ pC

pC Q r = 1

θ = {μ0,σm,α,β,Vinit}

PLOS BIOLOGY | Corective fedback on perceptual decisions

World-updatingmodel

As a model of the world-updating scenario, we developed the BMBU. BMBU shares the same platform for PDM with the belief-based RL model (as depicted in Figs 1A and 3A) but, as a BDT model, makes decisions using its “learned” generative model while continualy updating its belief about the clas boundary , the key latent variable of that internal model (as depicted in the left panel of Fig 3D).
