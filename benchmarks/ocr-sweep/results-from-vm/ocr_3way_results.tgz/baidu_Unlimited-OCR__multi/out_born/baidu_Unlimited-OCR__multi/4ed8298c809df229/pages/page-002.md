This figure depicts the experimental timeline of a perceptual decision-making task. The horizontal axis represents time in miliseconds, with specific intervals marked for fixation, stimulus presentation, response, and fedback. The sequence ilustrates the trial progresion, starting with a 50 ms fixation period folowed by a stimulus, a response phase, and a 1 0 ms fedback period.

PLOS BIOLOGY | Corective fedback on perceptual decisions

org/10.5281/zenodo.8427373). Al other relevant data, including numerical data underlying each figure, are within the paper and its Suporting Information files.

Funding: This research was suported by the Seoul National University (SNU) Research Grant 39202013 (to S.-H. L.), by the Brain Research Program through the National Research Foundation of Korea (NRF) funded by the Ministry of Science and Information and Comunications Technology (MSIT) Grant No. NRF-2021R1F1A1052020 (to S.-H. L.), and by the Basic Research Laboratory Program through NRF funded by MSIT Grant No. NRF-2018R1A4A1025891 (to S.-H. L.). The funders had no role in study design, data colection, analysis, the decision to publish, or manuscript preparation.

![figure](assets/p3_1.png)