p(m′t,CLt = small|Bt) = ∫

p(m′t|St)p(St|Bt)dSt;

p(m′t,CLt = large|Bt) = ∫

p(m′t|St)p(St|Bt)dSt (10)

p(m′t|St) = N(m′t;St,σ2m′ + σ2m) S → m → m′

where , acording to the “chain” relations defined in the learned generative model ( in the left panel of Fig 3D; Eqs 5 and 6; se Equation S2 for derivations in Text in S1 Apendix). Eq 10 indicates that BMBU calculates how likely hypothetical boundary states bring about the mnemonic measurement ( ) while taking into acount the informed state of the clas variable ( ), by constraining the posible range of the stimulus states. To help readers intuitively apreciate these respective contribu- tions of the mnemonic measurement and the informed state of the clas variable (fedback) to the boundary likelihod, we further elaborated on how Eq 9 is reduced to Eq 10 depending on the informed state of (se Text in SI Apendix and S1 Fig).

B → S → m → m′ B → CL ← S

CLt = small N(St;Bt,σ2S) p(m′t|St) = N(m′t;St,σ2m′ + σ2m)

Lastly, we evaluate the integral for in Eq 10 by substituting $p(S_t|B_t) = $ and , from the defined statistical knowledge in the

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 2 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions

learned generative model (Eq 3 and Eqs 5 and 6, respectively) and find:

p(m′t,CLt = small|Bt)

# 1 √2π( σ

# 2 Mσ2S

σ2M+σ2S )

Btσ2

tσ2

S σ2

+σ2 S

σ2 M

σ2

S σ2

M+σ2

S dSt ×

e

# 1 √2π(σ2M + σ2S)

(Bt−m′

t)2 2(σ2

e−

+σ2 S

σ2M = σ2m′

where . For the other state in fedback, we evaluate the integral in the same maner and find:

p(m′t,CLt = large|Bt)

# 1 √2π( σ

# 2 Mσ2S

σ2M+σ2S )

Btσ2

tσ2

S σ2

+σ2 S

σ2 M

σ2

S σ2

+σ2

S dSt ×

e

# 1 √2π(σ2M + σ2S)

(Bt−m′

t)2 2(σ2

e−

+σ2 S

Having calculated the likelihod of , we turn to describe (i) how BMBU combines that likelihod with a prior distribution on trial , which forms a posterior distribution of acording to Bayes rule:

Bt t Bt