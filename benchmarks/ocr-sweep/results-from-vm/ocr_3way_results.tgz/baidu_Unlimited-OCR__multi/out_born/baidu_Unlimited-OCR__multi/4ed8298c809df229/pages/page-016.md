heads of the colored arows at the top indicate the clas boundary before and after , respectively. (H) Juxtaposition of the diferences betwen the retrospective and prospective history efects displayed by the 2 model agents. (C, F) The contributions of both sensory and fedback evidence are indicated by Sevidence and F-evidence, respectively. (B, D, E, G) Data points are the means and SEMs acros the parameter sets used in ex ante simulations (se Materials and methods). The data underlying this figure (B, D, E, G, H) can be found in S1 Data.

htps:/doi.org/10.1371/journal.pbio.302373.g04

Hence, we simulated ex ante the 2 models over a reasonable range of parameters by making the model agents perform the binary clasification task on the sequences of stimuli that wil be used in the actual experiment (Table A in S1 Apendix, S4 Fig, and Materials and methods). The simulation results confirmed our intuition, as sumarized in Fig 4, which shows the retrospective and prospective history efects for the PDM episodes with corect fedback. Notably, the retrospective history efects indicate that both value-updating and world-updating agents were already slightly biased to the choice they are about to make in the—folowing—toi (Fig 4B and 4E). One readily intuits that such retrospective biases are more pronounced when

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 10 / 32

![Fig 5](assets/p17_1.png)

