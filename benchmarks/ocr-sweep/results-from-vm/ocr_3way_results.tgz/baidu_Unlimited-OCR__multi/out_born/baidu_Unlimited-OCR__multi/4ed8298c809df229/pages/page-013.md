Supose a decision-maker curently believes that the size distribution is centered around 0. Let us first consider a case where the decision-maker experiences a PDM episode with an ambiguous stimulus: The ring with size 0 is presented and produces a sensory measurement that is only slightly greater than 0 (through the stochastic proces where is generated from ; Eq 5), which leads to the large choice since the infered from such is greater than the center of the size distribution (Eqs 4 and 7), and then folowed by corect fedback. BMBU predicts that after this PDM episode, the decision-maker wil update the belief about the size distribution by shifting it towards the smaler side. Hence, the choice in the next trial wil be biased towards the larger option, resulting in a negatively biased PSE for the psychometric curve defined by the trials folowing the episode of interest. This is because the impact of the mnemonic measurement on boundary-updating is minimal, whereas that of the informed clas variable is substantial. After the above episode, the decision-makerʼs noisy mnemonic measurement is also likely to be slightly larger than 0 since is an unbiased random sample of the sensory measurement (Eq 6). Thus, the impact of on boundary updating is minimal because is close to 0 and thus only slightly atracts the clas boundary. On the contrary, the impact of the informed state of the clas variable on boundary updating is relatively substantial, pushing the clas boundary towards the regime consistent with the informed state of (Eqs 9–12), which is the smaler side. As a result, the clas boundary is negatively (towards smal-side) biased, which leads to the negative bias in the PSE of the psychometric curve defined from the trials folowing the episode of interest (as depicted by the left (yelow) regime in the plot of Fig 3D).

m m S

m′ m m′ m′

CL

CL

Next, to apreciate the stimulus-dependent nature of fedback efects in the world-updating scenario, let us consider another case where the decision-maker experiences a PDM episode with an unambiguous stimulus: The ring with size 2 is presented and produces a sensory measurement that fals around 2, which leads to the large choice and then folowed by corect

PLOS Biology | htps:/doi.org/10.1371/journal.pbio.302373 November 8, 2023 8 / 32

PLOS BIOLOGY | Corective fedback on perceptual decisions

fedback. After this episode, as in the previous case with an ambiguous stimulus, the informed state of the clas variable ( ) shifts the clas boundary to the smaler side. However, unlike the previous case, the impact of the mnemonic measurement on boundary-updating, which is likely to be around 2, is substantial, resulting in a shift of the boundary towards the far larger side. Consequently, the clas boundary becomes positively (towards-large-side) biased. Here, the mnemonic measurement and the informed state of the clas variable exert conflicting influences on boundary updating. Since the mnemonic measurement increases as the stimulus size grows (e.g., ), the relative impact of the mnemonic measurement on boundary-updating is increasingly greater as the stimulus size grows, eventualy overcoming the counteracting influence of the informed state of the clas variable (S1 Fig). As a result, the bias in the clas boundary is initialy negative but is progresively reversed to be positive as the stimulus size grows, which leads to the bias reversal in the PSE of the psychometric curve defined from the trials folowing the episode of interest (as depicted by the right (blue) regime in the plot of Fig 3D).

CL = large

S = 0 → 1 → 2