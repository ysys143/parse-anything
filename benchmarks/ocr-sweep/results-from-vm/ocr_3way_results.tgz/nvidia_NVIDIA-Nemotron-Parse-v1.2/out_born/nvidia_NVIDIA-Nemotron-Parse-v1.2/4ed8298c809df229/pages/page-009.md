![Fig 2](assets/p10_1.png)

<x_0.1504><y_0.1898>feedback indicating whether the classification was correct or incorrect by the color around the fixation. (C) The 3D state space of the PDM episodes in the experiment. The example episode of toi in (A) is marked by the black cube. (D) Definition of retrospective and prospective history effects. As illustrated in (A) and (C), for any given episode of toi, all the trials labeled with toi–1 and toi+1 are stacked and used to derive the psychometric curves, respectively. The PSEs estimated for the toi–1 and toi+1 psychometric curves quantify the retrospective and prospective history effects, respectively. In this example, the black and gray curves were defined for toi = [0; large; correct] and toi = [0; small; correct], respectively, with circles and bars representing the mean and SEM across 30 participants, respectively. The data underlying this figure (D) can be found in S1 Data. https://doi.org/10.1371/journal.pbio.3002373.g002<x_0.8486><y_0.3586><class_Text>

<x_0.1494><y_0.3695>and prospective trials quantify the choice biases that exist before and after the PDM episode of interest occurs, respectively, with negative and positive values signifying that choices are biased to large and small, respectively.<x_0.833><y_0.4273><class_Text>

<x_0.1494><y_0.4578>## Decision-making processes for binary classification<x_0.8213><y_0.4891><class_Section-header>

<x_0.1494><y_0.5102>As a first step of evaluating the value-updating and world-updating scenarios, we constructed a common platform of decision-making for binary classification where both scenarios play out. This platform consists of 3 processing stages (Fig 3A). At the stage of “perception,” the decision maker infers the class probabilities, i.e., the probabilities that the ring size (S) is larger and smaller, respectively, than the class boundary (B) given a noisy sensory measurement (m), as follows:<x_0.8496><y_0.6023><class_Text>

<x_0.1494><y_0.6906>where CL stands for the class variable with the 2 (small and large) states.<x_0.6367><y_0.7102><class_Text>

<x_0.1494><y_0.7211>At the stage of “valuation,” the decision-maker forms the expected values for the 2 choices (_Q<sub>large</sub>_ and _Q<sub>small</sub>_) by multiplying the class probabilities by the learned values of the corresponding choices (_V<sub>large</sub>_ and _V<sub>small</sub>_) as follows:<x_0.834><y_0.7773><class_Text>
