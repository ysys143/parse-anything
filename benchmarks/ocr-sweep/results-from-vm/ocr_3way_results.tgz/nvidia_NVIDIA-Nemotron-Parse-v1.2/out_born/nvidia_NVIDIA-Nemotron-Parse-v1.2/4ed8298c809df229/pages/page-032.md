<x_0.2842><y_0.1133>\(p(m'_t,CL_t=small|B_t)=\int_{-\infty}^{B_t}p(m'_t|S_t)p(S_t|B_t)dS_t;\)<br>
\(p(m'_t,CL_t=large|B_t)=\int_{B_t}^{+\infty} p(m'_t|S_t)p(S_t|B_t)dS_t\) (10)<x_0.7148><y_0.1969><class_Formula>

<x_0.1533><y_0.2125>where \(p(m'_t|S_t)=N(m'_t;S_t,\sigma_{m^\prime}^2+\sigma_m^2)\), according to the "chain" relations defined in the learned generative model (\(S\rightarrow m\rightarrow m'\) in the left panel of Fig 3D; Eqs 5 and 6; see Equation S2 for derivations in Text in S1 Appendix). Eq 10 indicates that BMBU calculates how likely hypothetical boundary states bring about the mnemonic measurement (\(B\rightarrow S\rightarrow m\rightarrow m'\)) while taking into account the informed state of the class variable (\(B\rightarrow CL\leftarrow S\)), by constraining the possible range of the stimulus states. To help readers intuitively appreciate these respective contributions of the mnemonic measurement and the informed state of the class variable (feedback) to the boundary likelihood, we further elaborated on how Eq 9 is reduced to Eq 10 depending on the informed state of _CL<sub>t</sub>_ (see Text in SI Appendix and S1 Fig).<x_0.832><y_0.3766><class_Text>

<x_0.1533><y_0.393>Lastly, we evaluate the integral for _CL<sub>t</sub>=small_ in Eq 10 by substituting $p(S\_t|B\_t) = $ \(N(S_t;B_t,\sigma_S^2)\) and \(p(m'_t|S_t)=N(m'_t;S_t,\sigma_{m^\prime}^2+\sigma_m^2)\), from the defined statistical knowledge in the<x_0.8369><y_0.4273><class_Text>

<x_0.1533><y_0.5062>learned generative model (Eq 3 and Eqs 5 and 6, respectively) and find:<x_0.6191><y_0.5172><class_Text>

<x_0.2109><y_0.5344>\(p(m'_t,CL_t=small|B_t)\)<br>
\(=\frac{1}{\sqrt{2\pi\left(\frac{\sigma_M^2\sigma_S^2}{\sigma_M^2+\sigma_S^2}\right)}}\int_{-\infty}^{B_t}e^{-\frac{\left(s_t-\frac{B_t\sigma_M^2+m_t^\prime\sigma_S^2}{\sigma_M^2+\sigma_S^2}\right)^2}{2\frac{\sigma_M^2\sigma_S^2}{\sigma_M^2+\sigma_S^2}}}dS_t\times\frac{1}{\sqrt{2\pi(\sigma_M^2+\sigma_S^2)}}e^{-\frac{(B_t-m_t^\prime)^2}{2(\sigma_M^2+\sigma_S^2)}}.\) (11)<x_0.7881><y_0.6492><class_Formula>

<x_0.1533><y_0.6648>where \(\sigma_M^2=\sigma_{m_t^\prime}^2+\sigma_m^2\). For the other state in feedback, we evaluate the integral in the same manner and find:<x_0.8447><y_0.6977><class_Text>

<x_0.2119><y_0.7172>\(p(m'_t,CL_t=large|B_t)\)<br>
\(=\frac{1}{\sqrt{2\pi\left(\frac{\sigma_M^2\sigma_S^2}{\sigma_M^2+\sigma_S^2}\right)}}\int_{B_t}^\infty e^{-\frac{\left(s_t-\frac{B_t\sigma_M^2+m_t^\prime\sigma_S^2}{\sigma_M^2+\sigma_S^2}\right)^2}{2\frac{\sigma_M^2\sigma_S^2}{\sigma_M^2+\sigma_S^2}}}dS_t\times\frac{1}{\sqrt{2\pi(\sigma_M^2+\sigma_S^2)}}e^{-\frac{(B_t-m_t^\prime)^2}{2(\sigma_M^2+\sigma_S^2)}}.\) (12)<x_0.7871><y_0.8313><class_Formula>

<x_0.1533><y_0.85>Having calculated the likelihood of _B<sub>t</sub>_, we turn to describe (ii) how BMBU combines that likelihood with a prior distribution on trial _t_, which forms a posterior distribution of _B<sub>t</sub>_ according to Bayes rule:<x_0.835><y_0.8797><class_Text>