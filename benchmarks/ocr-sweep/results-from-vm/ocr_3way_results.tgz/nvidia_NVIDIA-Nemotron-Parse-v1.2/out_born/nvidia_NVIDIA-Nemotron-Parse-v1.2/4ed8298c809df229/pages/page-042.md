<x_0.1533><y_0.1141>18. Odoemene O, Pisupati S, Nguyen H, Churchland AK. Visual evidence accumulation guides decision making in unrestrained mice. J Neurosci. 2018; 38(47):10143–10155. https://doi.org/10.1523/ JNEUROSCI.3478-17.2018 PMID: 30322902<x_0.8252><y_0.1664><class_List-item>

<x_0.1533><y_0.1695>19. Hermoso-Mendizabal A, Hyafil A, Rueda-Orozco PE, Jaramillo S, Robbe D, de la Rocha J. Response outcomes gate the impact of expectations on perceptual decisions. Nat Commun. 2020; 11(1):1057. https://doi.org/10.1038/s41467-020-14824-w PMID: 32103009<x_0.8281><y_0.2227><class_List-item>

<x_0.1533><y_0.2258>20. Akrami A, Kopec CD, Diamond ME, Brody CD. Posterior parietal cortex represents sensory history and mediates its effects on behaviour. Nature. 2018; 554(7692):368–372. https://doi.org/10.1038/ nature25510 PMID: 29414944<x_0.8428><y_0.2797><class_List-item>

<x_0.1533><y_0.2812>21. Summerfield C, Tsetsos K. Building bridges between perceptual and economic decision-making: neural and computational mechanisms. Front Neurosci. 2012; 6:70. https://doi.org/10.3389/fnins.2012.00070 PMID: 22654730<x_0.8096><y_0.3359><class_List-item>

<x_0.1533><y_0.3375>22. Kahnt T, Grueschow M, Speck O, Haynes JD. Perceptual learning and decision-making in human medial frontal cortex. Neuron. 2011; 70(3):549–559. https://doi.org/10.1016/j.neuron.2011.02.054 PMID: 21555079<x_0.8105><y_0.3914><class_List-item>

<x_0.1533><y_0.4672>24. Polani ́ a R, Krajbich I, Grueschow M, Ruff CC. Neural oscillations and synchronization differentially support evidence accumulation in perceptual and value-based decision making. Neuron. 2014; 82(3):709–720. https://doi.org/10.1016/j.neuron.2014.03.014 PMID: 24811387<x_0.8203><y_0.5203><class_List-item>

<x_0.1533><y_0.5234>25. Ko ̈rding KP, Wolpert DM. Bayesian decision theory in sensorimotor control. Trends Cogn Sci. 2006; 10(7):319–326. https://doi.org/10.1016/j.tics.2006.05.003 PMID: 16807063<x_0.8311><y_0.5578><class_List-item>

<x_0.1533><y_0.5609>26. Trommersha ̈user J, Maloney LT, Landy MS. Decision making, movement planning and statistical decision theory. Trends Cogn Sci. 2008; 12(8):291–297. https://doi.org/10.1016/j.tics.2008.04.010 PMID: 18614390<x_0.8125><y_0.6141><class_List-item>

<x_0.1533><y_0.6172>27. Griffiths TL, Tenenbaum JB. Optimal predictions in everyday cognition. Psychol Sci. 2006; 17(9):767– 773. https://doi.org/10.1111/j.1467-9280.2006.01780.x PMID: 16984293<x_0.8369><y_0.6516><class_List-item>

<x_0.1533><y_0.6547>28. Tenenbaum JB, Kemp C, Griffiths TL, Goodman ND. How to grow a mind: statistics, structure, and abstraction. Science. 2011; 331(6022):1279–1285. https://doi.org/10.1126/science.1192788 PMID: 21393536<x_0.8164><y_0.7078><class_List-item>

<x_0.1533><y_0.7109>29. Glaze CM, Filipowicz ALS, Kable JW, Balasubramanian V, Gold JI. A bias–variance trade-off governs individual differences in on-line learning in an unpredictable environment. Nat Hum Behav. 2018; 2(3):213–224.<x_0.8291><y_0.7641><class_List-item>

<x_0.1533><y_0.768>30. Ma WJ. Bayesian decision models: A primer. Neuron. 2019; 104(1):164–175. https://doi.org/10.1016/j.neuron.2019.09.037 PMID: 31600512<x_0.6719><y_0.8016><class_List-item>

<x_0.1533><y_0.8047>31. Hachen I, Reinartz S, Brasselet R, Stroligo A, Diamond ME. Dynamics of history-dependent perceptual judgment. Nat Commun. 2021; 12(1):6036. https://doi.org/10.1038/s41467-021-26104-2 PMID: 34654804<x_0.8457><y_0.8578><class_List-item>