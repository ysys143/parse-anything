<x_0.1533><y_0.1164>outperforms the former in explaining how corrective feedback adjusts the decision-making strategy along with past stimuli and choices. Our work suggests that humans learn about what has happened in their environment rather than the values of their own choices through corrective feedback during perceptual decision-making.<x_0.8408><y_0.1852><class_Text>

<x_0.1543><y_0.225>## Introduction<x_0.3096><y_0.2422><class_Section-header>

<x_0.1543><y_0.275>Perceptual decision-making (PDM) means committing to a proposition about an objective world state (e.g., “The temperature today is low.”). Decision-makers adjust future commitments based on what they experienced from past commitments, including what they perceived, what they chose, and what the environment gave them in return. Among these history factors, _trial-to-trial corrective feedback--_ feedback about the correctness of a decision-maker’s choices on a trial-to-trial basis—is widely used by experimenters to train participants on PDM tasks. Despite this clear utility of feedback and a pile of evidence for its impact on subsequent PDM behavior across species and sensory modalities [1–11], much remains elusive about how corrective feedback, in conjunction with other history factors, exerts its trial- to-trial influence on subsequent decisions.<x_0.8389><y_0.4367><class_Text>

<x_0.1904><y_0.5219>figure<x_0.2266><y_0.5336><class_Caption>

![figure](assets/p2_2.png)

<x_0.2314><y_0.5547>benefits of transparency in the peer review process; therefore, we enable the publication of all of the content of peer review and author responses alongside final, published articles. The editorial history of this article is available here:<br> https://doi.org/10.1371/journal.pbio.3002373<x_0.3896><y_0.6086><class_Footnote>

<x_0.2314><y_0.6156>**Copyright:** © 2023 Lee et al. This is an open access article distributed under the terms of the Creative Commons Attribution License, which permits unrestricted use, distribution, and reproduction in any medium, provided the original author and source are credited.<x_0.3906><y_0.6695><class_Footnote>

<x_0.2314><y_0.6773>**Data Availability Statement:** Raw data, processed data files, and codes used in this study are publicly available on GitHub at: https://github.com/ hyangjung-lee/lee\_2023\_corrective-fbk (https://doi.<x_0.3916><y_0.7133><class_Footnote>

<x_0.4043><y_0.5891>### Introduction<x_0.4766><y_0.5977><class_Section-header>

<x_0.4033><y_0.6047>Perceptual decision-making (PDM) means committing to a proposition about an objective world state (e.g., “The temperature today is low.”). Decision-makers adjust future commitments based on what they experienced from past commitments, including what they perceived, what they chose, and what the environment gave them in return. Among these history factors, _trial-to-trial corrective feedback--_ feedback about the correctness of a decision-maker’s choices on a trial-to-trial basis—is widely used by experimenters to train participants on PDM tasks. Despite this clear utility of feedback and a pile of evidence for its impact on subsequent PDM behavior across species and sensory modalities [1–11], much remains elusive about how corrective feedback, in conjunction with other history factors, exerts its trial- to-trial influence on subsequent decisions.<x_0.7969><y_0.7141><class_Text>
