<x_0.334><y_0.1469>**CorrectiveFeedbackCSNL**<x_0.6709><y_0.1719><class_Page-header>

![figure](assets/p1_1.png)

<x_0.1895><y_0.2828>figure<x_0.2314><y_0.2961><class_Text>

<x_0.1533><y_0.3141>RESEARCH ARTICLE<x_0.292><y_0.3273><class_Section-header>

<x_0.1533><y_0.3641>## Corrective feedback guides human perceptual decision-making by informing about the world state rather than rewarding its choice<x_0.8164><y_0.4602><class_Section-header>

<x_0.1533><y_0.4867>Hyang-Jung Lee1, Heeseung Lee1, Chae Young Lim2, Issac Shim3, Sang-Hun Lee1\*<x_0.7002><y_0.5><class_Text>

<x_0.1533><y_0.5172>1 Department of Brain and Cognitive Sciences, Seoul National University, Seoul, South Korea, 2 Department of Statistics, Seoul National University, Seoul, South Korea, 3 Institute of Neuroscience, University of Oregon, Eugene, Oregon, United States of America<x_0.8057><y_0.568><class_Text>

<x_0.1611><y_0.5852>• visionsl@snu.ac.kr<x_0.3027><y_0.5992><class_List-item>

<x_0.1533><y_0.6359>### Abstract<x_0.2715><y_0.6609><class_Section-header>

<x_0.1533><y_0.6875>Corrective feedback received on perceptual decisions is crucial for adjusting decision-making strategies to improve future choices. However, its complex interaction with other decision components, such as previous stimuli and choices, challenges a principled account of how it shapes subsequent decisions. One popular approach, based on animal behavior and extended to human perceptual decision-making, employs “reinforcement learning,” a principle proven successful in reward-based decision-making. The core idea behind this approach is that decision-makers, although engaged in a perceptual task, treat corrective feedback as rewards from which they learn choice values. Here, we explore an alternative idea, which is that humans consider corrective feedback on perceptual decisions as evidence of the actual state of the world rather than as rewards for their choices. By implementing these "feedback-as-reward" and "feedback-as-evidence" hypotheses on a shared learning platform, we show that the latter<x_0.8477><y_0.8695><class_Text>