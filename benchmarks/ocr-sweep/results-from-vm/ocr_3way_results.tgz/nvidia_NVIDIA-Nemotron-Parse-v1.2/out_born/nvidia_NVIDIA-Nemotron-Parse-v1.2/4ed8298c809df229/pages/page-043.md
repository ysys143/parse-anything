<x_0.1533><y_0.1141>32. Burnham KP, Anderson DR. Model Selection and Inference, A Practical Information-Heuristic Approach. New York: Springer-Verlag; 2002.<tbc><x_0.7812><y_0.1477><class_Bibliography>

<x_0.1533><y_0.1516>33. Stephan KE, Penny WD, Daunizeau J, Moran RJ, Friston KJ. Bayesian model selection for group studies. Neuroimage. 2009; 46(4):1004–1017. https://doi.org/10.1016/j.neuroimage.2009.03.025 PMID: 19306932<tbc><x_0.8486><y_0.2039><class_Bibliography>

<x_0.1533><y_0.2078>34. Rigoux L, Stephan KE, Friston KJ, Daunizeau J. Bayesian model selection for group studies—Revisited. Neuroimage. 2014; 84:971–985. https://doi.org/10.1016/j.neuroimage.2013.08.065 PMID: 24018303<tbc><x_0.8447><y_0.2422><class_Bibliography>

<x_0.1533><y_0.2453>35. Cao Y, Summerfield C, Park H, Giordano BL, Kayser C. Causal inference in the multisensory brain. Neuron. 2019; 102(5):1076–1087.e8. https://doi.org/10.1016/j.neuron.2019.03.043 PMID: 31047778<tbc><x_0.8232><y_0.2797><class_Bibliography>

<x_0.1533><y_0.2828>36. Palminteri S, Wyart V, Koechlin E. The importance of falsification in computational cognitive modeling. Trends Cogn Sci. 2017; 21(6):425–433. https://doi.org/10.1016/j.tics.2017.03.011 PMID: 28476348<tbc><x_0.8418><y_0.3172><class_Bibliography>

<x_0.1533><y_0.3203>37. Urai AE, Braun A, Donner TH. Pupil-linked arousal is driven by decision uncertainty and alters serial choice bias. Nat Commun. 2017; 8(1):14637. https://doi.org/10.1038/ncomms14637 PMID: 28256514<tbc><x_0.835><y_0.3539><class_Bibliography>

<x_0.1533><y_0.3578>38. Zariwala HA, Kepecs A, Uchida N, Hirokawa J, Mainen ZF. The limits of deliberation in a perceptual decision task. Neuron. 2013; 78(2):339–351. https://doi.org/10.1016/j.neuron.2013.02.010 PMID: 23541901<tbc><x_0.8203><y_0.4102><class_Bibliography>

<x_0.1533><y_0.4141>39. Renart A, Machens CK. Variability in neural activity and behavior. Curr Opin Neurobiol. 2014; 25:211– 220. https://doi.org/10.1016/j.conb.2014.02.013 PMID: 24632334<tbc><x_0.8311><y_0.4477><class_Bibliography>

<x_0.1533><y_0.4516>40. Qamar AT, Cotton RJ, George RG, Beck JM, Prezhdo E, Laudano A, et al. Trial-to-trial, uncertainty- based adjustment of decision boundaries in visual categorization. Proc National Acad Sci. 2013; 110(50):20332–20337. https://doi.org/10.1073/pnas.1219756110 PMID: 24272938<tbc><x_0.8174><y_0.5039><class_Bibliography>

<x_0.1533><y_0.5078>41. Summerfield C, Behrens TE, Koechlin E. Perceptual classification in a rapidly changing environment. Neuron. 2011; 71(4):725–736. https://doi.org/10.1016/j.neuron.2011.06.022 PMID: 21867887<tbc><x_0.8301><y_0.5414><class_Bibliography>

<x_0.1533><y_0.5453>42. Norton EH, Fleming SM, Daw ND, Landy MS. Suboptimal criterion learning in static and dynamic environments. PLoS Comput Biol. 2017; 13(1):e1005304. https://doi.org/10.1371/journal.pcbi.1005304 PMID: 28046006<tbc><x_0.8389><y_0.5977><class_Bibliography>

<x_0.1533><y_0.6008>43. Treisman M, Williams TC. A theory of criterion setting with an application to sequential dependencies. Psychol Rev. 1984; 91(1):68–111.<tbc><x_0.8408><y_0.6352><class_Bibliography>

<x_0.1533><y_0.6391>44. Lages M, Treisman M. A criterion setting theory of discrimination learning that accounts for anisotropies and context effects. Seeing Perceiving. 2010; 23(5):401–434. https://doi.org/10.1163/187847510x541117 PMID: 21466134<tbc><x_0.7734><y_0.6914><class_Bibliography>

<x_0.1533><y_0.6945>45. Fritsche M, Mostert P, Lange FP de. Opposite effects of recent history on perception and decision. Curr Biol. 2017; 27(4):590–5.<tbc><x_0.8213><y_0.7289><class_Bibliography>

<x_0.1533><y_0.7328>46. Drugowitsch J, Mendonc ̧a AG, Mainen ZF, Pouget A. Learning optimal decisions with confidence. Proc National Acad Sci. 2019; 116(49):24872–24880. https://doi.org/10.1073/pnas.1906787116 PMID: 31732671<tbc><x_0.8398><y_0.7852><class_Bibliography>

<x_0.1533><y_0.8313>PLOS BIOLOGY<x_0.2588><y_0.8461><class_Page-footer>