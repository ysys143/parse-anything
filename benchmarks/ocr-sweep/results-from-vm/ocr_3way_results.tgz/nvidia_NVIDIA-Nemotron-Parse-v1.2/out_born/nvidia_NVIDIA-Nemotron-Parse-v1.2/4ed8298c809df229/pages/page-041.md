<x_0.1621><y_0.1156>4. Busse L, Ayaz A, Dhruv NT, Katzner S, Saleem AB, Scholvinck ML, et al. The detection of visual con trast in the behaving mouse. J Neurosci. 2011; 31(31):11351–11361. https://doi.org/10.1523/ JNEUROSCI.6689-10.2011 PMID: 21813694<x_0.8262><y_0.1664><class_List-item>

<x_0.1621><y_0.1719>5. Scott BB, Constantinople CM, Erlich JC, Tank DW, Brody CD. Sources of noise during accumulation of evidence in unrestrained and voluntarily head-restrained rats. eLife. 2015; 4:e11308. https://doi.org/10. 7554/eLife.11308 PMID: 26673896<x_0.8477><y_0.2227><class_List-item>

<x_0.1621><y_0.2281>6. Mendonc ̧a AG, Drugowitsch J, Vicente MI, DeWitt EEJ, Pouget A, Mainen ZF. The impact of learning on perceptual decisions and its implication for speed-accuracy tradeoffs. Nat Commun. 2020; 11 # (1):2757. https://doi.org/10.1038/s41467-020-16196-7 PMID: 32488065<x_0.8359><y_0.2789><class_List-item>

<x_0.1621><y_0.2836>7. Fernberger SW. Interdependence of judgments within the series for the method of constant stimuli. J Exp Psychol. 1920; 3(2):126–150.<x_0.8379><y_0.3164><class_List-item>

<x_0.1621><y_0.3219>8. Lak A, Nomoto K, Keramati M, Sakagami M, Kepecs A. Midbrain dopamine neurons signal belief in choice accuracy during a perceptual decision. Curr Biol. 2017; 27(6):821–832. https://doi.org/10.1016/j. cub.2017.02.026 PMID: 28285994<x_0.8164><y_0.3727><class_List-item>

<x_0.1621><y_0.3773>9. Lak A, Hueske E, Hirokawa J, Masset P, Ott T, Urai AE, et al. Reinforcement biases subsequent perceptual decisions when confidence is low, a widespread behavioral phenomenon. eLife. 2020; 9: e49834. https://doi.org/10.7554/eLife.49834 PMID: 32286227<x_0.8184><y_0.4289><class_List-item>

<x_0.1533><y_0.4344>10. Lak A, Okun M, Moss MM, Gurnani H, Farrell K, Wells MJ, et al. Dopaminergic and prefrontal basis of learning from sensory confidence and reward value. Neuron. 2020; 105(4):700–711.e6. https://doi.org/ 10.1016/j.neuron.2019.11.018 PMID: 31859030<x_0.8457><y_0.4852><class_List-item>

<x_0.1533><y_0.4906>11. Nogueira R, Abolafia JM, Drugowitsch J, Balaguer-Ballester E, Sanchez-Vives MV, Moreno-Bote R. Lateral orbitofrontal cortex anticipates choices and integrates prior with current information. Nat Com mun. 2017; 8(1):14823. https://doi.org/10.1038/ncomms14823 PMID: 28337990<x_0.8428><y_0.5414><class_List-item>

<x_0.1533><y_0.5469>12. Lee D, Seo H, Jung MW. Neural basis of reinforcement learning and decision making. Annu Rev Neu rosci. 2012; 35(1):287–308. https://doi.org/10.1146/annurev-neuro-062111-150512 PMID: 22462543 ## 13. Daw ND, Doya K. The computational neurobiology of learning and reward. Curr Opin Neurobiol. 2006; 16(2):199–204. https://doi.org/10.1016/j.conb.2006.03.006 PMID: 16563737<x_0.8418><y_0.6156><class_List-item>

<x_0.1533><y_0.6219>13. Sutton R, Barto A. Reinforcement Learning: An Introduction. Cambridge, MA: MIT Press; 1998.<x_0.792><y_0.6344><class_List-item>

<x_0.1533><y_0.6406>14. Corrado GS, Sugrue LP, Seung HS, Newsome WT. Linear-nonlinear-poisson models of primate choice dynamics. J Exp Anal Behav. 2005; 84(3):581–617. https://doi.org/10.1901/jeab.2005.23-05 PMID: 16596981<x_0.8418><y_0.6914><class_List-item>

<x_0.1533><y_0.6961>15. Lau B, Glimcher PW. Dynamic response-by-response models of matching behavior in rhesus monkeys. J Exp Anal Behav. 2005; 84(3):555–579. https://doi.org/10.1901/jeab.2005.110-04 PMID: 16596980<x_0.8223><y_0.7477><class_List-item>

<x_0.1533><y_0.7523>16. Gla ̈scher J, Daw N, Dayan P, O’Doherty JP. States versus rewards: dissociable neural prediction error signals underlying model-based and model-free reinforcement learning. Neuron. 2010; 66(4):585– 595. https://doi.org/10.1016/j.neuron.2010.04.016 PMID: 20510862<x_0.8438><y_0.8031><class_List-item>

<x_0.1543><y_0.8094>17. Lee SW, Shimojo S, O’Doherty JP. Neural computations underlying arbitration between model-based and model-free learning. Neuron. 2014; 81(3):687–699. https://doi.org/10.1016/j.neuron.2013.11.028 PMID: 24507199<x_0.835><y_0.8594><class_List-item>