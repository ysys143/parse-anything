<x_0.1533><y_0.1148>S1 Data. Excel spreadsheet containing, in separate sheets, the underlying numerical data for Figs 2D, 4B, 4D, 4E, 4G, 4H, 5B, 5D, 5E, 5G, 5H, 6B, 6C, 6D, 7A, 7B, 7C, 7D, 7E, 7F, S2A, S2B, S3, S4A, S4B, S5, S6A, S6B, S7A and S7B. (XLSX)<x_0.8389><y_0.1664><class_Text>

<x_0.1533><y_0.1828>S2 Data. Excel spreadsheet containing detailed statistical information comparing alternative PSE estimation methods. (XLSX)<x_0.7842><y_0.2156><class_Text>

<x_0.1533><y_0.2508>## Acknowledgments<x_0.3994><y_0.2773><class_Section-header>

<x_0.1533><y_0.3039>The authors are grateful to Daeyeol Lee for his insightful comments and inspiring conversations concerning the prior version of the manuscript.<x_0.7783><y_0.3359><class_Text>

<x_0.1533><y_0.3711>### Author Contributions<x_0.4297><y_0.3984><class_Section-header>

<x_0.1533><y_0.4242>Conceptualization: Hyang-Jung Lee, Heeseung Lee, Sang-Hun Lee. Data curation: Issac Rhim. Formal analysis: Hyang-Jung Lee. Funding acquisition: Sang-Hun Lee. Investigation: Hyang-Jung Lee. Methodology: Hyang-Jung Lee, Chae Young Lim, Sang-Hun Lee. Resources: Sang-Hun Lee. Software: Hyang-Jung Lee. Supervision: Sang-Hun Lee. Validation: Hyang-Jung Lee, Chae Young Lim, Sang-Hun Lee. Visualization: Hyang-Jung Lee, Sang-Hun Lee. Writing – original draft: Hyang-Jung Lee. Writing – review & editing: Hyang-Jung Lee, Heeseung Lee, Chae Young Lim, Issac Rhim, Sang-Hun Lee.<x_0.8262><y_0.532><class_Text>

<x_0.1533><y_0.5672>## References<x_0.3047><y_0.5945><class_Section-header>

<x_0.1621><y_0.6195>1. Gold JI, Law CT, Connolly P, Bennur S. The relative influences of priors and sensory evidence on an oculomotor decision variable during perceptual learning. J Neurophysiol. 2008; 100(5):2653–2668. https://doi.org/10.1152/jn.90629.2008 PMID: 18753326<x_0.8291><y_0.6719><class_List-item>

<x_0.1621><y_0.6758>2. Hwang EJ, Dahlen JE, Mukundan M, Komiyama T. History-based action selection bias in posterior parietal cortex. Nat Commun. 2017; 8(1):1242. https://doi.org/10.1038/s41467-017-01356-z PMID: 29089500<x_0.8193><y_0.7273><class_List-item>

<x_0.1533><y_0.7438>PLOS BIOLOGY Corrective feedback on perceptual decisions PLOS Biology | https://doi.org/10.1371/journal.pbio.3002373 November 8, 2023 29 / 32<x_0.6543><y_0.7773><class_Text>

<x_0.1621><y_0.8234>3. Abrahamyan A, Silva LL, Dakin SC, Carandini M, Gardner JL. Adaptable history biases in human per ceptual decisions. Proc National Acad Sci. 2016; 113(25):E3548–E3557. https://doi.org/10.1073/pnas. 1518786113 PMID: 27330086<x_0.8379><y_0.875><class_List-item>