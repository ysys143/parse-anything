![Fig 4](assets/p16_1.png)

<|det|>image [800