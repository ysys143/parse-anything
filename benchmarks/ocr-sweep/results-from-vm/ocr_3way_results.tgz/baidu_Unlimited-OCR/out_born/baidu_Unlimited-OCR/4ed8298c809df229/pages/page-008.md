<|det|>image_caption [351, 255, 751, 283]<|/det|>binary classification of ring size
<|det|>image_caption [218, 449, 374, 500]<|/det|>Stimulus \(S\in \{-2, - 1,0,1,2\}\)
<|det|>image_caption [448, 449, 641, 500]<|/det|>Choice \(C\in \{small, large\}\)
<|det|>image_caption [682, 449, 906, 500]<|/det|>Feedback \(F\in \{\text{correct, incorrect}\}\)

![figure](assets/p9_1.png)